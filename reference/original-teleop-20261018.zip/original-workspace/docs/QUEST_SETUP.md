# Quest 手部数据接收

遥操作实现已迁入与 `harness/` 同级的 [`遥操/`](../遥操/README.md)，统一入口为 `python -m 遥操 receive|hand|arm`。下文已有的 `tools/quest_*.py` 命令保留兼容；手部跟随仍需 WSL 重定向环境，机械臂当前仍为映射预览。

Quest 3 / 3S 安装 Hand Tracking Streamer。`tools/quest_receive.py` 只接收数据；`tools/quest_hand.py` 可预览重定向，显式加 `--execute` 才会进行 Wuji 右手跟随。

## Wi-Fi

1. 头显和电脑连同一个普通 Wi-Fi。企业网络可能启用客户端隔离。
2. 电脑运行 `ipconfig`，找当前 Wi-Fi 的 IPv4 地址。换网络后重新查看。
3. 头显选 UDP，目标 IP 填电脑 IPv4，端口 9000，选择右手或双手。取消勾选 `Video Feed`，再开始串流。
4. 电脑在项目根目录运行：

```powershell
.\.venv-quest\Scripts\python.exe -m pip install -r requirements-quest.txt
.\.venv-quest\Scripts\python.exe tools\quest_receive.py --duration 300
```

允许 Windows 防火墙提示中的 Python 接收该网络的数据。无数据时检查目标 IP、端口、防火墙和路由器客户端隔离。无需关闭防火墙。

正常时显示 `Right/wrist` 和 `Right/landmarks` 的数据包到达频率与最新接收年龄；腕部包含 xyz（米）和四元数 xyzw，landmarks 包含 21 个三维点。抬手、握拳、转腕，检查数值是否改变。原始数据和检查结果写入 `live/quest`。

保留 Unity 坐标约定，尚未标定到机械臂坐标。接收年龄只表示电脑多久没收到数据；没有源时钟标定，不能作为端到端延迟。仅接收到数据也不代表源端追踪有效或机器人已经可以跟随。

## USB 备选

1. 数据线连接头显，允许 USB 调试，`adb devices -l` 应显示 `device`。
2. 电脑配置 USB 转发并启动接收：

```powershell
adb reverse tcp:8000 tcp:8000
adb reverse --list
.\.venv-quest\Scripts\python.exe tools\quest_receive.py --transport tcp --host 127.0.0.1 --port 8000 --duration 600
```

3. 头显选择 `TCP - wired`，目标 IP 填 `127.0.0.1`，端口 8000。取消勾选 `Video Feed`，再点 `Start Streaming`。电脑充当 TCP 服务端，头显主动连接。
4. 保持头显戴在头上，放下手柄，把裸手放到头显可见范围，抬手、转腕、张手握拳。

TCP 接收使用上游 SDK 的分行和断线恢复逻辑，支持半包、粘包和重新连接。断线期间仍报告数据接收年龄。更换 USB 连接后可能需要重新执行转发命令。

## 已确认的连接故障（HTS 1.1.0 / Quest 3S）

`Video Feed` 是电脑向头显回传视频的功能，需要另外启动视频服务。只接收手部数据时请关闭它。

2026-10-16 实测：USB TCP 8000 已连接且收到了双手腕部、关键点和头部姿态，但勾选 `Video Feed` 后，应用连接 `ws://127.0.0.1:8765` 失败，日志报告 `TCP Disconnect Triggered: Video failure: Signaling connection failed.`，随后手部数据也断开。

取消勾选并重新开始后，连续 30 秒验证通过：双手 wrist、landmarks 和 Head pose 各收到 2161 包，平均约 72 包/秒，解析错误为 0；每手均为 21 个关键点。双手各 2161 对 wrist/landmarks 的源帧号及时间戳一致，源帧号和时间戳严格递增。该窗口手部最大到包间隔约 22.44 毫秒；这不是端到端延迟。结果保存在 `live/quest/usb_validation.json`，原始记录为 `live/quest/capture_20261016_125027.jsonl`。

该窗口出现姿态值重复，尤其左手只有 51 个不同腕部姿态。不能仅凭收到新帧号判断手仍被有效追踪；接机械臂前必须确认源端跟踪有效性字段或补充机制，不能直接将持续到包当成允许运动的条件。

`mono-io-layer-error (数字)` 是通用 I/O 错误文本，仅凭文字不能判断具体故障。应读取同一时刻应用日志，区分手部 TCP 连接和视频连接失败。USB 显示 `unauthorized` 时，先在头显重新允许调试；`adb devices -l` 显示 `device` 后重新设置转发。

2026-10-16 13:38 再次报错的日志为连接 `127.0.0.1:8000` 时 `mono-io-layer-error (111)`（连接被拒绝）。此时电脑 8000 端口正在监听、USB 已授权，但 `adb reverse --list` 为空。重新执行 `adb reverse tcp:8000 tcp:8000` 恢复转发后，在头显 Stop/Start Streaming。头显重启或 USB 拔插后应检查转发，反复拔插本身不会建立它。

本次排查中转发还曾在下一次命令检查时再次消失。将 ADB 服务改为独立常驻会话后，重新设置的转发跨命令检查仍保留：先 `adb kill-server`，再在一个保持打开的终端运行 `adb nodaemon server`；其他终端执行 reverse 和接收器命令。此操作会断开已有 ADB 会话，只在该故障排查时使用。App 错误界面无法退出时，可执行 `adb shell am force-stop com.wengmister.handtrackingstreamer` 后从头显重新打开，不需要清空应用数据。进程列表中同一虚拟环境的 Python 启动器及子进程并不能证明端口冲突，应检查实际监听端口。

上游：[HTS](https://github.com/wengmister/hand-tracking-streamer)、[连接说明](https://github.com/wengmister/hand-tracking-streamer/blob/main/CONNECTIONS.md)、[Python SDK](https://github.com/wengmister/hand-tracking-sdk)。

## Wuji Hand 2 右手跟随

此入口只控制手指，不使用腕部 xyz/旋转控制机械臂。头显开启右手或双手、`Debug Info`，关闭 `Video Feed`。先启动上面的 USB 接收器，确认新数据持续到达；接收器重启后，在头显 Stop/Start Streaming。将右手留在头显前方，避免遮挡。

当前安装使用 WSL Ubuntu-22.04 的 `/home/jianziyu/.venv-quest-retarget`，与 `/opt/wuji-venv` 驱动环境分开。已验证的核心版本为 Python 3.10、numpy 2.2.6、scipy 1.15.3、pin 4.1.0、nlopt 2.11.0、PyYAML 5.4.1。官方源码位于 `live/vendor/wuji-retargeting`，提交 `531f6ed4250b475d2e9231f54e988fc9b1c5b4ea`，description 子模块提交 `8271644a78d69ed9a4adcf9165d882c64ad33dfa`。驱动继续使用 wuji-sdk 2026.9.22；不要同时运行另一个 SDK/CLI 运动控制器。

在 PowerShell 中将 capture 路径换成接收器本次生成的文件。以下命令默认只预览：

```powershell
wsl.exe -d Ubuntu-22.04 -- /home/jianziyu/.venv-quest-retarget/bin/python -u '/mnt/c/jianziYu/桌面/天机/tools/quest_hand.py' --capture '/mnt/c/jianziYu/桌面/天机/live/quest/capture_YYYYMMDD_HHMMSS.jsonl' --duration 20
```

确认手掌已固定、指尖周围清空，Harness 黑板和 Wuji 驱动已就绪后，添加 `--execute` 即可持续跟随；同时删去示例中的 `--duration 20`，默认运行至 Ctrl+C。默认没有额外的相对起点角度限制，目标检查模型关节限位。它仍跟随相对启动姿态的变化，不会启动即跳到绝对姿态。默认速度上限 0.15 rad/s、电流上限 0.8 A、MIT 增益 2.0/0.04。程序检查实际反馈和诊断，Ctrl+C 或保护触发后失能并确认 20 个关节回到 Ready。停止后需要显式新开一轮，不自动恢复使能。需要复现早期小幅测试时，显式添加 `--duration 20 --max-delta 0.15`。

接收器自身也应使用 `--duration 0` 才会持续到 Ctrl+C；此前已启动的定时接收器不会因修改脚本自动延长。接收器重启后需在头显 Stop/Start Streaming，并让跟随命令使用新生成的 capture 文件。

输入超过 200 ms、源时间/序号重置、积压超过 150 ms、连续 750 ms 关键点完全不变均会终止；驱动另有 250 ms 目标看门狗及租约/诊断保护。由于 HTS 尚未传出 tracking-valid 字段，完全不变被保守视为可能丢失追踪：手出视野或遮挡可能触发，保持静止也可能误触发。恢复追踪后先确认数据再启动新一轮。`--replay` 仅用于离线预览，不能与 `--execute` 同用。

2026-10-16 实测：`live/quest/follow_20261016_132630.json` 记录 387 个样本、十多秒跟随，20 个关节实测位置均有变化；随后输入姿态冻结触发停止，`disabled_after=true` 且清理无错误。用户随后报告看见运动。该测试只验证有界跟随链路；尚未逐指确认方向、拇指映射和绝对手型精度，尚未验证机械臂末端跟随。

离线检查：

```powershell
python -m unittest discover -s tests -p '*wuji*' -v
wsl.exe -d Ubuntu-22.04 -- /home/jianziyu/.venv-quest-retarget/bin/python -m unittest discover -s '/mnt/c/jianziYu/桌面/天机/tests' -p test_quest_retarget.py -v
```

## 天机腕部 6D 映射预览

`tools/quest_arm.py` 将右手 wrist 的相对 XYZ 和旋转映射为天机右末端 `base_link` pose，格式 `[x,y,z,qx,qy,qz,qw]`。它目前仅预览，**没有运动发送入口**。已有 `move_to_pose` 是阻塞单点运动，不能当成连续六维遥操接口；连续跟随和实机方向核验尚未完成。

```powershell
C:\ProgramData\miniconda3\python.exe tools\quest_arm.py
```

默认选最新 capture 文件、读取新鲜天机位姿作为锚点，运行到 Ctrl+C；也可显式给 `--capture`、`--duration 20`。头显需开启 Head Pose 和 Debug Info。启动时平视希望映射到机器人正前方（base +X）的方向，并将右手保持在视野内。只使用启动时头部朝向的水平分量确定前方，此后转头不会改变映射方向。默认位置比例 1:1，可用 `--scale` 修改。

代码转换 Unity 的右/上/前坐标约定：启动时头部的正前方向映射到机器人 +X，右侧映射到 −Y，上方映射到 +Z。旋转增量通过包含反射的基变换处理，再乘机械臂启动朝向；初始手腕与末端姿态各自作为零点，首个目标保持机械臂当前姿态。它尚未标定 wrist 到 Wuji 掌心/指尖的 TCP 杠杆偏移，不能把原始 wrist 直接当成 `r_link7` 的绝对位姿。该映射依赖 Head/pose 与 wrist 共享 Unity 世界坐标，需在真实抬手、向前和转腕时验证方向；头显重置追踪原点后重新启动标定。

实时预览检查数据年龄、wrist/landmarks 源帧配对、源序号和时间推进、运输积压及姿态冻结。纯静止也可能触发冻结保护。旧录制可用 `--replay --robot-pose X Y Z QX QY QZ QW` 离线预览，不会连接机械臂读取锚点；预览不会夹紧目标，输出可能超出工作空间，不能直接执行整个录制。

2026-10-16：10 项离线测试通过，覆盖坐标方向、头部朝向对齐、任意起始姿态、旋转反射、四元数符号、输入过期/冻结/源重置。`capture_20261016_141953.jsonl` 离线生成 5440 个预览样本，结果 `arm_preview_20261016_143250.json`。这只验证数学和数据处理，未执行机械臂运动。

同日恢复记录：底层 ROS 的末端与关节话题持续更新，而原 Harness 驱动的位姿/夹爪订阅停止更新。空闲时退出旧进程后发现 systemd 配置是 `Restart=on-failure`，正常退出不会自动重启；当前 SSH 用户无免密 sudo，临时以同一 `driver.py` 启动独立通信进程（PID 1633779，日志 `/tmp/tianji-thor-driver-manual.log`，黑板 `http://6.6.8.10:17892`）。重新订阅后四路图像及双臂位姿/夹爪恢复新鲜，未发送运动目标。**当前 systemd 服务仍未运行，临时进程无崩溃自动恢复**。恢复托管时须在无活动租约/动作下，核对并停止这个独立进程，再 `sudo systemctl start tianji-thor-driver.service`，避免两个驱动并行。没有修改底层厂商服务。

随后通过共享 AgentTools 注册表调用 `ms_thor__prepare_control` 成功，反馈位置模式 `[1,1]`、控制输入 `1`、IK 来源 `2`，租约已释放；仅准备控制模式，未发送末端运动目标。状态快照为 `live/runtime/quest_arm_setup_20261016.json`。
