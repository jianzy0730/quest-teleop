"""Offline replay continuity, envelope, feedback and cleanup checks."""
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np

from 遥操.quest_arm_replay import (
    angle_deg, execute_session, make_plan, recorded_frames, scaled_rotation, wait_reached,
)

ANCHOR = np.array([.5, -.15, .7, 0., 0., 0., 1.])
SAFETY = {'workspace': {'x': [.2, .75], 'y': [-.4, .4], 'z': [.03, .9]}, 'max_step_m': .15}


def state(target, stamp=None):
    now = time.time()
    return {'updated_at': now, 'eef_right': list(target),
            'lease': {'by': 'test', 'expires': now+10},
            'perception': {'ready': True, 'streams': {'eef_right': {'source_t': stamp or now}}}}


class ReplayTests(unittest.TestCase):
    def write_capture(self, directory, frames):
        path = Path(directory)/'capture.jsonl'
        records = []
        for seq, ns, x, hand_seq in frames:
            pose_data = dict(x=x, y=1., z=0., qx=0., qy=0., qz=0., qw=1.)
            for key, data, number in (
                ('Right/wrist', pose_data, seq),
                ('Right/landmarks', {'points': [[x, 0., 0.]]*21}, hand_seq),
                ('Head/pose', pose_data, seq),
            ):
                records.append({'packets': [{'key': key, 'data': data,
                    'debug': {'source_frame_seq': number, 'source_ts_ns': ns}}]})
        path.write_text('\n'.join(json.dumps(r) for r in records), encoding='utf-8')
        return path

    def test_split_record_pairing_and_continuity(self):
        with tempfile.TemporaryDirectory() as temp:
            path = self.write_capture(temp, [(1, 1_000_000_000, 0., 1), (2, 1_050_000_000, .02, 2)])
            frames = recorded_frames(path, .05)
            self.assertEqual([f['source_seq'] for f in frames], [1, 2])
            self.assertAlmostEqual(frames[1]['t_s'], .05)

    def test_source_reset_gap_and_missing_pair_rejected(self):
        for second in [(0, 1_050_000_000, .02, 0), (2, 1_300_000_000, .02, 2),
                       (2, 1_050_000_000, .02, 99)]:
            with self.subTest(second=second), tempfile.TemporaryDirectory() as temp:
                path = self.write_capture(temp, [(1, 1_000_000_000, 0., 1), second])
                with self.assertRaises(ValueError):
                    recorded_frames(path, .05)

    def test_rotation_gain_and_sign(self):
        q = [0., 0., np.sin(np.pi/4), np.cos(np.pi/4)]
        a = scaled_rotation(ANCHOR[3:], q, .05)
        b = scaled_rotation(ANCHOR[3:], -np.asarray(q), .05)
        np.testing.assert_allclose(a, b)
        self.assertAlmostEqual(angle_deg(a, ANCHOR[3:]), 4.5)

    def test_plan_rebased_and_bounds_include_unsampled_frames(self):
        frames = [{'wrist': np.array([x, 1., 0., 0., 0., 0., 1.]),
                   'head': [0, 1, 0, 0, 0, 0, 1], 't_s': t, 'source_seq': i, 'source_ns': i+1}
                  for i, (x, t) in enumerate([(0., 0.), (.05, .1), (.1, .2)])]
        plan = make_plan(frames, ANCHOR, SAFETY, position_scale=.3, interval_s=.2)
        np.testing.assert_allclose(plan['waypoints'][0]['pose'][:3], [.5, -.18, .7])
        # Even an intermediate frame omitted by the sampling interval must be safe.
        frames[1]['wrist'][0] = 1.
        with self.assertRaises(ValueError): make_plan(frames, ANCHOR, SAFETY, interval_s=.2)

    def test_xyz_success_does_not_mask_rotation_failure(self):
        class Fake:
            by = 'test'
            def state(self): return state([.5, -.15, .7, 0., 0., .05, np.sqrt(1-.05**2)])
        with self.assertRaisesRegex(RuntimeError, 'not settled'):
            wait_reached(Fake(), ANCHOR, 0., timeout_s=.03)

    def test_cached_sample_not_counted_three_times(self):
        stamp = time.time()
        class Fake:
            by = 'test'
            def state(self): return state(ANCHOR, stamp)
        with self.assertRaisesRegex(RuntimeError, 'not settled'):
            wait_reached(Fake(), ANCHOR, 0., timeout_s=.12)

    def test_three_distinct_feedback_samples_verify_pose(self):
        class Fake:
            by = 'test'
            def state(self): return state(ANCHOR)
        result = wait_reached(Fake(), ANCHOR, 0., timeout_s=.4)
        self.assertEqual(result['completion'], 'pose_feedback_verified')

    def test_interruption_stops_then_releases(self):
        calls = []
        class Fake:
            def acquire(self, **kw): calls.append('acquire')
            def cap(self, name, args):
                calls.append(name)
                return {'exit': 'success'}
            def release(self):
                calls.append('release')
                return {'released': True}
        plan = {'mode': 'test', 'anchor': ANCHOR, 'waypoints': [{}]}
        with tempfile.TemporaryDirectory() as temp, patch('遥操.quest_arm_replay.ReplaySession.observe', side_effect=KeyboardInterrupt):
            result = execute_session(Fake(), plan, Path(temp), [])
        self.assertEqual(calls, ['acquire', 'prepare_control', 'stop_motion', 'release'])
        self.assertEqual(result['failure'], 'interrupted')


if __name__ == '__main__':
    unittest.main()
