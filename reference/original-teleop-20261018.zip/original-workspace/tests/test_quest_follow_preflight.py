"""An old remote driver must be rejected before either follower starts."""
import unittest
import contextlib
import io
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from urllib.error import URLError

from 遥操.quest_arm_follow import check_driver, wait_for_driver
from 遥操 import follow


class DriverPreflightTests(unittest.TestCase):
    def test_old_running_driver_is_rejected_by_read_only_request(self):
        with patch('harness.client._get', return_value={'ready': True}) as get:
            with self.assertRaisesRegex(RuntimeError, 'Thor driver is outdated'):
                check_driver(SimpleNamespace(base='http://robot'))
            get.assert_called_once_with('http://robot/ready')

    def test_servo_driver_is_accepted(self):
        ready = {'ready': True, 'capabilities': ['servo_start', 'servo_target', 'servo_status'],
                 'servo':{'distance_limit_policy':'hold'}}
        with patch('harness.client._get', return_value=ready):
            self.assertEqual(check_driver(SimpleNamespace(base='http://robot')), ready)

    def test_throwing_distance_driver_is_rejected_before_control(self):
        ready = {'capabilities':['servo_start','servo_target','servo_status'],
                 'servo':{'workspace_policy':'clamp'}}
        with patch('harness.client._get',return_value=ready):
            with self.assertRaisesRegex(RuntimeError,'limit-hold update'):
                check_driver(SimpleNamespace(base='http://robot'))

    def test_transient_timeouts_wait_and_recover_without_acquiring_control(self):
        ready = {'ready':True,'capabilities':['servo_start','servo_target','servo_status'],
                 'servo':{'distance_limit_policy':'hold'}}
        clock = [0.]
        robot = Mock(base='http://robot')
        messages = io.StringIO()
        with patch('harness.client._get',side_effect=[URLError('timed out'),TimeoutError('timed out'),ready]) as get, \
             patch('遥操.quest_arm_follow.time.monotonic',side_effect=lambda:clock[0]), \
             patch('遥操.quest_arm_follow.time.sleep',side_effect=lambda t:clock.__setitem__(0,clock[0]+t)), \
             contextlib.redirect_stdout(messages):
            self.assertEqual(wait_for_driver(robot),ready)
        self.assertEqual(get.call_count,3)
        self.assertIn('Waiting for Thor driver',messages.getvalue())
        robot.acquire.assert_not_called()
        robot.cap.assert_not_called()

    def test_protocol_failure_is_not_hidden_by_indefinite_retry(self):
        with patch('harness.client._get',return_value={'ready':True}) as get:
            with self.assertRaisesRegex(RuntimeError,'outdated'):
                wait_for_driver(SimpleNamespace(base='http://robot'))
        self.assertEqual(get.call_count,1)

    def test_driver_wait_can_be_cancelled_during_retry(self):
        cancel = Mock(side_effect=[None,KeyboardInterrupt])
        with patch('harness.client._get',side_effect=URLError('offline')), \
             contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(KeyboardInterrupt):
                wait_for_driver(SimpleNamespace(base='http://robot'),cancel)

    def test_launcher_opens_receiver_before_waiting_and_skips_driver_without_stream(self):
        with tempfile.TemporaryDirectory() as folder:
            child = Mock()
            child.poll.side_effect = [None,0,0]
            messages = io.StringIO()
            def wait_for_input(path):
                self.assertTrue(start.called)
                raise KeyboardInterrupt
            with patch.object(follow,'ROOT',Path(folder)), \
                 patch('sys.argv',['follow','--only','arm','--transport','udp','--port','19009']), \
                 patch.object(follow.subprocess,'Popen',return_value=child) as start, \
                 patch.object(follow,'latest_packets',side_effect=wait_for_input), \
                 patch.object(follow.socket,'socket'), \
                 patch('harness.client.Robot') as robot, \
                 contextlib.redirect_stdout(messages):
                follow.main()
            self.assertEqual(start.call_count,1)
            self.assertIn('receive',start.call_args.args[0])
            self.assertIn('Waiting for live Quest',messages.getvalue())
            self.assertNotIn('STOP:',messages.getvalue())
            robot.assert_not_called()


if __name__ == '__main__':
    unittest.main()
