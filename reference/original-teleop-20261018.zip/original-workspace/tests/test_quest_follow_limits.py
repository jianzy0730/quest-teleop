"""Do not hide limit violations from the authoritative robot-side hold."""
import time
import unittest
from unittest.mock import Mock

import numpy as np

from 遥操.quest_arm_follow import target_allowed, recover_mapping


class FollowLimitTests(unittest.TestCase):
    def test_unclamped_pose_reaches_driver_including_rotation(self):
        now = time.time()
        state = {'updated_at':now, 'eef_right':[.5,0,.5,0,0,0,1],
                 'perception':{'ready':True,'streams':{'eef_right':{'source_t':now}}}}
        safety = {'workspace':{'x':[.2,.75],'y':[-.4,.4],'z':[.03,.9]},'max_step_m':.15}
        requested = [.7,-.7,.8,0,0,.6,.8]
        target, limited = target_allowed(requested,state,safety)
        np.testing.assert_array_equal(target, requested)
        self.assertEqual(limited,['y','distance'])
        with self.assertRaises(ValueError):
            target_allowed([float('nan')]*7,state,safety)
        state['perception']['streams']['eef_right']['source_t'] -= 10
        with self.assertRaises(Exception):
            target_allowed(requested,state,safety)

    def test_delayed_feedback_does_not_shift_rotation_zero_while_running(self):
        mapper = Mock()
        self.assertFalse(recover_mapping(mapper, 'wrist', 'actual', 'running'))
        mapper.rebase.assert_not_called()
        for phase in ('paused','awaiting_input'):
            self.assertTrue(recover_mapping(mapper, 'wrist', 'actual', phase))
        self.assertEqual(mapper.rebase.call_count, 2)


if __name__ == '__main__':
    unittest.main()
