"""Offline coordinate and input-failure tests. No robot connection."""
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from 遥操.quest_arm import WristMapper, WristGate, rotation, quaternion


def p(x=0., y=0., z=0., q=(0., 0., 0., 1.)):
    return np.r_[x, y, z, q]


class MappingTests(unittest.TestCase):
    def test_rebase_keeps_axes_and_maps_new_wrist_to_measured_pose(self):
        mapper = WristMapper(p(), p(), p(q=[0, .6, 0, .8]), scale=.5)
        axes = mapper.axes.copy()
        wrist = p(1, 2, 3, quaternion([.3, .4, -.2, .83]))
        actual = p(.4, -.1, .6, quaternion([.2, -.3, .4, .83]))
        mapper.rebase(wrist, actual)
        np.testing.assert_allclose(mapper.map(wrist), actual, atol=1e-12)
        np.testing.assert_array_equal(mapper.axes, axes)
        moved = wrist.copy()
        moved[0] += .1
        np.testing.assert_allclose(mapper.map(moved)[:3], actual[:3]+.05*axes[:,0], atol=1e-12)

    def test_clutch_preserves_arbitrary_robot_pose(self):
        anchor = p(.5, -.2, .6, quaternion([.2, -.3, .4, .83]))
        wrist = p(1., 1.4, -.3, quaternion([.3, .4, -.2, .83]))
        mapper = WristMapper(wrist, anchor, p())
        np.testing.assert_allclose(mapper.map(wrist), anchor, atol=1e-12)

    def test_forward_left_up_and_scale(self):
        mapper = WristMapper(p(), p(), p(), scale=.5)
        for human, robot in ((p(z=.1), [.05,0,0]), (p(x=.1), [0,-.05,0]), (p(y=.1), [0,0,.05])):
            np.testing.assert_allclose(mapper.map(human)[:3], robot, atol=1e-12)

    def test_head_yaw_alignment_stays_fixed_after_calibration(self):
        head = p(q=[0,np.sin(np.pi/4),0,np.cos(np.pi/4)])
        mapper = WristMapper(p(), p(), head)
        np.testing.assert_allclose(mapper.map(p(x=.1))[:3], [.1,0,0], atol=1e-12)

    def test_rotation_matches_reflected_world_delta(self):
        wrist = p(q=quaternion([.3,-.2,.1,.92]))
        anchor = p(.5,-.2,.6,quaternion([-.2,.4,.1,.89]))
        current = p(.1,.2,.3,quaternion([-.4,.3,.2,.83]))
        mapper = WristMapper(wrist, anchor, p(q=[0,.6,0,.8]))
        expected = mapper.axes @ rotation(current[3:]) @ rotation(wrist[3:]).T @ mapper.axes.T @ rotation(anchor[3:])
        actual = rotation(mapper.map(current)[3:])
        np.testing.assert_allclose(actual, expected, atol=1e-12)
        self.assertAlmostEqual(np.linalg.det(actual), 1.)

    def test_quaternion_sign_and_room_translation_invariance(self):
        mapper = WristMapper(p(1,2,3), p(.4,-.2,.6), p())
        a = mapper.map(p(1.1,2.2,3.3,q=[0,0,.6,.8]))
        b = mapper.map(p(1.1,2.2,3.3,q=[0,0,-.6,-.8]))
        np.testing.assert_allclose(a,b,atol=1e-12)
        other = WristMapper(p(8,5,2), p(.4,-.2,.6), p())
        np.testing.assert_allclose(other.map(p(8.1,5.2,2.3,q=[0,0,.6,.8])),a,atol=1e-12)

    def test_reject_invalid_pose_and_head_direction(self):
        for wrist in (p(q=[0,0,0,0]), p(x=np.nan)):
            with self.assertRaises(ValueError): WristMapper(wrist,p(),p())
        with self.assertRaises(ValueError):
            WristMapper(p(),p(),p(q=[np.sqrt(.5),0,0,np.sqrt(.5)]))


class GateTests(unittest.TestCase):
    def packets(self, seq=1, ns=1_000_000_000, offset=0.):
        rec = {'recv_unix_ns': time.time_ns()+int(offset*1e9)}
        debug = {'source_frame_seq':seq, 'source_ts_ns':ns}
        return {key: (rec, {'debug':debug.copy(),'data':{'pose':0}})
                for key in ('Right/wrist','Right/landmarks','Head/pose')}

    def test_stale_and_source_reset_rejected(self):
        with self.assertRaises(TimeoutError): WristGate().accept(self.packets(offset=-1))
        gate = WristGate()
        self.assertTrue(gate.accept(self.packets(seq=3)))
        with self.assertRaises(ValueError): gate.accept(self.packets(seq=2))
        with self.assertRaises(ValueError): gate.accept(self.packets(seq=4))

    def test_pairing_and_duplicate_do_not_advance_gate(self):
        gate = WristGate()
        packets = self.packets()
        packets['Right/landmarks'][1]['debug']['source_frame_seq'] = 0
        self.assertFalse(gate.accept(packets))
        self.assertIsNone(gate.seq)
        packets = self.packets()
        self.assertTrue(gate.accept(packets))
        self.assertFalse(gate.accept(packets))

    def test_fresh_sequence_does_not_mask_frozen_tracking(self):
        gate = WristGate()
        self.assertTrue(gate.accept(self.packets()))
        gate.changed_at = time.monotonic()-1
        with self.assertRaises(TimeoutError): gate.accept(self.packets(seq=2,ns=1_010_000_000))

    def test_transport_backlog_rejected(self):
        gate = WristGate()
        self.assertTrue(gate.accept(self.packets()))
        with patch('遥操.quest_arm.time.time_ns', return_value=time.time_ns()+300_000_000):
            with self.assertRaises(TimeoutError):
                gate.accept(self.packets(seq=2,ns=1_010_000_000))


if __name__ == '__main__':
    unittest.main()
