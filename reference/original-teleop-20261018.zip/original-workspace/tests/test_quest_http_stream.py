"""Test actual keep-alive and ambiguous responses without robot motion."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import socket
import threading
import unittest

from 遥操.http_stream import CapConnection, TransportError


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        self.server.requests.append((body, self.client_address))
        if body['name'] == 'drop_response':
            self.close_connection = True
            self.connection.shutdown(socket.SHUT_RDWR)
            return
        payload = json.dumps({'exit':'success', 'args':body['args']}).encode()
        self.send_response(200)
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)
    def log_message(self, *args):
        pass


class ConnectionTests(unittest.TestCase):
    def setUp(self):
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.server.requests = []
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.connection = CapConnection(f'http://127.0.0.1:{self.server.server_port}', 'test-owner')
    def tearDown(self):
        self.connection.close()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)
    def test_sequential_frames_reuse_connection_with_current_payload(self):
        for seq in range(20):
            result = self.connection.post('servo_target', {'seq':seq})
            self.assertEqual(result['args']['seq'], seq)
        self.assertEqual(len({address for body,address in self.server.requests}), 1)
        self.assertTrue(all(body['by']=='test-owner' for body,address in self.server.requests))
    def test_lost_response_is_not_retried(self):
        with self.assertRaisesRegex(TransportError, 'drop_response HTTP response'):
            self.connection.post('drop_response', {'seq':1})
        self.assertEqual(len(self.server.requests), 1)
        # Reconcile using a sensing operation; do not replay the old target.
        self.connection.post('servo_status', {})
        self.assertEqual(len(self.server.requests), 2)


if __name__ == '__main__':
    unittest.main()
