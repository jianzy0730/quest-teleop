"""Offline geometry tests; requires the isolated WSL retarget environment."""
import sys
from pathlib import Path
import unittest
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from 遥操.quest_hand import QuestRetarget, LiveGate


class RetargetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mapper = QuestRetarget()

    def test_recover_model_open_and_curl(self):
        m = self.mapper
        result = []
        for curl in (0., .6):
            q = np.zeros(20)
            for base in (4,8,12,16):
                q[base:base+4] = [curl, 0, curl, .7*curl]
            p = m.fk(q)*[1,1,-1]
            m.retargeter.reset()
            for _ in range(5):
                recovered = m.solve(p, filtered=False)
            result.append(recovered)
        # All four fingers must curl in their own SDK slots, without swapped
        # fingers or a backwards direction. Thumb is independently oriented.
        for base in (4,8,12,16):
            self.assertGreater(result[1][base]-result[0][base], .3)
            self.assertGreater(result[1][base+2]-result[0][base+2], .25)
        print('open',result[0].round(3),'curl',result[1].round(3))

    def test_rotation_translation_invariance(self):
        from scipy.spatial.transform import Rotation
        m = self.mapper
        p = m.fk(np.full(20,.2))*[1,1,-1]
        m.retargeter.reset()
        a = m.solve(p, filtered=False)
        m.retargeter.reset()
        b = m.solve(p @ Rotation.from_euler('xyz',[.6,.2,-.7]).as_matrix().T + [1,2,3], filtered=False)
        np.testing.assert_allclose(a,b,atol=1e-5)

    def test_invalid_geometry(self):
        for p in (np.zeros((21,3)),np.ones((20,3)),np.full((21,3),np.nan)):
            with self.assertRaises(ValueError):
                self.mapper.solve(p)


if __name__ == '__main__':
    unittest.main()
