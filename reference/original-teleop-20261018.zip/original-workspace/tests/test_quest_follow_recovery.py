"""Run the actual arm follower through gaps and a lost target response offline."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np

from 遥操 import quest_arm_follow as follow
from 遥操 import quest_hand as hand_follow
from 遥操.http_stream import TransportError


class RecoveryTests(unittest.TestCase):
    def test_hand_waits_after_missing_input_and_lost_response(self):
        self.run_hand_recovery()

    def test_hand_explicit_excursion_keeps_original_session_start(self):
        self.run_hand_recovery(max_delta=.15)

    def run_hand_recovery(self, max_delta=None):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder)
            stop = output/'stop'
            robot = Mock(base='http://unused', by='owner')
            robot.release.return_value = {'released':True}
            initial = {'exit':'success','session_id':'session','phase':'awaiting_input',
                       'start_rad':[.1]*20,'actual_rad':[.1]*20}
            robot.cap.side_effect = lambda name,*a,**kw: ({**initial,'phase':'stopped'}
                if name == 'stream_status' else initial)
            mapper = Mock(mapping={}, retargeter=SimpleNamespace(rotation_xyz={}))
            mapper.limits = np.array([[-1.,1.]]*20)
            poses = {}
            counter = [0]
            gate = SimpleNamespace(seq=0)
            def latest(path):
                counter[0] += 1
                if counter[0] == 21:
                    raise FileNotFoundError('temporary missing input')
                if counter[0] > 60:
                    self.fail('hand did not recover')
                if counter[0] <= 20:
                    time.sleep(.055)
                gate.seq = counter[0]
                return {'recv_unix_ns':time.time_ns()}, {'data':{'points':[]}}
            def accept(*args):
                if counter[0] == 22:
                    raise TimeoutError('temporary stale input')
                return True
            gate.accept = accept
            targets = []
            def solve(points):
                # Bent fingers at startup; changing curl on recovery must not
                # become a new zero. Include targets above model limits.
                q = np.linspace(.5, 1.2, 20) + counter[0]*.005
                poses[gate.seq] = q.copy()
                return q
            mapper.solve.side_effect = solve
            def post(name,args,timeout=.5):
                if name == 'stream_status':
                    return initial if not targets else {**initial,'phase':'paused','actual_rad':[.2]*20}
                targets.append(args)
                if len(targets) == 1:
                    raise TransportError('response lost')
                if len(targets) == 2:
                    return {'exit':'success','completion':'rebase_required','actual_rad':[.2]*20,'phase':'rebasing'}
                stop.touch()
                return {**initial,'phase':'running','completion':'target_accepted'}
            connection = Mock()
            connection.post.side_effect = post
            extra = [] if max_delta is None else ['--max-delta',str(max_delta)]
            with patch('sys.argv', ['follow','--execute','--capture',str(output/'capture'),'--output',str(output),'--stop-file',str(stop)]+extra), \
                 patch('harness.client.Robot', return_value=robot), \
                 patch.object(hand_follow, 'QuestRetarget', return_value=mapper), \
                 patch.object(hand_follow, 'CapConnection', return_value=connection), \
                 patch.object(hand_follow, 'LiveGate', return_value=gate), \
                 patch('harness.client._post', return_value={**initial,'phase':'stopped'}), \
                 patch.object(hand_follow, 'latest_right', side_effect=latest), \
                 contextlib.redirect_stdout(io.StringIO()):
                hand_follow.main()
            self.assertEqual(robot.acquire.call_count, 1)
            self.assertEqual(len(targets), 3)
            self.assertEqual(len({x['seq'] for x in targets}), 3)
            self.assertGreater(counter[0], 22)
            for sent in targets:
                expected = np.clip(poses[sent['seq']], -1, 1) if max_delta is None else np.full(20, .25)
                np.testing.assert_allclose(sent['positions_rad'], expected)
            logs = [json.loads(line) for line in next(output.glob('follow_*.jsonl')).read_text().splitlines()]
            self.assertEqual(logs[-1]['mapping_mode'], 'absolute')
            np.testing.assert_allclose(logs[-1]['target_rad'], targets[-1]['positions_rad'])
            self.assertTrue(any((row.get('stream') or {}).get('completion') == 'rebase_required' for row in logs))
            robot.release.assert_called_once()

    def test_input_gap_and_unknown_target_outcome_wait_and_rebase(self):
        self.run_arm_recovery(distance_rejection=False)

    def test_distance_hold_from_driver_continues_without_rebase(self):
        self.run_arm_recovery(distance_rejection=True)

    def run_arm_recovery(self, distance_rejection):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder)
            stop = output/'stop'
            pose = [.5, -.2, .6, 0, 0, 0, 1]
            def state():
                return {'updated_at':time.time(), 'eef_right':pose,
                        'perception':{'ready':True,'streams':{'eef_right':{'source_t':time.time()}}}}
            robot = Mock(base='http://unused', by='owner')
            robot.release.return_value = {'released':True}
            robot.safety = {'workspace':{'x':[.2,.75], 'y':[-.4,.4], 'z':[.03,.9]}, 'max_step_m':.15}
            robot.policy_observe.side_effect = lambda **kw: {'state':state()}
            robot.cap.side_effect = lambda name,args: ({'exit':'success','control':{'prepared':True}}
                if name == 'control_state' else {'exit':'success','session_id':'session'})
            gate = SimpleNamespace(seq=0)
            counter = [0]
            def latest(path):
                counter[0] += 1
                if counter[0] == 3:
                    raise FileNotFoundError('capture temporarily missing after preparation')
                if counter[0] > 20:
                    self.fail('follower did not recover')
                rec = {'recv_unix_ns':time.time_ns()}
                wrist = dict(zip(('x','y','z','qx','qy','qz','qw'), [0,0,counter[0]*.001,0,0,0,1]))
                return {'Right/wrist':(rec,{'data':wrist}), 'Head/pose':(rec,{'data':wrist})}
            def accept(packets, calibration=False):
                gate.seq += 1
                if counter[0] == 5:
                    raise TimeoutError('input temporarily stale')
                return True
            gate.accept = accept
            targets = []
            statuses = []
            def post(name,args,timeout=.5):
                if name == 'servo_status':
                    statuses.append(counter[0])
                    return {'exit':'success','phase':'paused','eef_right':pose,'source_t':time.time()}
                targets.append(args)
                if len(targets) == 1:
                    if distance_rejection:
                        return {'exit':'success','completion':'target_held',
                                'target_pose':pose,'limited_axes':['distance'],
                                'eef_right':pose,'source_t':time.time()}
                    raise TransportError('response lost after possible acceptance')
                stop.touch()
                return {'exit':'success','completion':'target_accepted', 'eef_right':pose,
                        'source_t':time.time(), 'target_pose':args['pose']}
            connection = Mock()
            connection.post.side_effect = post
            with patch('sys.argv', ['follow','--capture',str(output/'capture'),'--output',str(output),'--stop-file',str(stop)]), \
                 patch('harness.client.Robot', return_value=robot), \
                 patch.object(follow, 'wait_for_driver'), \
                 patch.object(follow, 'CapConnection', return_value=connection), \
                 patch.object(follow, 'WristGate', return_value=gate), \
                 patch.object(follow, 'latest_packets', side_effect=latest), \
                 contextlib.redirect_stdout(io.StringIO()):
                follow.main()
            self.assertEqual(robot.acquire.call_count, 1)
            self.assertEqual(len(targets), 2)
            self.assertGreater(targets[1]['seq'], targets[0]['seq'])
            self.assertTrue(any(i > 5 for i in statuses))
            # A successful limit hold must keep the original mapping; only
            # uncertain transport followed by a paused status reclutches.
            delta = .002 if distance_rejection else .001
            np.testing.assert_allclose(targets[1]['pose'][:3], np.array(pose[:3])+[delta,0,0], atol=1e-12)
            robot.release.assert_called_once()
            connection.close.assert_called_once()


if __name__ == '__main__':
    unittest.main()
