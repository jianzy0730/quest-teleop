"""Separate slow SDK startup from live target timing without a connected hand."""
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from 遥操.quest_hand import checked


class HandRequestTests(unittest.TestCase):
    def test_start_has_initialization_budget_and_definite_busy_can_retry(self):
        busy = {'exit':'busy', 'completion':'not_started'}
        robot = SimpleNamespace(cap=Mock(return_value=busy))
        self.assertEqual(checked(robot, 'stream_start', {'side':'right'}), busy)
        self.assertEqual(robot.cap.call_args.kwargs['timeout'], 10.)

    def test_live_target_budget_unchanged_and_timeout_names_operation(self):
        robot = SimpleNamespace(base='http://robot', by='test')
        with patch('harness.client._post', side_effect=TimeoutError('timed out')) as post:
            with self.assertRaisesRegex(RuntimeError, 'stream_target.*HTTP timeout 0.2s'):
                checked(robot, 'stream_target', {})
            self.assertEqual(post.call_args.kwargs['timeout'], .2)

    def test_initialization_timeout_is_not_retried(self):
        robot = SimpleNamespace(cap=Mock(side_effect=TimeoutError('timed out')))
        with self.assertRaisesRegex(RuntimeError, 'stream_start.*HTTP timeout 10.0s'):
            checked(robot, 'stream_start', {})
        robot.cap.assert_called_once()


if __name__ == '__main__':
    unittest.main()
