"""Compatibility entry point. Implementation: 遥操/quest_arm.py."""
from importlib import import_module
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
_module = import_module('遥操.quest_arm')
if __name__ == '__main__':
    _module.main()
else:
    sys.modules[__name__] = _module
