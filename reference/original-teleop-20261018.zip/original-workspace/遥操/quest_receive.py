"""Inspect and record HTS UDP/TCP telemetry. Does not connect to robot drivers.

Run with .venv-quest/Scripts/python.exe -m 遥操 receive.
Coordinates are kept in the sender's Unity convention; no robot mapping is applied.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import ExitStack
from dataclasses import asdict
import json
import math
from pathlib import Path
import socket
import time

def inspect_packet(packet):
    """Validate numeric geometry and return a diagnostic payload."""
    from hand_tracking_sdk.models import LandmarksPacket, WristPacket

    data = packet.data.to_dict()
    if isinstance(packet, LandmarksPacket):
        values = [v for point in packet.data.points for v in point]
    else:
        values = list(data.values())
    if not all(math.isfinite(v) for v in values):
        raise ValueError("non-finite geometry")
    if isinstance(packet, WristPacket):
        q = packet.data
        norm = math.sqrt(q.qx**2 + q.qy**2 + q.qz**2 + q.qw**2)
        if not 0.9 <= norm <= 1.1:
            raise ValueError(f"invalid quaternion norm {norm}")
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--transport", choices=["udp", "tcp"], default="udp")
    parser.add_argument("--port", type=int)
    parser.add_argument("--peer", help="Only accept datagrams from this IP")
    parser.add_argument("--duration", type=float, default=300, help="0: receive until Ctrl+C")
    parser.add_argument("--output", type=Path, default=Path("live/quest"))
    parser.add_argument("--capture", type=Path, help='Explicit output recording path')
    parser.add_argument("--stop-file", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    # Keep the command dispatcher and --help usable from the base Windows
    # environment; the SDK is installed only in .venv-quest.
    from hand_tracking_sdk.exceptions import (ParseError,
                                               TransportDisconnectedError,
                                               TransportTimeoutError)
    from hand_tracking_sdk.parser import parse_line
    from hand_tracking_sdk.transport import TCPServerConfig, TCPServerLineReceiver
    if args.port is None:
        args.port = 8000 if args.transport == "tcp" else 9000
    if args.peer and args.transport == "tcp":
        parser.error("--peer is available only for UDP; bind TCP to --host 127.0.0.1 for USB")
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error("duration must be finite and nonnegative; 0 means until Ctrl+C")
    args.output.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    capture = args.capture or args.output / f"capture_{stamp}.jsonl"
    capture.parent.mkdir(parents=True, exist_ok=True)
    summary_path = args.output / f"summary_{stamp}.json"
    counts, window = Counter(), Counter()
    latest, last_seen, peers = {}, {}, set()
    errors = 0
    started = last_report = time.monotonic()
    with ExitStack() as stack:
        out = stack.enter_context(capture.open("x", encoding="utf-8", buffering=1))
        if args.transport == "udp":
            sock = stack.enter_context(socket.socket(socket.AF_INET, socket.SOCK_DGRAM))
            sock.bind((args.host, args.port))
            sock.settimeout(0.25)
        else:
            receiver = stack.enter_context(TCPServerLineReceiver(TCPServerConfig(
                host=args.host, port=args.port, accept_timeout_s=0.25, read_timeout_s=0.25)))
        print(f"Listening {args.transport.upper()} {args.host}:{args.port}; record: {capture}", flush=True)
        try:
            while args.duration == 0 or time.monotonic() - started < args.duration:
                if args.stop_file and args.stop_file.exists():
                    break
                address = None
                try:
                    if args.transport == "udp":
                        payload, address = sock.recvfrom(65535)
                    else:
                        payload = receiver.recv_line().encode("utf-8")
                except (socket.timeout, TransportTimeoutError, TransportDisconnectedError):
                    payload = None
                except UnicodeDecodeError:
                    errors += 1
                    payload = None
                if payload is not None and (not args.peer or address[0] == args.peer):
                    peers.add(address[0] if address else "tcp_client")
                    received_ns = time.monotonic_ns()
                    record = {"recv_monotonic_ns": received_ns, "recv_unix_ns": time.time_ns(),
                              "peer": list(address) if address else None,
                              "raw": payload.decode("utf-8", "replace")}
                    packets = []
                    for line in record["raw"].splitlines():
                        if not line.strip():
                            continue
                        try:
                            packet = parse_line(line)
                            data = inspect_packet(packet)
                        except (ParseError, ValueError) as exc:
                            errors += 1
                            packets.append({"error": str(exc)})
                            continue
                        key = f"{packet.side.value}/{packet.kind.value}"
                        counts[key] += 1
                        window[key] += 1
                        last_seen[key] = time.monotonic()
                        latest[key] = data
                        packets.append({"key": key, "data": data,
                                        "debug": asdict(packet.debug) if packet.debug else None})
                    record["packets"] = packets
                    out.write(json.dumps(record, allow_nan=False) + "\n")
                now = time.monotonic()
                if now - last_report >= 2:
                    report = {key: {"packets_per_s": round(window[key] / (now - last_report), 1),
                                    "age_s": round(now - last_seen[key], 2)} for key in counts}
                    wrists = {key: value for key, value in latest.items() if key.endswith("/wrist")}
                    print(json.dumps({"peers": sorted(peers), "streams": report,
                                      "wrists_unity": wrists, "errors": errors}), flush=True)
                    out.flush()
                    window.clear()
                    last_report = now
        except KeyboardInterrupt:
            pass
    summary = {"elapsed_s": round(time.monotonic() - started, 2), "peers": sorted(peers),
               "valid_packets": dict(counts), "parse_errors": errors,
               "latest_unity": latest, "capture": str(capture),
               "note": "Packet arrival rates are not source frame rates or latency measurements."}
    summary_path.write_text(json.dumps(summary, indent=2, allow_nan=False), encoding="utf-8")
    print(f"Saved {summary_path}", flush=True)


if __name__ == "__main__":
    main()
