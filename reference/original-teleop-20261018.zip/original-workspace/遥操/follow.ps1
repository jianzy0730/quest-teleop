# Run from any PowerShell working directory. Ctrl+C stops the session.
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location -LiteralPath $projectRoot
try {
    & 'C:\ProgramData\miniconda3\python.exe' -u -m (Split-Path -Leaf $PSScriptRoot) follow @args
    $followExitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
exit $followExitCode
