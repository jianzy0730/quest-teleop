# Quest 遥操

从任意 PowerShell 目录启动右臂 XYZ + 旋转、Wuji 右手跟随：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\jianziYu\桌面\天机\遥操\follow.ps1"
```

也可以从项目根目录运行 `C:\ProgramData\miniconda3\python.exe -u -m 遥操 follow`。
先运行接收命令，再在 Quest 中 Start Streaming；TCP `127.0.0.1:8000`，Video Feed 关闭，Head Pose、Debug Info 开启。
保持右手可见，启动校准以当前手腕和机器人末端为零点；Ctrl+C 停止并释放两侧控制权。

默认不加手指软件速度斜坡，低通参数为 `--filter-alpha 1.0`（不额外平滑）；机械臂位置和旋转默认 1:1。
手指使用绝对姿态跟随：直接发送当前 retarget 关节角，不扣除启动时人手弯曲角度；启动后会跟到当前手势。
可追加 `--only hand` 或 `--only arm` 单测，`--preview` 只预览，`--scale 0.5` 缩放手腕平移。
设备关节限位和 Harness 工作空间仍生效。
XYZ 超出工作空间时目标夹到边界，终端限频提示 WARNING，手移回范围内自动继续；
手指目标也夹到已有模型关节限位并提示。Quest 输入中断、过期或冻结时暂停等待，程序保持运行；
超过 250 ms 没有新目标时，手臂清除旧目标，手指保持当前位置。恢复新鲜输入后，机械臂以当前机器人姿态重新对齐，手指继续跟随最新绝对手势。
HTTP 短暂超时也等待恢复，通过状态查询核对设备后继续，不重发结果未知的旧目标。
单步位移异常、机器人反馈失联、租约丢失及驱动故障仍停止；Ctrl+C 停止后不会自动恢复。
Wuji 初始化 HTTP 等待预算为 10 秒，实时目标仍为 0.2 秒，不增加手指速度限制；
实时请求复用 HTTP 连接，通信错误会标出具体 stream_start / stream_status / stream_target 请求。

启动时先检查 Thor 运行端是否提供 `servo_start` / `servo_target` / `servo_status`，旧版本会在启动两个跟随器之前报出缺失接口。
2026-10-16 已部署并验证真实 `servo_start` 与无输入超时；Wuji 服务也已重启，验证默认 `max_velocity_rad_s=null`。
同日 16:59 已部署 Thor 工作空间夹紧，`/ready` 的 `servo.workspace_policy=clamp`；
边界夹紧、反复越界及回到范围内恢复已经离线测试，尚未用 Quest 实机验证这一版。
这次修复尚未验证 Quest 同时驱动手臂与手指的实机连续跟随。
2026-10-16 17:22 已部署 Thor `servo_status`、输入超时暂停及 HTTP 持续连接，并重启 Wuji 服务。
启动前接口检查通过；Thor 持续连接只读检查 500 次无错误，平均 1.80 ms，最大 5.14 ms。
部署后控制反馈仍为 `[1,1] / input=1 / ik_source=2`，两侧无租约；这一版尚未验证 Quest 实机连续跟随。
部署和检查记录：[pause_deploy_20261016_172204](../live/quest/pause_deploy_20261016_172204/verification.json)。
端口占用时先在旧接收器或旧 follow 终端 Ctrl+C；已有接收器可通过 `--capture <其正在写入的文件>` 复用。

与 `harness/` 同级的遥操作适配层。负责 Quest 输入、坐标转换、手部重定向和跟随会话；机器人控制通过 Harness 的租约和驱动能力执行。

| 文件 | 功能 | 当前状态 |
| --- | --- | --- |
| `quest_receive.py` | USB TCP / Wi-Fi UDP 接收与录制 | 已验证 |
| `quest_hand.py` | Wuji Hand 2 右手重定向、跟随和停止清理 | 已验证右手运动 |
| `quest_arm.py` | wrist XYZ + 四元数 → 天机右末端相对位姿 | 预览与共用映射 |
| `quest_arm_follow.py` | wrist 实时跟随，通过 Thor servo 接口发送目标 | 已部署接口，待连续联调 |
| `follow.py` / `follow.ps1` | 一条命令启动接收和两个跟随器 | USB 自动反向转发，Ctrl+C 清理 |
| `quest_arm_replay.py` | 已录制 wrist 的有界采样回放、位置及旋转反馈核验 | 2026-10-16 已验证右臂实际运动 |
| `__main__.py` | `receive` / `hand` / `arm` / `arm-replay` 命令入口 | 按需加载对应环境依赖 |

代码在本目录维护。`tools/quest_*.py` 保留为兼容入口，已有命令仍可用。运行数据继续写入 `live/quest/`，驱动与设备参数继续在 `robots/`；后续机械臂流式适配和联动会话在这里扩展，通过 Harness 对接设备端能力。

## 运行

以下命令从项目根目录 `C:\jianziYu\桌面\天机` 执行。Windows 接收环境和 WSL 手部重定向环境沿用现有安装，不需要重新安装依赖。

USB 接收（已有接收器运行时复用它）：

```powershell
adb reverse tcp:8000 tcp:8000
.\.venv-quest\Scripts\python.exe -m 遥操 receive --transport tcp --host 127.0.0.1 --port 8000 --duration 0
```

头显选择 TCP、`127.0.0.1:8000`，开启 Head Pose 和 Debug Info，关闭 Video Feed。

`follow.ps1` 先启动接收器，无限等待 Quest 开流；等待期间不获取机器人控制权。
收到实时数据后检查天机连接；连接超时、拒绝连接或服务暂未就绪时持续重试，
终端显示 `Waiting for Thor driver`，Ctrl+C 可结束。驱动恢复后重新检查输入新鲜度，
再启动跟随。驱动版本不兼容仍明确报错，避免把需要更新的问题当成网络等待。

天机腕部映射预览，默认使用最新 capture 和新鲜机器人末端位姿作起点：

```powershell
C:\ProgramData\miniconda3\python.exe -m 遥操 arm
```

初始平视方向映射为机器人 +X，人体右侧对应 −Y，上方对应 +Z；旋转以启动姿态为零点。这个命令不发送机械臂运动，尚未做实机方向验证，也没有 wrist 到掌心的 TCP 偏移标定。

Wuji 右手跟随，把 capture 文件名换为当前接收器输出：

```powershell
wsl.exe -d Ubuntu-22.04 -- /home/jianziyu/.venv-quest-retarget/bin/python -u '/mnt/c/jianziYu/桌面/天机/遥操/quest_hand.py' --capture '/mnt/c/jianziYu/桌面/天机/live/quest/capture_YYYYMMDD_HHMMSS.jsonl' --execute
```

去掉 `--execute` 即只预览。手部跟随默认运行到 Ctrl+C；接收命令使用 `--duration 0`。实时跟随输入过期或追踪冻结时暂停等待，新鲜输入恢复后继续绝对姿态跟随。手指默认使用已有模型关节限位，不增加相对起点角度限制。
日志包含 `mapping_mode=absolute`、`retarget_rad`、`requested_rad`、`target_rad` 与驱动反馈；可区分拟合不足、目标限位和实际未到位。显式传入 `--max-delta` 时，仍按驱动会话原始起点限制测试幅度。

2026-10-16：修复 `position_limit_active=True`、错误码为 0 时误停整个跟随的问题。
流式驱动根据此前已发送目标与反馈判断触限方向，将该方向目标夹到当时测量位置，
本次会话内保留边界，允许反向退回，其他手指继续跟随；终端输出限位警告。
启动时已有限位标志且无法判断方向的关节保持当前位置，直到标志清除；不猜测方向。
真实电机错误、异常状态和设备反馈失联仍停止。未改变固件限位或增加速度限制。
已通过离线触限/退回/故障测试；这一行为尚待 Quest 实机验证。

2026-10-16：遥操流式驱动按官方 SDK `describe_error` 的严重等级处理诊断。
`Warning`（包括 `3 / Enc1BitRate`）只记录并限频提示，继续跟随，
不会再导致启动失败或失能验证误报；失能仍需确认全部关节到达 Ready。
`DeferredStop`、`ImmediateStop`、`Fatal`、未知错误码及异常电机状态仍停止。
`stream_status` 提供 `diagnostic_warning_policy=warn_and_continue` 和当前 `diagnostic_warnings`。
同日：手指目标与实测相差超过 0.25 rad 持续 500 ms 改为只提示跟随误差，
不再抛异常结束会话；恢复后提示自动清除。日志记录 `tracking_warning` 的关节、
最大误差和持续时间，运行端提供 `tracking_error_policy=warn_and_continue`。
固件位置限位仍夹紧并允许退回；真实停机级诊断、异常状态、反馈失联和租约检查仍生效。

2026-10-16 17:56：已将机械臂限位保持部署到 Thor 驱动。目标超出工作空间或
距离实测末端超过现有 15 cm 范围时，锁定触限时的实测整个位姿，输出警告，
不抛异常、不退出会话。连续超限时保持同一目标，回到有效范围后自动继续。
电脑直接传递原始映射目标，由机器人端根据实时反馈判断限位，避免两次反馈间
移动造成的超距竞态；普通限位不重新设置 wrist 零点。真实故障仍停止。
这取代此前仅在电脑端夹紧的修复；此前机器人端异常仍会关闭会话。

旋转与 XYZ 在同一目标中发送，旋转比例为 1:1。修复了连接延迟但会话仍运行时
重新设置旋转零点的问题；只有机器人确实因断流暂停后才重新对齐。
当前是相对启动姿态的世界坐标旋转映射，不是已标定的掌心/TCP 绝对姿态。
旧录制出现过约 65° 的目标/实际旋转差，尚不能确定全部来自延迟、IK 可达性或
初始对齐；没有凭观察猜测翻转轴或修改 IK 参数。新日志记录原始 wrist、目标、
实测位姿、恢复/重新对齐事件，供下一轮实机核验。

已通过离线限位/退回/HTTP 异常路径及坐标映射测试；已核对机器人端源文件
哈希、就绪状态和控制设置。部署未发送运动目标，本次改动尚待 Quest 实机验证。
部署证据：[deployment.json](../live/quest/arm_hold_deploy_20261016_175606/deployment.json)。

查看各入口参数：`python -m 遥操 --help`，或在对应 Python 环境运行 `receive --help`、`hand --help`、`arm --help`。

完整连接排障、环境版本和实测记录见 [Quest 设置](../docs/QUEST_SETUP.md)。

## 录制数据驱动右臂

不连接 Quest 也可以回放已有录制。从当前末端位姿重新建立相对映射：

```powershell
C:\ProgramData\miniconda3\python.exe -u -m 遥操 arm-replay --capture live/quest/capture_20261016_141953.jsonl --execute
```

去掉 `--execute` 只写计划。默认截取 1 秒录制，位置比例 0.4、旋转比例 0.03，
生成有界采样目标；这是短轨迹验证，尚不是实时连续跟随。Ctrl+C 停止并释放本次租约。
每次运行都以当前机器人位姿为起点，再次运行会叠加相对运动。

2026-10-16 16:01 实机验证通过：实际位移约 27.95 mm，其中 Z 下降 25.62 mm；
执行中连续三个新反馈样本通过 2 mm / 0.5° 核验，最后位置误差 0.427 mm、
旋转误差 0.267°。模式反馈为 `[1,1] / input=1 / ik_source=2`，本次准备步骤
`changed=[]`，未切换设置。已清空保持目标并释放租约。
证据：[回放事件](../live/quest/arm_replay_20261016_160126/events.jsonl)、
[结束后检查](../live/quest/arm_replay_20261016_160126/postcheck.json)。

此前失败时，IK 请求已到达复用器输出，但没有 IK 结果和 QP 关节输出。
恢复 `apex-teleop` 服务、用户重新设置控制路径后本次通过；尚未区分恢复服务与
重新选择输入各自的影响，不能据此认定某一个动作是唯一修复原因。

## 离线验证

```powershell
C:\ProgramData\miniconda3\python.exe -m unittest discover -s tests -p test_quest_arm.py -v
wsl.exe -d Ubuntu-22.04 -- /home/jianziyu/.venv-quest-retarget/bin/python -m unittest discover -s '/mnt/c/jianziYu/桌面/天机/tests' -p test_quest_retarget.py -v
```
