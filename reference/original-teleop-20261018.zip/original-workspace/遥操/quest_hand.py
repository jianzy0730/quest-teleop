"""Quest right-hand preview and Wuji Hand 2 follow, stopped with Ctrl+C.

Run in the isolated WSL retarget environment. Preview is the default. Recorded
replay can only be used for offline inspection; execute requires fresh input.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
VENDOR = ROOT / 'live/vendor/wuji-retargeting'
sys.path.insert(0, str(VENDOR))

import numpy as np
import yaml

from 遥操.http_stream import CapConnection, TransportError


class QuestRetarget:
    def __init__(self, filter_alpha=1.):
        from wuji_retargeting import Retargeter
        from wuji_retargeting.mediapipe import estimate_frame_from_hand_points, OPERATOR2MANO_RIGHT
        from scipy.spatial.transform import Rotation
        config = yaml.safe_load((VENDOR / 'example/config/adaptive_analytical_wuji_glove_wuji_hand_2_right.yaml').read_text())
        config['__yaml_dir'] = str(VENDOR / 'example/config')
        config['retarget']['thumb_skip_pip'] = False
        if not math.isfinite(filter_alpha) or not 0 < filter_alpha <= 1:
            raise ValueError('filter alpha must be in (0,1]')
        config['retarget']['lp_alpha'] = filter_alpha
        self.retargeter = Retargeter.from_config(config, 'right')
        robot = self.retargeter.optimizer.robot
        fingers = ['thumb', 'index_finger', 'middle_finger', 'ring_finger', 'pinky']
        expected = []
        for f in fingers:
            suffixes = ['cmc_flex', 'cmc_abd', 'mcp', 'ip'] if f == 'thumb' else ['mcp_flex', 'mcp_abd', 'pip', 'dip']
            expected.extend(f'r_{f}_{s}' for s in suffixes)
        self.order = []
        for name in expected:
            joint_id = robot.model.getJointId(name)
            if joint_id >= robot.model.njoints or robot.model.joints[joint_id].nq != 1:
                raise RuntimeError('unexpected Hand 2 model joint: ' + name)
            self.order.append(int(robot.model.joints[joint_id].idx_q))
        if sorted(self.order) != list(range(20)):
            raise RuntimeError('Hand 2 model joint mapping is not bijective')
        self.frame_names = ['r_wrist'] + [f'r_{f}_{link}' for f in fingers for link in ['proximal_abd', 'middle', 'distal', 'tip']]
        model_points = self.fk(np.zeros(20))
        # Derive canonical-to-model rotation from the model's own palm frame.
        # It is device independent and also removes the model palm's slight tilt.
        rotation = estimate_frame_from_hand_points(model_points) @ OPERATOR2MANO_RIGHT
        angles = Rotation.from_matrix(rotation).as_euler('xyz', degrees=True)
        self.retargeter.rotation_xyz = dict(zip('xyz', angles.tolist()))
        driver_config = yaml.safe_load((ROOT/'robots/wuji-hand/manifest.yaml').read_text(encoding='utf-8'))
        self.limits = np.asarray(driver_config['gestures']['joint_limits_rad'])
        if not np.allclose(robot.joint_limits[self.order], self.limits, atol=1e-6):
            raise RuntimeError('retarget model and driver joint limits differ')
        self.mapping = dict(zip(expected, self.order))

    def fk(self, q_sdk):
        robot = self.retargeter.optimizer.robot
        q = np.zeros(20)
        q[self.order] = q_sdk
        robot.compute_forward_kinematics(q)
        return np.array([robot.get_link_pose(robot.get_link_index(n))[:3, 3] for n in self.frame_names])

    @staticmethod
    def validate(points):
        p = np.asarray(points, dtype=float)
        if p.shape != (21, 3) or not np.all(np.isfinite(p)):
            raise ValueError('21 finite xyz keypoints required')
        palm_a, palm_b = p[5]-p[0], p[9]-p[0]
        if not .03 < np.linalg.norm(palm_a) < .18 or not .03 < np.linalg.norm(palm_b) < .18:
            raise ValueError('invalid palm size / units')
        if np.linalg.norm(np.cross(palm_a, palm_b)) < .00015:
            raise ValueError('degenerate palm geometry')
        for base in (1, 5, 9, 13, 17):
            lengths = np.linalg.norm(np.diff(p[base:base+4], axis=0), axis=1)
            if np.any(lengths < .006) or np.any(lengths > .085):
                raise ValueError('invalid finger geometry')
        return p

    def solve(self, points, filtered=True):
        # Unity is left handed. Reflect once before constructing the anatomical
        # right-handed palm frame. Points are wrist-local metres already.
        p = self.validate(points) * [1, 1, -1]
        q = self.retargeter.retarget(p, apply_filter=filtered)[self.order]
        if q.shape != (20,) or not np.all(np.isfinite(q)):
            raise ValueError('invalid retarget output')
        if np.any(q < self.limits[:, 0]-1e-6) or np.any(q > self.limits[:, 1]+1e-6):
            raise ValueError('retarget output outside model limits')
        return np.clip(q, self.limits[:, 0], self.limits[:, 1])


def latest_right(path):
    """Read only a bounded tail; never work through an old frame backlog."""
    with path.open('rb') as f:
        f.seek(0, 2)
        size = f.tell()
        start = max(0, size-65536)
        f.seek(start)
        lines = f.read().split(b'\n')
    if start:
        lines = lines[1:]
    for line in reversed(lines[:-1]):  # exclude partially written last line
        try:
            rec = json.loads(line)
            for packet in rec['packets']:
                if packet.get('key') == 'Right/landmarks':
                    return rec, packet
        except (ValueError, KeyError):
            continue
    raise ValueError('no right-hand landmarks in latest input')


class LiveGate:
    def __init__(self):
        self.seq = self.source_ns = None
        self.offset = None
        self.last_pose = None
        self.changed_at = time.monotonic()

    def accept(self, rec, packet):
        age = (time.time_ns()-rec['recv_unix_ns'])/1e9
        if not -.1 <= age <= .2:
            raise TimeoutError(f'Quest input age {age:.3f}s; live input required')
        dbg = packet.get('debug') or {}
        seq, source_ns = dbg.get('source_frame_seq'), dbg.get('source_ts_ns')
        if not isinstance(seq, int) or not isinstance(source_ns, int):
            raise ValueError('enable Debug Info in the Quest app')
        if self.seq is not None:
            if seq == self.seq:
                return False
            if seq < self.seq or source_ns <= self.source_ns:
                raise ValueError('Quest source reset or timestamp did not advance')
        offset = (rec['recv_unix_ns']-source_ns)/1e9
        self.offset = offset if self.offset is None else min(self.offset, offset)
        if offset-self.offset > .15:
            raise TimeoutError('Quest source accumulated >150ms transport backlog')
        points = packet['data']['points']
        if points != self.last_pose:
            self.changed_at = time.monotonic()
            self.last_pose = points
        elif time.monotonic()-self.changed_at > .75:
            raise TimeoutError('Quest pose frozen >750ms; tracking validity unavailable')
        self.seq, self.source_ns = seq, source_ns
        return True


def checked(robot, name, args=None, timeout=None, connection=None):
    timeout = timeout if timeout is not None else (.2 if name == 'stream_target' else 10.)
    request_id = f'quest-{name}-{uuid.uuid4().hex}'
    begun = time.monotonic()
    try:
        if name in ('stream_target', 'stream_status'):
            # Avoid synchronous blackboard tracing between live targets.
            if connection is not None:
                result = connection.post(name, args or {}, timeout=timeout)
            else:
                from harness.client import _post
                result = _post(robot.base+'/cap', {'name':name, 'args':args or {},
                               'by':robot.by, 'request_id':request_id}, timeout=timeout)
        else:
            result = robot.cap(name, args, timeout=timeout, request_id=request_id)
    except (TimeoutError, OSError) as exc:
        raise RuntimeError(f'{name} after {time.monotonic()-begun:.3f}s (HTTP timeout {timeout}s): {exc}') from exc
    if name == 'stream_start' and result.get('exit') == 'busy' and result.get('completion') == 'not_started':
        return result
    if result.get('exit') != 'success':
        raise RuntimeError(f'{name}: {result}')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--duration', type=float, default=0, help='0: run until Ctrl+C; otherwise 1..30 seconds')
    parser.add_argument('--max-delta', type=float, default=None, help='Optional test excursion (0,.25] rad; default uses model limits')
    parser.add_argument('--velocity', type=float, default=None, help='Optional software slew rate in rad/s; default sends latest retarget target directly')
    parser.add_argument('--filter-alpha', type=float, default=1., help='Upstream retarget low pass: default 1 disables smoothing')
    parser.add_argument('--stop-file', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--owner', default=None, help=argparse.SUPPRESS)
    parser.add_argument('--replay', action='store_true', help='Offline preview only')
    parser.add_argument('--output', type=Path, default=ROOT/'live/quest')
    args = parser.parse_args()
    if (args.duration != 0 and not 1 <= args.duration <= 30) or (args.max_delta is not None and not 0 < args.max_delta <= .25) or (args.velocity is not None and (not math.isfinite(args.velocity) or args.velocity <= 0)) or (args.replay and args.execute):
        parser.error('duration 0 or 1..30, optional max-delta (0,.25], positive velocity; replay cannot execute')
    mapper = QuestRetarget(args.filter_alpha)
    print(json.dumps({'joint_mapping':mapper.mapping, 'rotation':mapper.retargeter.rotation_xyz}), flush=True)
    args.output.mkdir(parents=True, exist_ok=True)
    log_path = args.output / ('follow_' + time.strftime('%Y%m%d_%H%M%S') + '.jsonl')
    robot = None
    connection = None
    status = None
    gate = LiveGate()
    session_id = start = None
    status_ready = False
    enabled_at = None
    begun = time.monotonic()
    preview_samples = 0
    last_report = 0
    last_warning = -math.inf
    previous_limits = []
    last_hardware_warning = -math.inf
    previous_hardware_limits = None
    previous_diagnostic_warnings = None
    last_diagnostic_warning = -math.inf
    last_tracking_warning = -math.inf
    last_pause_report = -math.inf
    failure = None
    timing = {}
    try:
        with log_path.open('w') as log:
            while args.duration == 0 or time.monotonic()-begun < args.duration + (15 if args.execute else 0):
                if args.stop_file and args.stop_file.exists():
                    break
                try:
                    rec, packet = latest_right(args.capture)
                except (FileNotFoundError, ValueError) as exc:
                    if robot is not None:
                        if time.monotonic()-last_pause_report > 2:
                            print(json.dumps({'warning':'Quest input unavailable; hand paused','detail':str(exc)}),flush=True)
                            last_pause_report = time.monotonic()
                        time.sleep(.05)
                        continue
                    if args.replay:
                        raise
                    time.sleep(.05)
                    continue
                try:
                    accepted = args.replay or gate.accept(rec, packet)
                except TimeoutError as exc:
                    if time.monotonic()-last_pause_report > 2:
                        print(json.dumps({'warning':'Quest input delayed; hand paused','detail':str(exc)}),flush=True)
                        last_pause_report = time.monotonic()
                    time.sleep(.05)
                    continue
                if not accepted:
                    time.sleep(.01)
                    continue
                t = time.monotonic()
                timing = {'input_age_ms':(time.time_ns()-rec['recv_unix_ns'])/1e6}
                q = mapper.solve(packet['data']['points'])
                requested = target = None
                timing['retarget_ms'] = (time.monotonic()-t)*1000
                if time.monotonic()-t > .15:
                    raise TimeoutError('retarget computation exceeded 150ms')
                preview_samples += 1
                if args.execute:
                    # Warm up on one second of fresh, advancing source frames.
                    if robot is None and preview_samples >= 20 and time.monotonic()-begun >= 1:
                        from harness.client import Robot
                        robot = Robot('wuji-hand', by=args.owner or 'quest-hand-' + uuid.uuid4().hex)
                        connection = CapConnection(robot.base, robot.by)
                        robot.acquire('quest-hand-follow', ttl_s=6)
                    if robot is not None:
                        if session_id is None:
                            t_start = time.monotonic()
                            # Native SDK discovery/connection can delay this
                            # request. This does not change the live watchdog.
                            status = checked(robot, 'stream_start', {'side':'right', 'duration_s':args.duration, 'max_delta_rad':args.max_delta, 'velocity_rad_s':args.velocity})
                            timing['start_ms'] = (time.monotonic()-t_start)*1000
                            if status.get('exit') == 'busy' and status.get('completion') == 'not_started':
                                # Discovery shares the driver lock. A definite
                                # not_started response permits waiting/retrying.
                                time.sleep(.05)
                                continue
                            if status.get('exit') != 'success':
                                raise RuntimeError('stream_start: '+str(status))
                            session_id = status['session_id']
                        t_status = time.monotonic()
                        if not status_ready:
                            try:
                                status = checked(robot, 'stream_status', connection=connection)
                            except TransportError as error:
                                print(json.dumps({'warning':'hand connection delayed; waiting','detail':str(error)}),flush=True)
                                time.sleep(.05)
                                continue
                        timing['status_ms'] = (time.monotonic()-t_status)*1000
                        if status['phase'] == 'stopped':
                            if status.get('diagnosis'):
                                raise RuntimeError(status['diagnosis'])
                            break
                        if status['phase'] in ('awaiting_input', 'paused', 'rebasing', 'running') and not status_ready:
                            if (time.time_ns()-rec['recv_unix_ns'])/1e9 > .2:
                                # Connection/preflight can take seconds. Pick a
                            # new live frame before enabling or resuming.
                                continue
                            # Keep the original session start only for the
                            # explicitly requested optional excursion bound.
                            start = np.asarray(status['start_rad'])
                            status_ready = True
                        if status_ready:
                            if args.stop_file and args.stop_file.exists():
                                break
                            # Recheck file/source freshness after HTTP and IK.
                            if (time.time_ns()-rec['recv_unix_ns'])/1e9 > .2:
                                time.sleep(.05)
                                continue
                            # Fingers follow the absolute retarget pose, even
                            # after input gaps. Never subtract the user's
                            # initial curl or offset by the robot's start pose.
                            requested = q.copy()
                            target = requested.copy()
                            if args.max_delta is not None:
                                target = np.clip(target, start-args.max_delta, start+args.max_delta)
                            target = np.clip(target, mapper.limits[:, 0], mapper.limits[:, 1])
                            limited = np.flatnonzero(np.abs(requested-target) > 1e-9).tolist()
                            now = time.monotonic()
                            if limited and (limited != previous_limits or now-last_warning >= 1):
                                print(json.dumps({'warning':'joint target clamped; following continues','joints':limited}),flush=True)
                                last_warning = now
                            previous_limits = limited
                            t_target = time.monotonic()
                            try:
                                status = checked(robot, 'stream_target', {'session_id':session_id, 'seq':gate.seq, 'positions_rad':target.tolist()}, connection=connection)
                            except TransportError as error:
                                status_ready = False
                                print(json.dumps({'warning':'hand HTTP delayed; waiting without replaying target','detail':str(error)}),flush=True)
                                continue
                            timing['target_ms'] = (time.monotonic()-t_target)*1000
                            hardware_limits = (status.get('position_limit_joints', []),
                                               status.get('limit_clamped_joints', []),
                                               status.get('limit_direction_unknown', []))
                            now = time.monotonic()
                            if any(hardware_limits) and (hardware_limits != previous_hardware_limits or now-last_hardware_warning >= 1):
                                print(json.dumps({'warning':'hand position limit; following continues',
                                                  'active_joints':hardware_limits[0],
                                                  'clamped_joints':hardware_limits[1],
                                                  'held_until_limit_clears':hardware_limits[2]}),flush=True)
                                last_hardware_warning = now
                            previous_hardware_limits = hardware_limits
                            diagnostic_warnings = status.get('diagnostic_warnings', [])
                            if diagnostic_warnings and (diagnostic_warnings != previous_diagnostic_warnings or now-last_diagnostic_warning >= 2):
                                print(json.dumps({'warning':'hand firmware warning; following continues',
                                                  'diagnostics':diagnostic_warnings}),flush=True)
                                last_diagnostic_warning = now
                            previous_diagnostic_warnings = diagnostic_warnings
                            tracking_warning = status.get('tracking_warning')
                            if tracking_warning and now-last_tracking_warning >= 2:
                                print(json.dumps({'warning':'hand tracking lag; following continues',
                                                  'detail':tracking_warning}),flush=True)
                                last_tracking_warning = now
                            if status.get('completion') == 'rebase_required':
                                # Driver holds measured pose for this handshake;
                                # next fresh frame resumes absolute targets.
                                print(json.dumps({'warning':'Quest input resumed; hand will follow next absolute pose'}),flush=True)
                            if status['phase'] == 'running' and enabled_at is None:
                                enabled_at = time.monotonic()
                    else:
                        target = q
                else:
                    target = q
                sample = {'at':time.time(), 'source':packet.get('debug'), 'mapping_mode':'absolute',
                          'retarget_rad':q.tolist(),
                          'requested_rad':requested.tolist() if requested is not None else None,
                          'target_rad':target.tolist() if target is not None else None,
                          'timing_ms':timing, 'stream':status}
                log.write(json.dumps(sample)+'\n')
                log.flush()
                if time.monotonic()-last_report > 1:
                    print(json.dumps({'preview_samples':preview_samples, 'phase':status.get('phase') if status else 'preview', 'q_sdk':q.round(3).tolist()}), flush=True)
                    last_report = time.monotonic()
                time.sleep(.005)
    except KeyboardInterrupt:
        print('STOP: Ctrl+C', flush=True)
    except Exception as exc:
        failure = str(exc) or type(exc).__name__
        print('STOP: ' + failure + ' ' + json.dumps(timing), flush=True)
    finally:
        if connection is not None:
            connection.close()
        if robot is not None:
            try:
                if status is None or status.get('phase') != 'stopped':
                    robot.cap('cancel_motion', {}, timeout=3)
                deadline = time.monotonic()+5
                while time.monotonic() < deadline:
                    status = checked(robot, 'stream_status', timeout=3)
                    if status['phase'] == 'stopped':
                        break
                    time.sleep(.05)
            except Exception as exc:
                failure = (failure or '') + '; cleanup: ' + str(exc)
            finally:
                robot.release()
        summary = {'execute':args.execute, 'samples':preview_samples, 'failure':failure, 'last_timing_ms':timing, 'final_stream':status, 'log':str(log_path)}
        log_path.with_suffix('.json').write_text(json.dumps(summary, indent=2))
        print(json.dumps(summary), flush=True)
    if failure:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
