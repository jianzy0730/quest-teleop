"""Preview Quest wrist -> Thor right EE relative poses. No motion is sent.

Unity tracking coordinates must share an origin between Head/pose and
Right/wrist. At calibration, face the direction to map to robot base +X.
This is a relative wrist orientation mapping, not a measured palm/TCP offset.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def quaternion(q):
    q = np.asarray(q, dtype=float)
    if q.shape != (4,) or not np.isfinite(q).all():
        raise ValueError('four finite quaternion values required (xyzw)')
    n = np.linalg.norm(q)
    if not .9 <= n <= 1.1:
        raise ValueError('invalid quaternion norm')
    return q / n


def multiply(a, b):
    av, bv = a[:3], b[:3]
    return np.r_[a[3]*bv + b[3]*av + np.cross(av, bv), a[3]*b[3] - av@bv]


def rotation(q):
    x, y, z, w = quaternion(q)
    return np.array([
        [1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
        [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
        [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)],
    ])


def pose(values):
    p = np.asarray(values, dtype=float)
    if p.shape != (7,) or not np.isfinite(p).all():
        raise ValueError('seven finite pose values required')
    return np.r_[p[:3], quaternion(p[3:])]


def packet_pose(packet):
    return pose([packet['data'][k] for k in ('x', 'y', 'z', 'qx', 'qy', 'qz', 'qw')])


class WristMapper:
    def rebase(self, wrist, robot):
        """Keep the original control axes when recovering from a data gap."""
        self.wrist = pose(wrist)
        self.robot = pose(robot)
        self.previous_q = self.robot[3:].copy()

    def __init__(self, wrist, robot, head, scale=1.):
        self.wrist = pose(wrist)
        self.robot = pose(robot)
        head = pose(head)
        if not math.isfinite(scale) or scale <= 0:
            raise ValueError('scale must be finite and positive')
        self.scale = scale
        # Y-up Unity world: project the initial head forward onto the floor.
        # Unity right/up/forward -> base forward/left/up has determinant -1.
        forward = rotation(head[3:]) @ [0., 0., 1.]
        forward[1] = 0.
        if np.linalg.norm(forward) < .2:
            raise ValueError('look horizontally when calibrating')
        forward /= np.linalg.norm(forward)
        up = np.array([0., 1., 0.])
        right = np.cross(up, forward)
        self.axes = np.array([forward, -right, up])
        self.previous_q = self.robot[3:].copy()

    def map(self, wrist):
        wrist = pose(wrist)
        position = self.robot[:3] + self.scale * self.axes @ (wrist[:3]-self.wrist[:3])
        # Express a world-frame rotation increment in a reflected basis:
        # R_delta_base = M R_delta_unity M^T. Quaternion vector parts are axial
        # vectors, so transform them with det(M)*M, not M alone.
        inverse = self.wrist[3:] * [-1., -1., -1., 1.]
        delta = multiply(wrist[3:], inverse)
        delta_base = np.r_[-self.axes @ delta[:3], delta[3]]
        q = quaternion(multiply(delta_base, self.robot[3:]))
        if q @ self.previous_q < 0:
            q = -q
        self.previous_q = q.copy()
        return np.r_[position, q]


def latest_packets(path):
    """Bounded tail; ignore partial writes and never drain a frame backlog."""
    with path.open('rb') as f:
        f.seek(0, 2)
        start = max(0, f.tell()-131072)
        f.seek(start)
        lines = f.read().split(b'\n')
    if start:
        lines = lines[1:]
    found, pairs = {}, {}
    for line in reversed(lines[:-1]):
        try:
            rec = json.loads(line)
            for packet in rec['packets']:
                key = packet.get('key')
                if key == 'Head/pose' and key not in found:
                    found[key] = rec, packet
                elif key in ('Right/wrist','Right/landmarks'):
                    debug = packet.get('debug') or {}
                    frame = (debug.get('source_frame_seq'),debug.get('source_ts_ns'))
                    pairs.setdefault(frame, {}).setdefault(key,(rec,packet))
        except (ValueError, KeyError, TypeError):
            continue
        if 'Head/pose' in found:
            for pair in pairs.values():
                if len(pair) == 2:
                    return {**pair, **found}
    raise ValueError('need Right/wrist, Right/landmarks and Head/pose; enable Head Pose')


class WristGate:
    """Fresh arrival + source progress + paired tracking-change proxy.

    HTS does not transmit tracking-valid. Frozen poses can carry new sequence
    numbers, so identical wrist AND landmarks for 750ms fail closed. This may
    also reject a deliberately stationary hand. It is not tracking confidence.
    """
    def __init__(self):
        self.seq = self.source_ns = self.offset = self.geometry = None
        self.changed_at = time.monotonic()

    @staticmethod
    def fresh(rec, now_ns):
        age = (now_ns-rec['recv_unix_ns'])/1e9
        if not -.1 <= age <= .2:
            raise TimeoutError(f'Quest input age {age:.3f}s; live input required')

    def accept(self, packets, calibration=False):
        now = time.time_ns()
        for key in ('Right/wrist', 'Right/landmarks') + (('Head/pose',) if calibration else ()):
            self.fresh(packets[key][0], now)
        rec, wrist = packets['Right/wrist']
        _, hand = packets['Right/landmarks']
        debug = wrist.get('debug') or {}
        seq, ns = debug.get('source_frame_seq'), debug.get('source_ts_ns')
        if not isinstance(seq, int) or not isinstance(ns, int):
            raise ValueError('enable Debug Info in HTS')
        hand_debug = hand.get('debug') or {}
        if seq != hand_debug.get('source_frame_seq') or ns != hand_debug.get('source_ts_ns'):
            return False  # TCP lines can straddle one file flush; wait for a pair.
        if self.seq is not None and (seq < self.seq or ns < self.source_ns):
            raise ValueError('Quest source reset: calibrate a new session')
        if seq == self.seq:
            return False
        if self.source_ns is not None and ns <= self.source_ns:
            raise ValueError('Quest source time did not advance')
        offset = (rec['recv_unix_ns']-ns)/1e9
        self.offset = offset if self.offset is None else min(self.offset, offset)
        if offset-self.offset > .15:
            raise TimeoutError('Quest transport backlog >150ms')
        geometry = (wrist['data'], hand['data'])
        if geometry != self.geometry:
            self.geometry = geometry
            self.changed_at = time.monotonic()
        elif time.monotonic()-self.changed_at > .75:
            raise TimeoutError('Quest pose frozen; tracking validity unavailable')
        self.seq, self.source_ns = seq, ns
        return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, help='Default: newest live/quest/capture_*.jsonl')
    parser.add_argument('--duration', type=float, default=0, help='0: until Ctrl+C')
    parser.add_argument('--scale', type=float, default=1.)
    parser.add_argument('--replay', action='store_true', help='Offline preview of the entire capture')
    parser.add_argument('--robot-pose', nargs=7, type=float, help='Explicit preview anchor; required for replay')
    parser.add_argument('--output', type=Path, default=ROOT/'live/quest')
    parser.add_argument('--stop-file',type=Path,help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('duration must be finite and nonnegative')
    if not math.isfinite(args.scale) or args.scale <= 0:
        parser.error('scale must be finite and positive')
    if args.replay and args.robot_pose is None:
        parser.error('replay requires --robot-pose; never treat a stale robot pose as live')
    path = args.capture
    if path is None:
        paths = list((ROOT/'live/quest').glob('capture_*.jsonl'))
        if not paths:
            parser.error('no capture files')
        path = max(paths, key=lambda p: p.stat().st_mtime_ns)
    anchor = args.robot_pose
    if anchor is None:
        from harness.client import Robot
        observation = Robot('ms-thor').policy_observe(include=['state'], history=0)
        anchor = observation['state']['eef_right']
    anchor = pose(anchor)
    args.output.mkdir(parents=True, exist_ok=True)
    output = args.output / ('arm_preview_'+time.strftime('%Y%m%d_%H%M%S')+'.jsonl')
    print(json.dumps({'mode':'preview_no_motion', 'capture':str(path), 'anchor':anchor.tolist(), 'output':str(output)}), flush=True)
    mapper = None
    gate = WristGate()
    begun = last_report = time.monotonic()
    count = 0
    failure = None
    try:
        with output.open('w', encoding='utf-8') as log:
            def emit(packets):
                nonlocal mapper, count, last_report
                if not args.replay and not gate.accept(packets, calibration=mapper is None):
                    return
                wrist = packet_pose(packets['Right/wrist'][1])
                if mapper is None:
                    mapper = WristMapper(wrist, anchor, packet_pose(packets['Head/pose'][1]), args.scale)
                    print(json.dumps({'calibrated':True, 'unity_to_base_axes':mapper.axes.tolist()}), flush=True)
                target = mapper.map(wrist)
                delta = multiply(target[3:], anchor[3:]*[-1.,-1.,-1.,1.])
                angle = math.degrees(2*math.acos(float(np.clip(abs(delta[3]), 0., 1.))))
                sample = {'recv_unix_ns':packets['Right/wrist'][0]['recv_unix_ns'],
                          'source':packets['Right/wrist'][1].get('debug'),
                          'target_base_link':target.tolist(), 'delta_xyz_m':(target[:3]-anchor[:3]).tolist(),
                          'rotation_delta_deg':angle, 'mode':'preview_no_motion'}
                log.write(json.dumps(sample, allow_nan=False)+'\n')
                count += 1
                if time.monotonic()-last_report >= 1:
                    log.flush()
                    print(json.dumps(sample), flush=True)
                    last_report = time.monotonic()

            if args.replay:
                packets = {}
                last_seq = None
                with path.open(encoding='utf-8') as source:
                    for line in source:
                        rec = json.loads(line)
                        for packet in rec['packets']:
                            packets[packet.get('key')] = rec, packet
                        if all(k in packets for k in ('Right/wrist','Right/landmarks','Head/pose')):
                            seq = packets['Right/wrist'][1].get('debug')
                            if seq != last_seq:
                                emit(packets)
                                last_seq = seq
            else:
                while args.duration == 0 or time.monotonic()-begun < args.duration:
                    if args.stop_file and args.stop_file.exists():
                        break
                    emit(latest_packets(path))
                    time.sleep(.025)
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        failure = str(exc)
    summary = {'mode':'preview_no_motion', 'samples':count, 'failure':failure, 'output':str(output)}
    output.with_suffix('.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary), flush=True)
    if failure:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
