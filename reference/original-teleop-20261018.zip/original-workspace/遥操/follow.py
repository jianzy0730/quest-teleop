"""One-command Windows launcher for Quest USB/Wi-Fi, Thor arm and Wuji hand."""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import uuid

from .quest_arm import ROOT, WristGate, latest_packets


def wsl_path(path):
    path = Path(path).resolve()
    return '/mnt/'+path.drive[0].lower()+'/'+path.as_posix()[3:]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only', choices=['arm','hand','both'], default='both')
    parser.add_argument('--transport', choices=['usb','udp'], default='usb')
    parser.add_argument('--port',type=int)
    parser.add_argument('--scale', type=float, default=1., help='Arm translation scale; rotation is 1:1')
    parser.add_argument('--hand-velocity', type=float, help='Optional additional joint target slew rad/s; default none')
    parser.add_argument('--filter-alpha',type=float,default=1.,help='Upstream hand low-pass alpha; default 1 disables smoothing')
    parser.add_argument('--capture',type=Path,help='Use an existing LIVE receiver capture instead of starting a receiver')
    parser.add_argument('--preview', action='store_true',help='Receive and map inputs without robot motion')
    parser.add_argument('--duration',type=float,default=0,help='Optional test duration in seconds; 0 until Ctrl+C')
    args = parser.parse_args()
    if os.name != 'nt':
        parser.error('Run this launcher in Windows PowerShell')
    if not math.isfinite(args.scale) or args.scale <= 0 or not 0 < args.filter_alpha <= 1:
        parser.error('positive finite scale and filter alpha in (0,1] required')
    if args.hand_velocity is not None and (not math.isfinite(args.hand_velocity) or args.hand_velocity <= 0):
        parser.error('hand-velocity must be positive and finite')
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('duration must be finite and nonnegative')
    if args.port is None:
        args.port = 8000 if args.transport == 'usb' else 9000
    if not 1 <= args.port <= 65535:
        parser.error('port must be 1..65535')
    output = ROOT/'live/quest'/('session_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6])
    output.mkdir(parents=True)
    stop = output/'STOP'
    capture = args.capture.resolve() if args.capture else output/'capture.jsonl'
    children, logs, owners = {}, {}, {}
    failed = None
    def launch(name, command):
        logs[name] = (output/(name+'.log')).open('w',encoding='utf-8')
        env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
        children[name] = subprocess.Popen(command,cwd=ROOT,env=env,stdout=logs[name],stderr=subprocess.STDOUT,
                                          creationflags=subprocess.CREATE_NO_WINDOW)
    print('Session: '+str(output),flush=True)
    def check_children():
        if stop.exists():
            raise KeyboardInterrupt
        for name, child in children.items():
            if child.poll() is not None:
                raise RuntimeError(name+' exited; see '+str(output/(name+'.log')))
    try:
        if not args.capture:
            with socket.socket(socket.AF_INET,socket.SOCK_STREAM if args.transport=='usb' else socket.SOCK_DGRAM) as probe:
                try:
                    probe.bind(('127.0.0.1' if args.transport=='usb' else '0.0.0.0',args.port))
                except OSError as error:
                    if error.errno == 10048 or getattr(error, 'winerror', None) == 10048:
                        raise RuntimeError(f'Port {args.port} is already in use. Stop the previous receiver/follow console with Ctrl+C, or use --capture <its live capture.jsonl>.') from error
                    raise
            if args.transport == 'usb':
                adb = shutil.which('adb')
                if not adb:
                    raise RuntimeError('adb not found in PATH')
                subprocess.run([adb,'reverse',f'tcp:{args.port}',f'tcp:{args.port}'],check=True,timeout=15)
            launch('receive',[str(ROOT/'.venv-quest/Scripts/python.exe'),'-u','-m','遥操','receive',
                '--transport','tcp' if args.transport=='usb' else 'udp','--host','127.0.0.1' if args.transport=='usb' else '0.0.0.0',
                '--port',str(args.port),'--duration','0','--capture',str(capture),'--output',str(output),'--stop-file',str(stop)])
        print('Waiting for live Quest right wrist + landmarks + Head Pose. Start Streaming; Video Feed OFF. Ctrl+C stops.',flush=True)
        while True:
            check_children()
            try:
                live = WristGate().accept(latest_packets(capture),calibration=True)
            except (ValueError,FileNotFoundError,TimeoutError):
                live = False
            if live:
                if not args.preview and args.only in ('both','arm'):
                    from harness.client import Robot
                    from .quest_arm_follow import wait_for_driver
                    ready = wait_for_driver(Robot('ms-thor'), check_children)
                    print('Thor driver connected; control '+json.dumps(ready.get('control', {})),flush=True)
                    # Driver recovery may take minutes; require a fresh Quest
                    # frame before starting either follower, not the old one.
                    try:
                        if not WristGate().accept(latest_packets(capture),calibration=True):
                            continue
                    except (ValueError,FileNotFoundError,TimeoutError):
                        print('Waiting for live Quest input again. Ctrl+C stops.',flush=True)
                        continue
                break
            time.sleep(.05)
        if args.only in ('both','arm'):
            owners['arm'] = 'task-quest-arm-'+uuid.uuid4().hex
            command = [sys.executable,'-u','-m','遥操','arm' if args.preview else 'arm-follow',
                       '--capture',str(capture),'--scale',str(args.scale),'--output',str(output),'--stop-file',str(stop)]
            if not args.preview:
                command += ['--owner',owners['arm']]
            launch('arm',command)
        if args.only in ('both','hand'):
            owners['hand'] = 'quest-hand-'+uuid.uuid4().hex
            command=['wsl.exe','-d','Ubuntu-22.04','--','/home/jianziyu/.venv-quest-retarget/bin/python','-u',
                     wsl_path(ROOT/'遥操/quest_hand.py'),'--capture',wsl_path(capture),'--output',wsl_path(output),
                     '--stop-file',wsl_path(stop),'--owner',owners['hand'],'--filter-alpha',str(args.filter_alpha)]
            if not args.preview:
                command += ['--execute']
            if args.hand_velocity is not None:
                command += ['--velocity',str(args.hand_velocity)]
            launch('hand',command)
        print('Live input received. Starting '+args.only+'; keep hand visible during calibration. Logs: '+str(output),flush=True)
        positions={name:0 for name in children}
        started=time.monotonic()
        while True:
            if args.duration and time.monotonic()-started >= args.duration:
                break
            for name,child in children.items():
                if child.poll() is not None:
                    raise RuntimeError(f'{name} exited ({child.returncode}); all followers stopping')
                if name == 'receive':
                    continue
                with (output/(name+'.log')).open(encoding='utf-8',errors='replace') as log:
                    log.seek(positions[name])
                    lines=log.readlines()
                    positions[name]=log.tell()
                for line in lines:
                    try:
                        row=json.loads(line)
                    except ValueError:
                        continue
                    if 'warning' in row:
                        print('['+name+'] WARNING: '+str(row['warning'])+
                              ' '+json.dumps({k:v for k,v in row.items() if k != 'warning'}),flush=True)
                    elif row.get('calibrated'):
                        print('[arm] calibrated; following wrist XYZ + rotation',flush=True)
                    elif 'sent' in row and 'position_error_m' in row:
                        print(f"[arm] frames={row['sent']} position error={row['position_error_m']*1000:.1f}mm rotation error={row['rotation_error_deg']:.1f}deg",flush=True)
                    elif 'phase' in row:
                        print('[hand] '+str(row['phase']),flush=True)
            time.sleep(.1)
    except KeyboardInterrupt:
        print('Stopping: Ctrl+C',flush=True)
    except Exception as error:
        failed=str(error)
        print('STOP: '+failed,flush=True)
    finally:
        stop.touch()
        if not args.preview:
            from harness.client import Robot
            for name,owner in owners.items():
                try:
                    robot=Robot('ms-thor' if name=='arm' else 'wuji-hand',by=owner)
                    result=robot.cap('stop_motion' if name=='arm' else 'cancel_motion',{},timeout=3)
                    print(name+' stop: '+json.dumps(result),flush=True)
                except Exception as error:
                    failed=failed or 'stop failed: '+str(error)
        deadline=time.monotonic()+15
        while any(p.poll() is None for p in children.values()) and time.monotonic()<deadline:
            time.sleep(.1)
        for name,child in children.items():
            if child.poll() is None:
                child.terminate()
                failed=failed or name+' did not exit within 15 seconds; inspect log'
            logs[name].close()
        if not args.preview:
            for name,owner in owners.items():
                try:
                    robot=Robot('ms-thor' if name=='arm' else 'wuji-hand',by=owner)
                    robot.release()
                except Exception as error:
                    failed=failed or 'release failed: '+str(error)
        if failed:
            for name in children:
                print('--- '+name+' log ---',flush=True)
                print('\n'.join((output/(name+'.log')).read_text(encoding='utf-8',errors='replace').splitlines()[-8:]),flush=True)
        (output/'summary.json').write_text(json.dumps({'failure':failed,'capture':str(capture),'owners':owners},indent=2),encoding='utf-8')
        print('Stopped. Logs: '+str(output),flush=True)
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
