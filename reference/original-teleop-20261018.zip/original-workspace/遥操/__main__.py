"""Command entry point: python -m 遥操 {receive,hand,arm} [options]."""
from __future__ import annotations

import argparse
from importlib import import_module
import sys


COMMANDS = {
    'follow': ('follow', '一条命令启动 USB/Wi-Fi 接收和手臂/手指跟随；Ctrl+C 停止'),
    'receive': ('quest_receive', '接收 Quest UDP/TCP 数据'),
    'hand': ('quest_hand', 'Wuji 右手预览 / 跟随（--execute）'),
    'arm': ('quest_arm', '天机右臂腕部 6D 映射预览'),
    'arm-replay': ('quest_arm_replay', '录制腕部位姿的逐点实机重放（--execute）'),
    'arm-follow': ('quest_arm_follow', 'Quest 实时腕部跟随天机右臂'),
}


def main():
    parser = argparse.ArgumentParser(description='Quest → 天机 / Wuji 遥操')
    subparsers = parser.add_subparsers(dest='command', required=True)
    for name, (_, description) in COMMANDS.items():
        subparsers.add_parser(name, help=description, add_help=False)
    args, remaining = parser.parse_known_args()
    module = import_module('.' + COMMANDS[args.command][0], package=__package__)
    sys.argv = [sys.argv[0] + ' ' + args.command, *remaining]
    module.main()


if __name__ == '__main__':
    main()
