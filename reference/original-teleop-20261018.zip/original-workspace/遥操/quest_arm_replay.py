"""Bounded sampled Quest wrist replay through Harness (not a live servo).

Default mode only writes a plan. --execute acquires one lease and executes
the bounded sampled plan with measured pose verification. Ctrl+C stops.
"""
from __future__ import annotations

import argparse
import base64
import json
import math
from pathlib import Path
import sys
import time
import uuid

import numpy as np

from .quest_arm import ROOT, WristMapper, packet_pose, pose, quaternion


def angle_deg(a, b):
    return math.degrees(2 * math.acos(float(np.clip(abs(quaternion(a) @ quaternion(b)), 0., 1.))))


def scaled_rotation(start, goal, gain):
    start, goal = quaternion(start), quaternion(goal)
    if start @ goal < 0:
        goal = -goal
    theta = math.acos(float(np.clip(start @ goal, 0., 1.)))
    if theta < 1e-8:
        return start.copy()
    return quaternion((math.sin((1-gain)*theta)*start + math.sin(gain*theta)*goal)/math.sin(theta))


def recorded_frames(path, duration_s):
    """Pair split packet records by exact source frame and source timestamp.

    Old wall time is intentional here. Source continuity and paired geometry
    are still required. HTS has no tracking-valid flag; this is a proxy only.
    """
    cache, frames = {}, []
    previous = first_ns = changed_ns = geometry = None
    with Path(path).open(encoding='utf-8') as source:
        for line in source:
            record = json.loads(line)
            for packet in record['packets']:
                cache[packet['key']] = packet
            if not all(k in cache for k in ('Right/wrist', 'Right/landmarks', 'Head/pose')):
                continue
            wrist, hand, head = (cache[k] for k in ('Right/wrist', 'Right/landmarks', 'Head/pose'))
            debug = wrist.get('debug') or {}
            seq, ns = debug.get('source_frame_seq'), debug.get('source_ts_ns')
            if type(seq) is not int or type(ns) is not int:
                raise ValueError('recording needs source debug sequence and timestamp')
            hd = hand.get('debug') or {}
            if (seq, ns) != (hd.get('source_frame_seq'), hd.get('source_ts_ns')):
                continue
            if previous == (seq, ns):
                continue
            if previous and (seq <= previous[0] or ns <= previous[1]):
                raise ValueError('recorded source reset or time did not advance')
            if previous and ns-previous[1] > 100_000_000:
                raise ValueError('recorded paired frame gap exceeds 100 ms')
            if first_ns is None:
                head_ns = (head.get('debug') or {}).get('source_ts_ns')
                if type(head_ns) is not int or abs(head_ns-ns) > 200_000_000:
                    raise ValueError('initial head pose is not synchronized with wrist')
                first_ns = ns
            points = np.asarray(hand['data']['points'], dtype=float)
            if points.shape != (21, 3) or not np.isfinite(points).all():
                raise ValueError('invalid recorded hand landmarks')
            current_geometry = (wrist['data'], hand['data'])
            if current_geometry != geometry:
                geometry, changed_ns = current_geometry, ns
            elif ns-changed_ns > 750_000_000:
                raise ValueError('recorded tracking geometry frozen for over 750 ms')
            frame = {'source_seq': seq, 'source_ns': ns, 't_s': (ns-first_ns)/1e9,
                     'wrist': packet_pose(wrist), 'head': packet_pose(head)}
            frames.append(frame)
            previous = seq, ns
            if frame['t_s'] >= duration_s:
                return frames
    raise ValueError('recording ends before requested duration')


def validate_target(target, anchor, safety, max_translation_m=.05, max_rotation_deg=5.):
    target, anchor = pose(target), pose(anchor)
    if np.linalg.norm(target[:3]-anchor[:3]) > max_translation_m + 1e-9:
        raise ValueError('test translation envelope exceeded; reduce position scale')
    if angle_deg(target[3:], anchor[3:]) > max_rotation_deg + 1e-7:
        raise ValueError('test rotation envelope exceeded; reduce rotation scale')
    for axis, value in zip('xyz', target[:3]):
        low, high = safety['workspace'][axis]
        if not low <= value <= high:
            raise ValueError(f'{axis} target outside manifest workspace; no silent clamping')
    return target


def make_plan(frames, anchor, safety, position_scale=.4, rotation_scale=.03,
              interval_s=1/3, min_command_translation_m=.025):
    anchor = pose(anchor)
    mapper = WristMapper(frames[0]['wrist'], anchor, frames[0]['head'], position_scale)
    waypoints, skipped, next_t = [], [], interval_s
    for index, frame in enumerate(frames):
        target = mapper.map(frame['wrist'])
        target[3:] = scaled_rotation(anchor[3:], target[3:], rotation_scale)
        validate_target(target, anchor, safety)
        if frame['t_s'] + 1e-9 >= next_t or index == len(frames)-1:
            previous = waypoints[-1]['pose'] if waypoints else anchor
            step = float(np.linalg.norm(target[:3]-np.asarray(previous)[:3]))
            if step < min_command_translation_m:
                skipped.append({'source_seq': frame['source_seq'], 'source_t_s': frame['t_s'],
                                'step_m': step, 'reason': 'inside_driver_position_tolerance'})
                next_t = frame['t_s'] + interval_s
                continue
            if step > safety['max_step_m']:
                raise ValueError('test waypoint step too large')
            waypoints.append({'source_seq': frame['source_seq'], 'source_ns': frame['source_ns'],
                              'source_t_s': frame['t_s'], 'pose': target.tolist(),
                              'delta_xyz_m': (target[:3]-anchor[:3]).tolist(),
                              'rotation_delta_deg': angle_deg(target[3:], anchor[3:])})
            next_t = frame['t_s'] + interval_s
    if not waypoints:
        raise ValueError('recorded replay has no waypoint outside the driver position tolerance')
    return {'mode': 'sampled_recording_replay', 'anchor': anchor.tolist(),
            'position_scale': position_scale, 'rotation_scale': rotation_scale,
            'axes_unity_to_base': mapper.axes.tolist(), 'source_frames': len(frames),
            'driver_position_tolerance_m': .02, 'minimum_command_translation_m': min_command_translation_m,
            'skipped_waypoints': skipped, 'waypoints': waypoints}


def fresh_pose(state):
    now = time.time()
    stamp = state.get('perception', {}).get('streams', {}).get('eef_right', {}).get('source_t', 0)
    if not 0 <= now-state.get('updated_at', 0) <= .5 or not 0 <= now-stamp <= .5:
        raise RuntimeError('stale end effector feedback')
    if not state.get('perception', {}).get('ready'):
        raise RuntimeError('perception not ready')
    return pose(state['eef_right']), stamp


def wait_reached(robot, target, after_source_t, timeout_s=6.):
    """Require XYZ AND rotation with three distinct fresh post-command samples."""
    deadline, seen, consecutive = time.monotonic()+timeout_s, after_source_t, 0
    last = {}
    while time.monotonic() < deadline:
        state = robot.state()
        actual, stamp = fresh_pose(state)
        lease = state.get('lease') or {}
        if lease.get('by') != robot.by or lease.get('expires', 0) <= time.time():
            raise RuntimeError('replay lease lost')
        if stamp > seen:
            seen = stamp
            pe, re = float(np.linalg.norm(actual[:3]-target[:3])), angle_deg(actual[3:], target[3:])
            last = {'eef_right': actual.tolist(), 'source_t': stamp,
                    'position_error_m': pe, 'rotation_error_deg': re}
            consecutive = consecutive+1 if pe <= .002 and re <= .5 else 0
            if consecutive >= 3:
                return {'exit': 'success', 'completion': 'pose_feedback_verified', **last}
        time.sleep(.05)
    raise RuntimeError('pose not settled within 2 mm / 0.5 deg: '+json.dumps(last))


def save_observation(observation, output, stem):
    reduced = dict(observation)
    reduced['frames'] = {}
    for name, frame in observation.get('frames', {}).items():
        saved = dict(frame)
        for key in ('jpg_b64', 'jpg'):
            if saved.get(key):
                path = output / f'{stem}_{name}.jpg'
                path.write_bytes(base64.b64decode(saved[key]))
                saved[key] = str(path)
        reduced['frames'][name] = saved
    (output/f'{stem}.json').write_text(json.dumps(reduced, indent=2), encoding='utf-8')
    return {name: {key: val for key, val in frame.items() if key in ('jpg_b64', 'jpg', 'source_t', 'age_s')}
            for name, frame in reduced['frames'].items()}


class ReplaySession:
    def __init__(self, robot, plan, output):
        self.robot, self.plan, self.output = robot, plan, output
        self.index, self.observation_counter = 0, 0
        self.reviewed_at = None
        self.previous = pose(plan['anchor'])
        self.events = []

    def record(self, event):
        event = {'at': time.time(), **event}
        self.events.append(event)
        with (self.output/'events.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(event, allow_nan=False)+'\n')
        print(json.dumps(event), flush=True)

    def observe(self):
        obs = self.robot.policy_observe(include=['state', 'eyes', 'wrists'], history=0)
        fresh_pose(obs['state'])
        self.observation_counter += 1
        images = save_observation(obs, self.output, f'observe_{self.observation_counter}')
        self.reviewed_at = time.monotonic()
        self.record({'event': 'observe', 'index': self.index, 'images': images,
                     'eef_right': obs['state']['eef_right']})

    def next(self):
        if self.reviewed_at is None or time.monotonic()-self.reviewed_at > 30:
            raise RuntimeError('fresh observation required before next action')
        self.reviewed_at = None
        obs = self.robot.policy_observe(history=0)
        actual, stamp = fresh_pose(obs['state'])
        if np.linalg.norm(actual[:3]-self.previous[:3]) > .003 or angle_deg(actual[3:], self.previous[3:]) > 1.:
            raise RuntimeError('robot moved from verified previous pose; replan required')
        target = pose(self.plan['waypoints'][self.index]['pose'])
        validate_target(target, self.plan['anchor'], self.robot.safety)
        result = self.robot.execute_chunk([{'name': 'move_to_pose', 'args': {
            'pose': target.tolist(), 'arm': 'right', 'timeout_s': 6.}}], phase='approach')
        self.record({'event': 'command', 'index': self.index, 'target': target.tolist(), 'result': result})
        if result.get('exit') != 'success':
            raise RuntimeError('chunk failed: '+json.dumps(result))
        reached = wait_reached(self.robot, target, stamp)
        # No held target remains while the operator inspects the next images.
        stopped = self.robot.cap('stop_motion', {})
        self.record({'event': 'reached', 'index': self.index, **reached, 'stop': stopped})
        if stopped.get('exit') != 'success':
            raise RuntimeError('stop_motion failed')
        self.previous = pose(reached['eef_right'])
        self.index += 1
        self.observe()


def execute_session(robot, plan, output, commands=None):
    session = ReplaySession(robot, plan, output)
    acquired, failure = False, None
    try:
        robot.acquire(op='quest-arm-recorded-replay', ttl_s=30)
        acquired = True
        control = robot.cap('prepare_control', {})
        session.record({'event': 'prepare', 'result': control})
        if control.get('exit') != 'success':
            raise RuntimeError('control preparation failed')
        session.observe()
        if commands is None:
            for _ in plan['waypoints']:
                session.next()
        else:
            for line in commands:
                command = line.strip().lower()
                if command == 'stop':
                    break
                if command == 'observe':
                    session.observe()
                elif command == 'next':
                    session.next()
                    if session.index == len(plan['waypoints']):
                        break
                else:
                    session.record({'event': 'help', 'commands': ['observe', 'next', 'stop']})
    except KeyboardInterrupt:
        failure = 'interrupted'
    except Exception as error:
        failure = str(error)
    finally:
        if acquired:
            try:
                session.record({'event': 'final_stop', 'result': robot.cap('stop_motion', {})})
            except Exception as error:
                failure = failure or 'stop outcome unknown: '+str(error)
            finally:
                session.record({'event': 'release', 'result': robot.release()})
        summary = {'mode': plan['mode'], 'completed': session.index, 'total': len(plan['waypoints']),
                   'failure': failure, 'finished': session.index == len(plan['waypoints']) and failure is None}
        (output/'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
        print(json.dumps(summary), flush=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--duration', type=float, default=1.)
    parser.add_argument('--interval', type=float, default=1/3)
    parser.add_argument('--position-scale', type=float, default=.4)
    parser.add_argument('--rotation-scale', type=float, default=.03)
    parser.add_argument('--robot-pose', type=float, nargs=7, help='Offline plan anchor; incompatible with execute')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if not all(math.isfinite(x) and x > 0 for x in (args.duration, args.interval, args.position_scale, args.rotation_scale)):
        parser.error('duration, interval, scales must be finite and positive')
    if args.duration > 2. or args.interval > args.duration or args.rotation_scale > 1.:
        parser.error('bounded test requires duration <= 2 s, interval <= duration, rotation scale <= 1')
    if args.execute and args.robot_pose:
        parser.error('execute always anchors to fresh robot feedback')
    frames = recorded_frames(args.capture, args.duration)
    from harness.client import Robot
    robot = Robot('ms-thor', by='quest-replay-'+uuid.uuid4().hex)
    anchor = args.robot_pose
    if anchor is None:
        anchor, _ = fresh_pose(robot.policy_observe(history=0)['state'])
    plan = make_plan(frames, anchor, robot.safety, args.position_scale, args.rotation_scale, args.interval)
    plan['capture'] = str(args.capture.resolve())
    output = args.output or ROOT/'live/quest'/('arm_replay_'+time.strftime('%Y%m%d_%H%M%S'))
    output.mkdir(parents=True, exist_ok=False)
    (output/'plan.json').write_text(json.dumps(plan, indent=2), encoding='utf-8')
    print(json.dumps({'output': str(output), 'execute': args.execute, 'plan': plan}), flush=True)
    if args.execute:
        result = execute_session(robot, plan, output)
        if not result['finished']:
            raise SystemExit(1)


if __name__ == '__main__':
    main()
