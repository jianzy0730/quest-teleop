"""Legacy CLI compatibility; all implementation lives in quest-teleop."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "quest-teleop"))
