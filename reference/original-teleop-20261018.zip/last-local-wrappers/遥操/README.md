# 遥操

源码、安装和运行说明统一在 [quest-teleop](../quest-teleop/README.md)。

这里仅保留旧命令 `python -m 遥操 follow` 和 `follow.ps1` 的兼容入口。
