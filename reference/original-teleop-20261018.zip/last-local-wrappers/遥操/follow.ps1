# Compatibility launcher. Ctrl+C ends the session.
$repo = Join-Path (Split-Path -Parent $PSScriptRoot) 'quest-teleop'
$python = Join-Path $repo '.venv\Scripts\python.exe'
Push-Location -LiteralPath $repo
try {
    & $python -u -m quest_teleop follow @args
    $followExitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
exit $followExitCode
