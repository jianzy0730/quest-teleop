"""Forward the old command to quest_teleop."""
from quest_teleop.__main__ import main

if __name__ == "__main__":
    main()
