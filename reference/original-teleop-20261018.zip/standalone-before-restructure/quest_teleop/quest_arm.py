"""Preview Quest wrist -> Thor right EE relative poses. No motion is sent.

Unity tracking coordinates must share an origin between Head/pose and
Right/wrist. At calibration, face the direction to map to robot base +X.
This is a relative wrist orientation mapping, not a measured palm/TCP offset.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import time

import numpy as np

from quest_teleop.config import ROOT
from .tracking import WristGate, latest_packets


def quaternion(q):
    q = np.asarray(q, dtype=float)
    if q.shape != (4,) or not np.isfinite(q).all():
        raise ValueError('four finite quaternion values required (xyzw)')
    n = np.linalg.norm(q)
    if not .9 <= n <= 1.1:
        raise ValueError('invalid quaternion norm')
    return q / n


def multiply(a, b):
    av, bv = a[:3], b[:3]
    return np.r_[a[3]*bv + b[3]*av + np.cross(av, bv), a[3]*b[3] - av@bv]


def rotation(q):
    x, y, z, w = quaternion(q)
    return np.array([
        [1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
        [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
        [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)],
    ])


def pose(values):
    p = np.asarray(values, dtype=float)
    if p.shape != (7,) or not np.isfinite(p).all():
        raise ValueError('seven finite pose values required')
    return np.r_[p[:3], quaternion(p[3:])]


def packet_pose(packet):
    return pose([packet['data'][k] for k in ('x', 'y', 'z', 'qx', 'qy', 'qz', 'qw')])


class WristMapper:
    def rebase(self, wrist, robot):
        """Keep the original control axes when recovering from a data gap."""
        self.wrist = pose(wrist)
        self.robot = pose(robot)
        self.previous_q = self.robot[3:].copy()

    def __init__(self, wrist, robot, head, scale=1.):
        self.rebase(wrist, robot)
        head = pose(head)
        if not math.isfinite(scale) or scale <= 0:
            raise ValueError('scale must be finite and positive')
        self.scale = scale
        # Y-up Unity world: project the initial head forward onto the floor.
        # Unity right/up/forward -> base forward/left/up has determinant -1.
        forward = rotation(head[3:]) @ [0., 0., 1.]
        forward[1] = 0.
        if np.linalg.norm(forward) < .2:
            raise ValueError('look horizontally when calibrating')
        forward /= np.linalg.norm(forward)
        up = np.array([0., 1., 0.])
        right = np.cross(up, forward)
        self.axes = np.array([forward, -right, up])

    def map(self, wrist):
        wrist = pose(wrist)
        position = self.robot[:3] + self.scale * self.axes @ (wrist[:3]-self.wrist[:3])
        # Express a world-frame rotation increment in a reflected basis:
        # R_delta_base = M R_delta_unity M^T. Quaternion vector parts are axial
        # vectors, so transform them with det(M)*M, not M alone.
        inverse = self.wrist[3:] * [-1., -1., -1., 1.]
        delta = multiply(wrist[3:], inverse)
        delta_base = np.r_[-self.axes @ delta[:3], delta[3]]
        q = quaternion(multiply(delta_base, self.robot[3:]))
        if q @ self.previous_q < 0:
            q = -q
        self.previous_q = q.copy()
        return np.r_[position, q]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, help='Default: newest logs/capture_*.jsonl; follow supplies its session capture')
    parser.add_argument('--scale', type=float, default=1.)
    parser.add_argument('--replay', action='store_true', help='Offline preview of the entire capture')
    parser.add_argument('--robot-pose', nargs=7, type=float, help='Explicit preview anchor; required for replay')
    parser.add_argument('--output', type=Path, default=ROOT/'logs')
    parser.add_argument('--stop-file',type=Path,help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not math.isfinite(args.scale) or args.scale <= 0:
        parser.error('scale must be finite and positive')
    if args.replay and args.robot_pose is None:
        parser.error('replay requires --robot-pose; never treat a stale robot pose as live')
    path = args.capture
    if path is None:
        paths = list((ROOT/'logs').glob('capture_*.jsonl'))
        if not paths:
            parser.error('no capture files')
        path = max(paths, key=lambda p: p.stat().st_mtime_ns)
    anchor = args.robot_pose
    if anchor is None:
        from quest_teleop.client import Robot
        anchor = Robot('ms-thor').state()['eef_right']
    anchor = pose(anchor)
    args.output.mkdir(parents=True, exist_ok=True)
    output = args.output / ('arm_preview_'+time.strftime('%Y%m%d_%H%M%S')+'.jsonl')
    print(json.dumps({'mode':'preview_no_motion', 'capture':str(path), 'anchor':anchor.tolist(), 'output':str(output)}), flush=True)
    mapper = None
    gate = WristGate()
    last_report = time.monotonic()
    count = 0
    failure = None
    try:
        with output.open('w', encoding='utf-8') as log:
            def emit(packets):
                nonlocal mapper, count, last_report
                if not args.replay and not gate.accept(packets, calibration=mapper is None):
                    return
                wrist = packet_pose(packets['Right/wrist'][1])
                if mapper is None or gate.restarted:
                    if not args.replay:
                        gate.fresh(packets['Head/pose'][0], time.time_ns())
                    mapper = WristMapper(wrist, anchor, packet_pose(packets['Head/pose'][1]), args.scale)
                    gate.restarted = False
                    print(json.dumps({'calibrated':True, 'unity_to_base_axes':mapper.axes.tolist()}), flush=True)
                target = mapper.map(wrist)
                delta = multiply(target[3:], anchor[3:]*[-1.,-1.,-1.,1.])
                angle = math.degrees(2*math.acos(float(np.clip(abs(delta[3]), 0., 1.))))
                sample = {'recv_unix_ns':packets['Right/wrist'][0]['recv_unix_ns'],
                          'source':packets['Right/wrist'][1].get('debug'),
                          'target_base_link':target.tolist(), 'delta_xyz_m':(target[:3]-anchor[:3]).tolist(),
                          'rotation_delta_deg':angle, 'mode':'preview_no_motion'}
                log.write(json.dumps(sample, allow_nan=False)+'\n')
                count += 1
                if time.monotonic()-last_report >= 1:
                    log.flush()
                    print(json.dumps(sample), flush=True)
                    last_report = time.monotonic()

            if args.replay:
                packets = {}
                last_seq = None
                with path.open(encoding='utf-8') as source:
                    for line in source:
                        rec = json.loads(line)
                        for packet in rec['packets']:
                            packets[packet.get('key')] = rec, packet
                        if all(k in packets for k in ('Right/wrist','Right/landmarks','Head/pose')):
                            seq = packets['Right/wrist'][1].get('debug')
                            if seq != last_seq:
                                emit(packets)
                                last_seq = seq
            else:
                while True:
                    if args.stop_file and args.stop_file.exists():
                        break
                    try:
                        emit(latest_packets(path))
                    except (FileNotFoundError, TimeoutError, ValueError, KeyError, TypeError):
                        pass  # Wait for a usable live sample; preview never moves devices.
                    time.sleep(.025)
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        failure = str(exc)
    summary = {'mode':'preview_no_motion', 'samples':count, 'failure':failure, 'output':str(output)}
    output.with_suffix('.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary), flush=True)
    if failure:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
