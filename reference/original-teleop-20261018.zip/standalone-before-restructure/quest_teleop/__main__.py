"""One CLI for follow, preview, diagnosis and device services."""
import argparse
from importlib import import_module
import os
import sys

COMMANDS = {
    'follow':'follow', 'receive':'quest_receive', 'hand':'quest_hand',
    'arm':'quest_arm', 'arm-follow':'quest_arm_follow', 'doctor':'doctor',
    'thor-driver':'drivers.thor', 'wuji-driver':'drivers.wuji',
}

def main():
    parser=argparse.ArgumentParser(description='Quest 3 -> Thor / Wuji Hand 2')
    parser.add_argument('--config',help='JSON configuration file')
    parser.add_argument('command',choices=COMMANDS)
    parser.add_argument('arguments',nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.config:
        from pathlib import Path
        os.environ['QUEST_TELEOP_CONFIG']=str(Path(args.config).expanduser().resolve())
    sys.argv=[sys.argv[0]+' '+args.command,*args.arguments]
    module=import_module('.'+COMMANDS[args.command],package=__package__)
    module.main()

if __name__ == '__main__':main()
