"""Read-only installation and optional connection checks; never acquire control."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from .config import load_config

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--offline',action='store_true',help='Skip device and USB checks')
    parser.add_argument('--hand',action='store_true',help='Build retargeter in current interpreter and test FK/solve')
    args=parser.parse_args()
    config=load_config()
    checks=[]
    def check(name,run):
        try:
            result=run()
            checks.append({'name':name,'ok':True,'detail':result})
        except Exception as error:
            checks.append({'name':name,'ok':False,'detail':str(error)})
    def module(name):
        if importlib.util.find_spec(name) is None:raise RuntimeError('missing '+name+'; run setup')
        return 'installed'
    for name in (('numpy','yaml') if args.hand else ('numpy','yaml','hand_tracking_sdk')):
        check(name,lambda n=name:module(n))
    def assets():
        paths=['assets/right.urdf','assets/retarget_right.yaml','assets/hand.json','_vendor/wuji_retargeting/retarget.py']
        for p in paths:
            if not (Path(__file__).parent/p).is_file():raise FileNotFoundError(p)
        return 'bundled'
    check('assets',assets)
    if args.hand:
        def hand():
            import numpy as np
            from .quest_hand import QuestRetarget
            mapper=QuestRetarget()
            points=mapper.fk(np.full(20,.1))*[1,1,-1]
            angles=mapper.solve(points)
            if len(angles) != 20 or not np.isfinite(angles).all():
                raise RuntimeError('retarget did not return 20 finite joints')
            return {'joints':len(angles),'finite':bool(np.isfinite(angles).all())}
        check('retarget',hand)
    if not args.offline:
        from .client import _get
        if config['transport']=='usb':
            def adb():
                from .runtime import find_adb
                result=subprocess.run([find_adb(),'devices'],capture_output=True,text=True,timeout=10)
                if result.returncode:raise RuntimeError(result.stderr)
                if not any(line.endswith('\tdevice') for line in result.stdout.splitlines()):
                    raise RuntimeError('Quest not authorized/connected: '+result.stdout.strip())
                return result.stdout.strip()
            check('USB',adb)
        for key in ('thor_url','wuji_url'):
            if config['only']=='hand' and key=='thor_url' or config['only']=='arm' and key=='wuji_url':continue
            def endpoint(k=key):
                result=_get(config[k]+'/ready',timeout=2)
                actual=result.get('backend','existing')
                if actual != config['backend']:
                    raise RuntimeError(f"configured {config['backend']} but endpoint reports {actual}")
                return {'ready':result.get('ready'),'backend':actual,'hardware_checked':result.get('hardware_checked')}
            check(key,endpoint)
        if config['backend']=='existing':
            check('legacy blackboard',lambda:_get(config['blackboard_url']+'/bb/state?robot=ms-thor',timeout=2).get('robot','reachable'))
    print(json.dumps({'backend':config['backend'],'python':sys.executable,'checks':checks},ensure_ascii=False,indent=2))
    if any(not c['ok'] for c in checks):raise SystemExit(1)
