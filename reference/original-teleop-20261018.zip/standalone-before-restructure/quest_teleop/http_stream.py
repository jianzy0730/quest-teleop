"""One persistent connection per follower; never retry an ambiguous target."""
from __future__ import annotations

import http.client
import json
import socket
import time
from urllib.parse import urlsplit
import uuid


class TransportError(RuntimeError):
    """Transport failed; target outcome is unknown until driver reconciliation."""


class CapConnection:
    def __init__(self, base, owner):
        url = urlsplit(base)
        if url.scheme not in ('http', 'https') or not url.hostname:
            raise ValueError('HTTP(S) driver endpoint required')
        cls = http.client.HTTPSConnection if url.scheme == 'https' else http.client.HTTPConnection
        self.connection = cls(url.hostname, url.port, timeout=.5)
        self.path = url.path.rstrip('/') + '/cap'
        self.owner = owner

    def post(self, name, args, timeout=.5):
        c = self.connection
        c.timeout = timeout
        begun = time.monotonic()
        phase = 'connect'
        try:
            if c.sock is None:
                c.connect()
                c.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            c.sock.settimeout(timeout)
            phase = 'send'
            body = json.dumps({'name':name, 'args':args, 'by':self.owner,
                               'request_id':'quest-'+uuid.uuid4().hex}).encode('utf-8')
            c.request('POST', self.path, body=body, headers={'Content-Type':'application/json'})
            phase = 'response'
            response = c.getresponse()
            payload = response.read()
            result = json.loads(payload)
            if response.status >= 400 and 'exit' not in result:
                raise RuntimeError(f'HTTP {response.status}: {result}')
            return result
        except (OSError, http.client.HTTPException) as exc:
            # The driver may already have accepted this target. Reconcile
            # through status and rebase before submitting a NEW source frame.
            self.close()
            raise TransportError(f'{name} HTTP {phase} after {time.monotonic()-begun:.3f}s: {exc}') from exc
        except Exception:
            self.close()
            raise

    def close(self):
        self.connection.close()
