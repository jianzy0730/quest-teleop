"""Small device client; no Harness package, manifests or Agent policies.

Standalone drivers own sessions locally. The existing backend implements only
the legacy lease protocol needed while migrating already deployed drivers.
"""
import json
import threading
import time
import urllib.error
import urllib.request
from .config import load_config

def _post(url, payload, timeout=15.):
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        body = error.read()
        try:
            result = json.loads(body)
        except (ValueError, UnicodeError):
            raise error
        if 'exit' in result:
            return result
        raise error

def _get(url, timeout=5.):
    # Readiness HTTP errors remain errors so the launcher can keep waiting.
    with urllib.request.urlopen(url, timeout=timeout) as response:
        return json.load(response)

class Robot:
    def __init__(self, name, by='quest-teleop', config=None):
        self.config = config or load_config()
        self.name, self.by = name, by
        self.base = self.config['thor_url' if name == 'ms-thor' else 'wuji_url'].rstrip('/')
        self.bb = self.config['blackboard_url'].rstrip('/')
        self._stop = threading.Event()
        self._thread = None

    def _session(self, operation, ttl_s=6.):
        if self.config['backend'] == 'existing':
            return _post(self.bb+'/bb/'+operation, {'robot':self.name,'by':self.by,'ttl_s':ttl_s,'op':'teleop'}, timeout=3)
        return _post(self.base+'/session/'+operation, {'by':self.by,'ttl_s':ttl_s}, timeout=3)

    def acquire(self, ttl_s=6.):
        ready = _get(self.base+'/ready', timeout=3)
        actual = ready.get('backend', 'existing')
        if actual != self.config['backend']:
            raise RuntimeError(f"driver backend is {actual}, configured {self.config['backend']}; check config.local.json")
        result = self._session('lease', ttl_s)
        if not result.get('granted'):
            raise RuntimeError('control denied: '+str(result))
        self._stop.clear()
        def heartbeat():
            while not self._stop.wait(min(1., ttl_s/3)):
                try:
                    response = self._session('heartbeat',ttl_s)
                    key = 'ok' if self.config['backend'] == 'existing' else 'granted'
                    if not response.get(key):
                        self._stop.set()
                except (OSError, ValueError):
                    pass  # Driver enforces expiry; never renew an expired session here.
        self._thread = threading.Thread(target=heartbeat,daemon=True)
        self._thread.start()
        if self.config['backend'] == 'existing':
            time.sleep(1.2 if self.name == 'ms-thor' else .3)
        return result

    def release(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=4)
        return self._session('release')

    def cap(self, name, args=None, timeout=None, request_id=None):
        return _post(self.base+'/cap', {'name':name,'args':args or {},'by':self.by,'request_id':request_id}, timeout=timeout or 15.)

    def state(self):
        state = _get(self.base+'/state')
        state.setdefault('updated_at', state.get('t',time.time()))
        return state

