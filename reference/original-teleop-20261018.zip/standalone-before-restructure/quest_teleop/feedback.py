import math
import time
import numpy as np
from .quest_arm import pose, quaternion

def angle_deg(a, b):
    return math.degrees(2 * math.acos(float(np.clip(abs(quaternion(a) @ quaternion(b)), 0., 1.))))

def fresh_pose(state):
    now = time.time()
    stamp = state.get('perception', {}).get('streams', {}).get('eef_right', {}).get('source_t', 0)
    if not 0 <= now-state.get('updated_at', 0) <= .5 or not 0 <= now-stamp <= .5:
        raise RuntimeError('stale end effector feedback')
    if not state.get('perception', {}).get('ready'):
        raise RuntimeError('perception not ready')
    return pose(state['eef_right']), stamp
