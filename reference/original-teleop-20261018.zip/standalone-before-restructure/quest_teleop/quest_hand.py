"""Quest right-hand preview and Wuji Hand 2 follow, stopped with Ctrl+C.

Run in the isolated WSL retarget environment. Preview is the default. Recorded
replay can only be used for offline inspection; execute requires fresh input.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
import json
import math
from pathlib import Path
import sys
import time
import uuid

from quest_teleop.config import ROOT
from .tracking import LiveGate, latest_right
VENDOR = Path(__file__).resolve().parent / '_vendor'
ASSETS = Path(__file__).resolve().parent / 'assets'
sys.path.insert(0, str(VENDOR))

import numpy as np
import yaml

from quest_teleop.http_stream import CapConnection, TransportError


class QuestRetarget:
    def __init__(self, filter_alpha=1.):
        from wuji_retargeting import Retargeter
        from wuji_retargeting.mediapipe import estimate_frame_from_hand_points, OPERATOR2MANO_RIGHT
        from scipy.spatial.transform import Rotation
        config = yaml.safe_load((ASSETS / 'retarget_right.yaml').read_text())
        config['__yaml_dir'] = str(ASSETS)
        if not math.isfinite(filter_alpha) or not 0 < filter_alpha <= 1:
            raise ValueError('filter alpha must be in (0,1]')
        config['retarget']['lp_alpha'] = filter_alpha
        self.retargeter = Retargeter.from_config(config, 'right')
        robot = self.retargeter.optimizer.robot
        fingers = ['thumb', 'index_finger', 'middle_finger', 'ring_finger', 'pinky']
        expected = []
        for f in fingers:
            suffixes = ['cmc_flex', 'cmc_abd', 'mcp', 'ip'] if f == 'thumb' else ['mcp_flex', 'mcp_abd', 'pip', 'dip']
            expected.extend(f'r_{f}_{s}' for s in suffixes)
        self.order = []
        for name in expected:
            joint_id = robot.model.getJointId(name)
            if joint_id >= robot.model.njoints or robot.model.joints[joint_id].nq != 1:
                raise RuntimeError('unexpected Hand 2 model joint: ' + name)
            self.order.append(int(robot.model.joints[joint_id].idx_q))
        if sorted(self.order) != list(range(20)):
            raise RuntimeError('Hand 2 model joint mapping is not bijective')
        self.frame_names = ['r_wrist'] + [f'r_{f}_{link}' for f in fingers for link in ['proximal_abd', 'middle', 'distal', 'tip']]
        model_points = self.fk(np.zeros(20))
        # Derive canonical-to-model rotation from the model's own palm frame.
        # It is device independent and also removes the model palm's slight tilt.
        rotation = estimate_frame_from_hand_points(model_points) @ OPERATOR2MANO_RIGHT
        angles = Rotation.from_matrix(rotation).as_euler('xyz', degrees=True)
        self.retargeter.rotation_xyz = dict(zip('xyz', angles.tolist()))
        driver_config = json.loads((ASSETS/'hand.json').read_text(encoding='utf-8'))
        self.limits = np.asarray(driver_config['gestures']['joint_limits_rad'])
        if not np.allclose(robot.joint_limits[self.order], self.limits, atol=1e-6):
            raise RuntimeError('retarget model and driver joint limits differ')
        self.mapping = dict(zip(expected, self.order))

    def fk(self, q_sdk):
        robot = self.retargeter.optimizer.robot
        q = np.zeros(20)
        q[self.order] = q_sdk
        robot.compute_forward_kinematics(q)
        return np.array([robot.get_link_pose(robot.get_link_index(n))[:3, 3] for n in self.frame_names])

    @staticmethod
    def validate(points):
        p = np.asarray(points, dtype=float)
        if p.shape != (21, 3) or not np.all(np.isfinite(p)):
            raise ValueError('21 finite xyz keypoints required')
        palm_a, palm_b = p[5]-p[0], p[9]-p[0]
        if not .03 < np.linalg.norm(palm_a) < .18 or not .03 < np.linalg.norm(palm_b) < .18:
            raise ValueError('invalid palm size / units')
        if np.linalg.norm(np.cross(palm_a, palm_b)) < .00015:
            raise ValueError('degenerate palm geometry')
        for base in (1, 5, 9, 13, 17):
            lengths = np.linalg.norm(np.diff(p[base:base+4], axis=0), axis=1)
            if np.any(lengths < .006) or np.any(lengths > .085):
                raise ValueError('invalid finger geometry')
        return p

    def solve(self, points):
        # Unity is left handed. Reflect once before constructing the anatomical
        # right-handed palm frame. Points are wrist-local metres already.
        p = self.validate(points) * [1, 1, -1]
        q = self.retargeter.retarget(p)[self.order]
        if q.shape != (20,) or not np.all(np.isfinite(q)):
            self.retargeter.reset()
            raise ValueError('invalid retarget output')
        return np.clip(q, self.limits[:, 0], self.limits[:, 1])


def checked(robot, name, args=None, timeout=None, connection=None):
    timeout = timeout if timeout is not None else (.2 if name == 'stream_target' else 10.)
    begun = time.monotonic()
    try:
        if connection is not None and name in ('stream_target', 'stream_status'):
            result = connection.post(name, args or {}, timeout=timeout)
        else:
            result = robot.cap(name, args, timeout=timeout, request_id=f'quest-{name}-{uuid.uuid4().hex}')
    except (TimeoutError, OSError) as exc:
        raise RuntimeError(f'{name} after {time.monotonic()-begun:.3f}s (HTTP timeout {timeout}s): {exc}') from exc
    if name == 'stream_start' and result.get('exit') == 'busy' and result.get('completion') == 'not_started':
        return result
    if result.get('exit') != 'success':
        raise RuntimeError(f'{name}: {result}')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--velocity', type=float, default=None, help='Optional software slew rate in rad/s; default sends latest retarget target directly')
    parser.add_argument('--filter-alpha', type=float, default=1., help='Upstream retarget low pass: default 1 disables smoothing')
    parser.add_argument('--stop-file', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--owner', default=None, help=argparse.SUPPRESS)
    parser.add_argument('--replay', action='store_true', help='Offline preview only')
    parser.add_argument('--output', type=Path, default=ROOT/'logs')
    args = parser.parse_args()
    if args.velocity is not None and (not math.isfinite(args.velocity) or args.velocity <= 0):
        parser.error('velocity must be finite and positive')
    if args.replay and args.execute:
        parser.error('replay cannot execute')
    mapper = QuestRetarget(args.filter_alpha)
    print(json.dumps({'joint_mapping':mapper.mapping, 'rotation':mapper.retargeter.rotation_xyz}), flush=True)
    args.output.mkdir(parents=True, exist_ok=True)
    log_path = args.output / ('follow_' + time.strftime('%Y%m%d_%H%M%S') + '.jsonl')
    robot = None
    connection = None
    status = None
    gate = LiveGate()
    session_id = None
    status_ready = False
    begun = time.monotonic()
    preview_samples = 0
    last_report = 0
    last_hardware_warning = -math.inf
    previous_hardware_limits = None
    previous_diagnostic_warnings = None
    last_diagnostic_warning = -math.inf
    last_tracking_warning = -math.inf
    last_pause_report = -math.inf
    failure = None
    timing = {}
    try:
        with ExitStack() as stack:
            log = stack.enter_context(log_path.open('w', encoding='utf-8'))
            if args.replay:
                source = stack.enter_context(args.capture.open(encoding='utf-8'))
                replay = ((rec, packet) for rec in map(json.loads, source)
                          for packet in rec['packets'] if packet.get('key') == 'Right/landmarks')
            while True:
                if args.stop_file and args.stop_file.exists():
                    break
                try:
                    rec, packet = next(replay) if args.replay else latest_right(args.capture)
                except StopIteration:
                    break
                except (FileNotFoundError, ValueError) as exc:
                    if robot is not None:
                        if time.monotonic()-last_pause_report > 2:
                            print(json.dumps({'warning':'Quest input unavailable; hand paused','detail':str(exc)}),flush=True)
                            last_pause_report = time.monotonic()
                        time.sleep(.05)
                        continue
                    if args.replay:
                        raise
                    time.sleep(.05)
                    continue
                try:
                    accepted = args.replay or gate.accept(rec, packet)
                except (TimeoutError, ValueError, KeyError, TypeError) as exc:
                    if time.monotonic()-last_pause_report > 2:
                        print(json.dumps({'warning':'Quest input delayed; hand paused','detail':str(exc)}),flush=True)
                        last_pause_report = time.monotonic()
                    time.sleep(.05)
                    continue
                if not accepted:
                    time.sleep(.01)
                    continue
                t = time.monotonic()
                timing = {'input_age_ms':(time.time_ns()-rec['recv_unix_ns'])/1e6}
                try:
                    q = mapper.solve(packet['data']['points'])
                    if not args.replay:
                        gate.fresh(rec, time.time_ns())
                except (ValueError, KeyError, TypeError, IndexError, TimeoutError) as error:
                    if time.monotonic()-last_pause_report > 2:
                        print(json.dumps({'warning':'hand sample skipped; waiting for fresh valid input',
                                          'detail':str(error)}),flush=True)
                        last_pause_report = time.monotonic()
                    time.sleep(.005)
                    continue
                if gate.restarted:
                    status_ready = False
                    gate.restarted = False
                    print(json.dumps({'warning':'Quest source restarted; hand resumes absolute poses'}),flush=True)
                timing['retarget_ms'] = (time.monotonic()-t)*1000
                preview_samples += 1
                if args.execute:
                    # Warm up on one second of fresh, advancing source frames.
                    if robot is None and preview_samples >= 20 and time.monotonic()-begun >= 1:
                        from quest_teleop.client import Robot
                        robot = Robot('wuji-hand', by=args.owner or 'quest-hand-' + uuid.uuid4().hex)
                        connection = CapConnection(robot.base, robot.by)
                        robot.acquire(ttl_s=6)
                    if robot is not None:
                        if session_id is None:
                            t_start = time.monotonic()
                            # Native SDK discovery/connection can delay this
                            # request. This does not change the live watchdog.
                            start_args = {'side':'right', 'velocity_rad_s':args.velocity}
                            if robot.config['backend'] == 'existing':
                                start_args['duration_s'] = 0  # Legacy driver defaults to 20 seconds.
                            status = checked(robot, 'stream_start', start_args)
                            timing['start_ms'] = (time.monotonic()-t_start)*1000
                            if status.get('exit') == 'busy' and status.get('completion') == 'not_started':
                                # Discovery shares the driver lock. A definite
                                # not_started response permits waiting/retrying.
                                time.sleep(.05)
                                continue
                            session_id = status['session_id']
                        t_status = time.monotonic()
                        if not status_ready:
                            try:
                                status = checked(robot, 'stream_status', connection=connection)
                            except TransportError as error:
                                print(json.dumps({'warning':'hand connection delayed; waiting','detail':str(error)}),flush=True)
                                time.sleep(.05)
                                continue
                        timing['status_ms'] = (time.monotonic()-t_status)*1000
                        if status['phase'] == 'stopped':
                            if status.get('diagnosis'):
                                raise RuntimeError(status['diagnosis'])
                            break
                        if status['phase'] in ('awaiting_input', 'paused', 'rebasing', 'running') and not status_ready:
                            if (time.time_ns()-rec['recv_unix_ns'])/1e9 > .2:
                                # Pick a fresh frame after connection/preflight.
                                continue
                            status_ready = True
                        if status_ready:
                            if args.stop_file and args.stop_file.exists():
                                break
                            # Recheck file/source freshness after HTTP and IK.
                            if (time.time_ns()-rec['recv_unix_ns'])/1e9 > .2:
                                time.sleep(.05)
                                continue
                            # Fingers follow the absolute retarget pose, even
                            # after input gaps. Never subtract the user's
                            # initial curl or offset by the robot's start pose.
                            t_target = time.monotonic()
                            try:
                                status = checked(robot, 'stream_target', {'session_id':session_id, 'seq':gate.seq, 'positions_rad':q.tolist()}, connection=connection)
                            except TransportError as error:
                                status_ready = False
                                print(json.dumps({'warning':'hand HTTP delayed; waiting without replaying target','detail':str(error)}),flush=True)
                                continue
                            timing['target_ms'] = (time.monotonic()-t_target)*1000
                            hardware_limits = (status.get('position_limit_joints', []),
                                               status.get('limit_clamped_joints', []),
                                               status.get('limit_direction_unknown', []),
                                               status.get('feedback_limit_joints', []))
                            now = time.monotonic()
                            if any(hardware_limits) and (hardware_limits != previous_hardware_limits or now-last_hardware_warning >= 1):
                                print(json.dumps({'warning':'hand position limit; following continues',
                                                  'active_joints':hardware_limits[0],
                                                  'clamped_joints':hardware_limits[1],
                                                  'held_until_limit_clears':hardware_limits[2],
                                                  'feedback_outside_model':hardware_limits[3]}),flush=True)
                                last_hardware_warning = now
                            previous_hardware_limits = hardware_limits
                            diagnostic_warnings = status.get('diagnostic_warnings', [])
                            if diagnostic_warnings and (diagnostic_warnings != previous_diagnostic_warnings or now-last_diagnostic_warning >= 2):
                                print(json.dumps({'warning':'hand firmware warning; following continues',
                                                  'diagnostics':diagnostic_warnings}),flush=True)
                                last_diagnostic_warning = now
                            previous_diagnostic_warnings = diagnostic_warnings
                            tracking_warning = status.get('tracking_warning')
                            if tracking_warning and now-last_tracking_warning >= 2:
                                print(json.dumps({'warning':'hand tracking lag; following continues',
                                                  'detail':tracking_warning}),flush=True)
                                last_tracking_warning = now
                            if status.get('completion') == 'rebase_required':
                                # Driver holds measured pose for this handshake;
                                # next fresh frame resumes absolute targets.
                                print(json.dumps({'warning':'Quest input resumed; hand will follow next absolute pose'}),flush=True)
                sample = {'at':time.time(), 'source':packet.get('debug'), 'mapping_mode':'absolute',
                          'retarget_rad':q.tolist(),
                          'timing_ms':timing, 'stream':status}
                log.write(json.dumps(sample)+'\n')
                log.flush()
                if time.monotonic()-last_report > 1:
                    print(json.dumps({'preview_samples':preview_samples, 'phase':status.get('phase') if status else 'preview', 'q_sdk':q.round(3).tolist()}), flush=True)
                    last_report = time.monotonic()
                time.sleep(.005)
    except KeyboardInterrupt:
        print('STOP: Ctrl+C', flush=True)
    except Exception as exc:
        failure = str(exc) or type(exc).__name__
        print('STOP: ' + failure + ' ' + json.dumps(timing), flush=True)
    finally:
        if connection is not None:
            connection.close()
        if robot is not None:
            try:
                if status is None or status.get('phase') != 'stopped':
                    robot.cap('cancel_motion', {}, timeout=3)
                deadline = time.monotonic()+5
                while time.monotonic() < deadline:
                    status = checked(robot, 'stream_status', timeout=3)
                    if status['phase'] == 'stopped':
                        break
                    time.sleep(.05)
            except Exception as exc:
                failure = (failure or '') + '; cleanup: ' + str(exc)
            finally:
                robot.release()
        summary = {'execute':args.execute, 'samples':preview_samples, 'failure':failure, 'last_timing_ms':timing, 'final_stream':status, 'log':str(log_path)}
        log_path.with_suffix('.json').write_text(json.dumps(summary, indent=2))
        print(json.dumps(summary), flush=True)
    if failure:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
