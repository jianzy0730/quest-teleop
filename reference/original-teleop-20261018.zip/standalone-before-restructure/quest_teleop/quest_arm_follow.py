"""Live Quest right wrist to Thor right EEF. Ctrl+C stops."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import time
import uuid
import urllib.error

import numpy as np

from .config import ROOT
from .tracking import WristGate, latest_packets
from .quest_arm import WristMapper, packet_pose, pose
from .feedback import angle_deg, fresh_pose
from .http_stream import CapConnection, TransportError


def check_driver(robot, timeout=None):
    """Read-only protocol check before acquiring control or enabling a hand."""
    from quest_teleop.client import _get
    ready = (_get(robot.base+'/ready') if timeout is None else
             _get(robot.base+'/ready', timeout=timeout))
    config = getattr(robot, 'config', {})
    if isinstance(config, dict) and config.get('backend') == 'standalone' and ready.get('backend') != 'standalone':
        raise RuntimeError('Standalone mode needs the bundled thor-driver; current endpoint is a legacy driver. Use backend=existing during migration.')
    missing = {'servo_start', 'servo_target', 'servo_status'} - set(ready.get('capabilities', []))
    if missing:
        raise RuntimeError('Thor driver is outdated: missing '+', '.join(sorted(missing))+
                           '; update the Thor device service')
    servo = ready.get('servo', {})
    if servo.get('distance_limit_policy') not in ('hold', 'disabled'):
        raise RuntimeError('Thor driver needs the limit-hold update; update the Thor device service')
    if config.get('arm_limit_policy', 'vendor_ik') == 'vendor_ik' and not servo.get('supports_vendor_ik'):
        raise RuntimeError('Thor driver needs the vendor-IK teleop update; update its streaming module')
    return ready


def wait_for_driver(robot, check_pending=lambda: None):
    """Wait without a lease or motion; only transient connection failures retry."""
    last_report = -math.inf
    while True:
        check_pending()
        try:
            return check_driver(robot, timeout=2)
        except (OSError, urllib.error.URLError) as error:
            if isinstance(error, urllib.error.HTTPError) and error.code not in (408,429,500,502,503,504):
                raise
            now = time.monotonic()
            if now-last_report >= 5:
                print('Waiting for Thor driver at '+robot.base+
                      '; connection unavailable: '+str(error)+'. Retrying; Ctrl+C stops.',flush=True)
                last_report = now
        retry_at = time.monotonic()+2
        while time.monotonic() < retry_at:
            check_pending()
            time.sleep(.1)


def recover_mapping(mapper, wrist, actual, phase):
    # A slow/lost HTTP response does not mean the robot paused. Rebasing a
    # still-running session discards rotation error and shifts the wrist zero.
    if phase in ('paused', 'awaiting_input'):
        mapper.rebase(wrist, actual)
        return True
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--scale', type=float, default=1.0)
    parser.add_argument('--output', type=Path, default=ROOT/'logs')
    parser.add_argument('--stop-file', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--owner', default=None, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not math.isfinite(args.scale) or args.scale <= 0:
        parser.error('scale must be finite and positive')
    from quest_teleop.client import Robot
    robot = Robot('ms-thor', by=args.owner or 'task-quest-arm-'+uuid.uuid4().hex)
    connection = CapConnection(robot.base, robot.by)
    gate = WristGate()
    session = mapper = None
    last_report = time.monotonic()
    actual = stamp = None
    sent = 0
    last_warning = -math.inf
    previous_limits = []
    failure = None
    acquired = False
    needs_rebase = False
    last_pause_report = -math.inf
    args.output.mkdir(parents=True, exist_ok=True)
    log_path = args.output/('arm_follow_'+time.strftime('%Y%m%d_%H%M%S')+'.jsonl')
    print(json.dumps({'mode':'live_arm_follow','capture':str(args.capture),'log':str(log_path)}),flush=True)
    try:
        def check_pending():
            if args.stop_file and args.stop_file.exists():
                raise KeyboardInterrupt
        wait_for_driver(robot, check_pending)
        with log_path.open('w', encoding='utf-8') as log:
            while True:
                if args.stop_file and args.stop_file.exists():
                    break
                try:
                    packets = latest_packets(args.capture)
                except (FileNotFoundError, ValueError):
                    if session is not None:
                        needs_rebase = True
                        if time.monotonic()-last_pause_report > 2:
                            print(json.dumps({'warning':'Quest input unavailable; arm paused'}),flush=True)
                            last_pause_report = time.monotonic()
                        time.sleep(.05)
                        continue
                    time.sleep(.02)
                    continue
                try:
                    accepted = gate.accept(packets, calibration=mapper is None)
                    wrist = packet_pose(packets['Right/wrist'][1])
                    if mapper is None or gate.restarted:
                        gate.fresh(packets['Head/pose'][0], time.time_ns())
                        head = packet_pose(packets['Head/pose'][1])
                except (TimeoutError, ValueError, KeyError, TypeError) as error:
                    needs_rebase = mapper is not None
                    if time.monotonic()-last_pause_report > 2:
                        print(json.dumps({'warning':'Quest input delayed; arm paused','detail':str(error)}),flush=True)
                        last_pause_report = time.monotonic()
                    time.sleep(.05)
                    continue
                if not accepted:
                    time.sleep(.005)
                    continue
                if session is None:
                    robot.acquire(ttl_s=6)
                    acquired = True
                    anchor, stamp = fresh_pose(robot.state())
                    control = robot.cap('control_state',{})
                    if control.get('exit') != 'success' or not control['control']['prepared']:
                        raise RuntimeError('Thor mode/input is not prepared; configure control path first')
                    session = robot.cap('servo_start', {'limit_policy':'vendor_ik'} if robot.config['arm_limit_policy'] == 'vendor_ik' else {})
                    if session.get('exit') != 'success':
                        raise RuntimeError('servo_start: '+str(session))
                    # Acquisition/preparation takes seconds. Clutch to a NEW
                    # source frame after preparation, never the old first frame.
                    gate = WristGate()
                    continue
                if mapper is None or gate.restarted:
                    anchor, stamp = fresh_pose(robot.state())
                    if (time.time_ns()-packets['Right/wrist'][0]['recv_unix_ns'])/1e9 > .2:
                        continue
                    try:
                        mapper = WristMapper(wrist, anchor, head, args.scale)
                    except ValueError as error:
                        if time.monotonic()-last_pause_report > 2:
                            print(json.dumps({'warning':'waiting for calibration pose','detail':str(error)}),flush=True)
                            last_pause_report = time.monotonic()
                        continue
                    gate.restarted = needs_rebase = False
                    actual = anchor
                    calibration = {'calibrated':True,'anchor':anchor.tolist(),
                                   'wrist':wrist.tolist(),'axes':mapper.axes.tolist()}
                    print(json.dumps(calibration),flush=True)
                    log.write(json.dumps(calibration)+'\n')
                    continue
                if (time.time_ns()-packets['Right/wrist'][0]['recv_unix_ns'])/1e9 > .2:
                    time.sleep(.05)
                    continue
                now = time.monotonic()
                if needs_rebase or time.time()-stamp > .2:
                    try:
                        status = connection.post('servo_status', {}, timeout=.5)
                    except TransportError as error:
                        needs_rebase = True
                        if now-last_pause_report > 2:
                            print(json.dumps({'warning':'arm connection delayed; waiting','detail':str(error)}),flush=True)
                            last_pause_report = now
                        time.sleep(.05)
                        continue
                    if status.get('exit') != 'success' or status.get('phase') == 'stopped':
                        raise RuntimeError('servo_status: '+str(status))
                    actual, stamp = fresh_pose({'updated_at':time.time(), 'eef_right':status['eef_right'],
                        'perception':{'ready':True,'streams':{'eef_right':{'source_t':status['source_t']}}}})
                    rebased = recover_mapping(mapper, wrist, actual, status['phase'])
                    log.write(json.dumps({'event':'feedback_recovered','phase':status['phase'],
                        'rebased':rebased,'wrist':wrist.tolist(),'actual':actual.tolist()})+'\n')
                    needs_rebase = False
                    continue
                # Each driver response supplies fresh measured feedback; the
                # driver checks the lease on every target. A blackboard GET
                # here can block past the 250 ms input watchdog.
                requested = mapper.map(wrist)
                state = {'updated_at':time.time(),'eef_right':actual.tolist(),
                         'perception':{'ready':True,'streams':{'eef_right':{'source_t':stamp}}}}
                fresh_pose(state)
                target = pose(requested)
                t_target = time.monotonic()
                try:
                    result = connection.post('servo_target', {
                        'session_id':session['session_id'],'seq':gate.seq,'pose':target.tolist()}, timeout=.5)
                except TransportError as error:
                    needs_rebase = True
                    print(json.dumps({'warning':'arm HTTP delayed; waiting without replaying target','detail':str(error)}),flush=True)
                    continue
                target_ms = (time.monotonic()-t_target)*1000
                if result.get('exit') != 'success':
                    raise RuntimeError('servo_target: '+str(result))
                if result.get('completion') == 'rebase_required':
                    actual = np.asarray(result['eef_right'], dtype=float)
                    stamp = result['source_t']
                    mapper.rebase(wrist, actual)
                    warning = {'warning':'Quest input resumed; arm rebased at current pose',
                               'wrist':wrist.tolist(),'actual':actual.tolist()}
                    print(json.dumps(warning),flush=True)
                    log.write(json.dumps(warning)+'\n')
                    continue
                target = np.asarray(result.get('target_pose', target), dtype=float)
                limited = result.get('limited_axes', [])
                if limited and (limited != previous_limits or now-last_warning >= 1):
                    warning = {'warning':'arm limit reached; pose held, return inside limits to resume',
                               'limits':limited,'requested':requested.tolist(),'target':target.tolist()}
                    print(json.dumps(warning),flush=True)
                    log.write(json.dumps(warning)+'\n')
                    last_warning = now
                elif previous_limits and not limited:
                    print(json.dumps({'warning':'target back inside limits; following continues'}),flush=True)
                previous_limits = limited
                feedback = {'updated_at':time.time(),'eef_right':result['eef_right'],
                            'perception':{'ready':True,'streams':{'eef_right':{'source_t':result['source_t']}}}}
                actual, stamp = fresh_pose(feedback)
                sent += 1
                row = {'at':time.time(),'seq':gate.seq,'target':target.tolist(),
                       'wrist':wrist.tolist(),'completion':result.get('completion'),
                       'requested':requested.tolist(),'limited_axes':limited,
                       'target_ms':target_ms,
                       'actual':actual.tolist(),'position_error_m':float(np.linalg.norm(target[:3]-actual[:3])),
                       'rotation_error_deg':angle_deg(target[3:],actual[3:])}
                log.write(json.dumps(row)+'\n')
                if now-last_report >= 1:
                    print(json.dumps({'sent':sent,**row}),flush=True)
                    log.flush()
                    last_report = now
                time.sleep(.005)
    except KeyboardInterrupt:
        print('STOP: Ctrl+C',flush=True)
    except Exception as error:
        failure = str(error)
        print('STOP: '+failure,flush=True)
    finally:
        connection.close()
        if acquired:
            try:
                print(json.dumps({'stop':robot.cap('stop_motion',{})}),flush=True)
            finally:
                print(json.dumps({'release':robot.release()}),flush=True)
        summary={'sent':sent,'failure':failure,'log':str(log_path)}
        log_path.with_suffix('.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
        print(json.dumps(summary),flush=True)
    if failure:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
