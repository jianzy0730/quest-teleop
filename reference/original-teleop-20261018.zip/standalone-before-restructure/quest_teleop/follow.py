"""One-command Windows launcher for Quest USB/Wi-Fi, Thor arm and Wuji hand."""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import uuid

from .config import ROOT, load_config
from .tracking import LiveGate, WristGate, latest_packets, latest_right
from .runtime import hand_command, adb_reverse


def main():
    config = load_config()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only', choices=['arm','hand','both'], default=config['only'])
    parser.add_argument('--transport', choices=['usb','udp'], default=config['transport'])
    parser.add_argument('--port',type=int,default=config['port'])
    parser.add_argument('--scale', type=float, default=config['scale'], help='Arm translation scale; rotation is 1:1')
    parser.add_argument('--hand-velocity', type=float, help='Optional additional joint target slew rad/s; default none')
    parser.add_argument('--filter-alpha',type=float,default=config['filter_alpha'],help='Upstream hand low-pass alpha; default 1 disables smoothing')
    parser.add_argument('--capture',type=Path,help='Use an existing LIVE receiver capture instead of starting a receiver')
    parser.add_argument('--preview', action='store_true',help='Receive and map inputs without robot motion')
    parser.add_argument('--duration',type=float,default=0,help='Optional test duration in seconds; 0 until Ctrl+C')
    args = parser.parse_args()
    if not math.isfinite(args.scale) or args.scale <= 0 or not 0 < args.filter_alpha <= 1:
        parser.error('positive finite scale and filter alpha in (0,1] required')
    if args.hand_velocity is not None and (not math.isfinite(args.hand_velocity) or args.hand_velocity <= 0):
        parser.error('hand-velocity must be positive and finite')
    if not math.isfinite(args.duration) or args.duration < 0:
        parser.error('duration must be finite and nonnegative')
    if args.port is None:
        args.port = 8000 if args.transport == 'usb' else 9000
    if not 1 <= args.port <= 65535:
        parser.error('port must be 1..65535')
    output = ROOT/'logs'/('session_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6])
    output.mkdir(parents=True)
    config.update(only=args.only,transport=args.transport,port=args.port,scale=args.scale,filter_alpha=args.filter_alpha)
    effective_config = output/'config.json'
    effective_config.write_text(json.dumps(config,indent=2),encoding='utf-8')
    previous_config = os.environ.get('QUEST_TELEOP_CONFIG')
    os.environ['QUEST_TELEOP_CONFIG'] = str(effective_config)
    stop = output/'STOP'
    capture = args.capture.resolve() if args.capture else output/'capture.jsonl'
    children, logs, owners = {}, {}, {}
    failed = None
    def launch(name, command):
        logs[name] = (output/(name+'.log')).open('w',encoding='utf-8')
        env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
        children[name] = subprocess.Popen(command,cwd=ROOT,env=env,stdout=logs[name],stderr=subprocess.STDOUT,
                                          creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    print('Session: '+str(output),flush=True)
    def check_children():
        if stop.exists():
            raise KeyboardInterrupt
        for name, child in children.items():
            if child.poll() is not None:
                raise RuntimeError(name+' exited; see '+str(output/(name+'.log')))
    def input_ready():
        if args.only == 'hand':
            return LiveGate().accept(*latest_right(capture))
        return WristGate().accept(latest_packets(capture), calibration=True)
    try:
        if not args.capture:
            with socket.socket(socket.AF_INET,socket.SOCK_STREAM if args.transport=='usb' else socket.SOCK_DGRAM) as probe:
                try:
                    probe.bind(('127.0.0.1' if args.transport=='usb' else '0.0.0.0',args.port))
                except OSError as error:
                    if error.errno in (98,10048) or getattr(error, 'winerror', None) == 10048:
                        raise RuntimeError(f'Port {args.port} is already in use. Stop the previous receiver/follow console with Ctrl+C, or use --capture <its live capture.jsonl>.') from error
                    raise
            if args.transport == 'usb':
                adb_reverse(args.port, stop)
            launch('receive',[sys.executable,'-u','-m','quest_teleop','receive',
                '--transport','tcp' if args.transport=='usb' else 'udp','--host','127.0.0.1' if args.transport=='usb' else '0.0.0.0',
                '--port',str(args.port),'--capture',str(capture),'--output',str(output),'--stop-file',str(stop)])
        streams = 'right-hand landmarks' if args.only == 'hand' else 'right wrist + landmarks + Head Pose'
        print('Waiting for live Quest '+streams+'. Start Streaming; Video Feed OFF. Ctrl+C stops.',flush=True)
        while True:
            check_children()
            try:
                live = input_ready()
            except (ValueError,FileNotFoundError,TimeoutError):
                live = False
            if live:
                if not args.preview and args.only in ('both','arm'):
                    from quest_teleop.client import Robot
                    from .quest_arm_follow import wait_for_driver
                    ready = wait_for_driver(Robot('ms-thor'), check_children)
                    print('Thor driver connected; control '+json.dumps(ready.get('control', {})),flush=True)
                    # Driver recovery may take minutes; require a fresh Quest
                    # frame before starting either follower, not the old one.
                    try:
                        if not input_ready():
                            continue
                    except (ValueError,FileNotFoundError,TimeoutError):
                        print('Waiting for live Quest input again. Ctrl+C stops.',flush=True)
                        continue
                break
            time.sleep(.05)
        if args.only in ('both','arm'):
            owners['arm'] = 'task-quest-arm-'+uuid.uuid4().hex
            command = [sys.executable,'-u','-m','quest_teleop','arm' if args.preview else 'arm-follow',
                       '--capture',str(capture),'--scale',str(args.scale),'--output',str(output),'--stop-file',str(stop)]
            if not args.preview:
                command += ['--owner',owners['arm']]
            else:
                command += ['--robot-pose','0','0','0','0','0','0','1']
            launch('arm',command)
        if args.only in ('both','hand'):
            owners['hand'] = 'quest-hand-'+uuid.uuid4().hex
            command = hand_command(config, ROOT, capture, output, stop, owners['hand'], args.filter_alpha, effective_config)
            if not args.preview:
                command += ['--execute']
            if args.hand_velocity is not None:
                command += ['--velocity',str(args.hand_velocity)]
            launch('hand',command)
        print('Live input received. Starting '+args.only+'; keep hand visible during calibration. Logs: '+str(output),flush=True)
        positions={name:0 for name in children}
        started=time.monotonic()
        while True:
            if args.duration and time.monotonic()-started >= args.duration:
                break
            for name,child in children.items():
                if child.poll() is not None:
                    raise RuntimeError(f'{name} exited ({child.returncode}); all followers stopping')
                if name == 'receive':
                    continue
                with (output/(name+'.log')).open(encoding='utf-8',errors='replace') as log:
                    log.seek(positions[name])
                    lines=log.readlines()
                    positions[name]=log.tell()
                for line in lines:
                    try:
                        row=json.loads(line)
                    except ValueError:
                        continue
                    if 'warning' in row:
                        print('['+name+'] WARNING: '+str(row['warning'])+
                              ' '+json.dumps({k:v for k,v in row.items() if k != 'warning'}),flush=True)
                    elif row.get('calibrated'):
                        print('[arm] calibrated; following wrist XYZ + rotation',flush=True)
                    elif 'sent' in row and 'position_error_m' in row:
                        print(f"[arm] frames={row['sent']} position error={row['position_error_m']*1000:.1f}mm rotation error={row['rotation_error_deg']:.1f}deg",flush=True)
                    elif 'phase' in row:
                        print('[hand] '+str(row['phase']),flush=True)
            time.sleep(.1)
    except KeyboardInterrupt:
        print('Stopping: Ctrl+C',flush=True)
    except Exception as error:
        failed=str(error)
        print('STOP: '+failed,flush=True)
    finally:
        stop.touch()
        if not args.preview:
            from quest_teleop.client import Robot
            for name,owner in owners.items():
                try:
                    robot=Robot('ms-thor' if name=='arm' else 'wuji-hand',by=owner)
                    result=robot.cap('stop_motion' if name=='arm' else 'cancel_motion',{},timeout=3)
                    print(name+' stop: '+json.dumps(result),flush=True)
                except Exception as error:
                    failed=failed or 'stop failed: '+str(error)
        deadline=time.monotonic()+15
        while any(p.poll() is None for p in children.values()) and time.monotonic()<deadline:
            time.sleep(.1)
        for name,child in children.items():
            if child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=3)
                failed=failed or name+' did not exit within 15 seconds; inspect log'
            logs[name].close()
        if not args.preview:
            for name,owner in owners.items():
                try:
                    robot=Robot('ms-thor' if name=='arm' else 'wuji-hand',by=owner)
                    robot.release()
                except Exception as error:
                    failed=failed or 'release failed: '+str(error)
        if failed:
            for name in children:
                print('--- '+name+' log ---',flush=True)
                print('\n'.join((output/(name+'.log')).read_text(encoding='utf-8',errors='replace').splitlines()[-8:]),flush=True)
        (output/'summary.json').write_text(json.dumps({'failure':failed,'capture':str(capture),'owners':owners},indent=2),encoding='utf-8')
        print('Stopped. Logs: '+str(output),flush=True)
        if previous_config is None:
            os.environ.pop('QUEST_TELEOP_CONFIG',None)
        else:
            os.environ['QUEST_TELEOP_CONFIG'] = previous_config
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
