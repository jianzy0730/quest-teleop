"""Nonblocking, owner-scoped Cartesian targets for the Thor device service."""
import math
import threading
import time
import uuid


class ArmStream:
    def __init__(self, driver):
        self.driver = driver
        self.lock = threading.RLock()
        self.session = None

    def status(self):
        with self.lock:
            policy = self.session.get('limit_policy', 'hold') if self.session else 'hold'
            result = dict(supports_vendor_ik=True, limit_policy=policy, input_timeout_policy='pause',
                          workspace_policy='hold' if policy == 'hold' else 'vendor_ik',
                          distance_limit_policy='hold' if policy == 'hold' else 'disabled')
            return dict(result, **({key:self.session[key] for key in ('session_id','seq','phase')}
                                  if self.session else {'phase':'idle'}))

    def start(self, args, owner):
        policy = args.get('limit_policy', 'hold')
        if set(args) - {'limit_policy'} or policy not in ('hold', 'vendor_ik'):
            raise ValueError('limit_policy must be hold or vendor_ik')
        self.driver.check_owner(owner)
        if not self.driver.control_status()['prepared']:
            raise RuntimeError('control not prepared')
        with self.lock:
            self.driver._release('new servo session')
            self.session = dict(session_id=uuid.uuid4().hex, owner=owner,
                                seq=-1, deadline=time.monotonic()+5, phase='awaiting_input', limit_policy=policy)
            return dict(exit='success', session_id=self.session['session_id'],
                        completion='stream_started', watchdog_s=.25)

    def stop(self, owner=None):
        with self.lock:
            if self.session and (owner is None or self.session['owner'] == owner):
                self.session['phase'] = 'stopped'

    def guard(self):
        with self.lock:
            s = self.session
            if s and s['phase'] in ('running', 'awaiting_input') and time.monotonic() > s['deadline']:
                self.driver._release('servo input stale')
                # _release also marks the session stopped. Only an input
                # timeout may become resumable; fault/cancel stops stay final.
                s['phase'] = 'paused'
                s.pop('hold_pose', None)

    def feedback(self, owner):
        self.driver.check_owner(owner)
        self.guard()
        return dict(exit='success', **self.status(),
                    eef_right=self.driver.measured_pose(),
                    source_t=self.driver.stream_source_t['eef_right'])

    def update(self, args, owner):
        if set(args) != {'session_id', 'seq', 'pose'}:
            raise ValueError('session_id, seq and pose required')
        values, seq = args['pose'], args['seq']
        if not isinstance(values, list) or len(values) != 7 or any(
                isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in values):
            raise ValueError('seven finite pose values required')
        if isinstance(seq, bool) or not isinstance(seq, int) or seq < 0:
            raise ValueError('nonnegative integer sequence required')
        n = math.sqrt(sum(v*v for v in values[3:]))
        if not .9 <= n <= 1.1:
            raise ValueError('invalid quaternion')
        d = self.driver
        d.check_owner(owner)
        if not d.perception_status()['ready'] or time.time() > d.control_valid_until:
            raise RuntimeError('perception or control unavailable')
        with self.lock:
            self.guard()
            s = self.session
            if not s or s['owner'] != owner or s['session_id'] != args['session_id']:
                raise PermissionError('servo session owner mismatch')
            if s['phase'] == 'stopped':
                raise RuntimeError('servo stopped; start a new session')
            if seq <= s['seq']:
                raise ValueError('servo sequence did not advance')
            if s['phase'] == 'paused':
                s.update(seq=seq, deadline=time.monotonic()+5, phase='awaiting_input')
                # Discard the first post-gap target, acknowledge measured pose
                # so the client can rebase before sending a NEW source frame.
                return dict(exit='success', completion='rebase_required', seq=seq,
                            eef_right=d.measured_pose(), source_t=d.stream_source_t['eef_right'])
            enforce_limits = s['limit_policy'] == 'hold'
            xyz = d._clamp(values[:3]) if enforce_limits else values[:3]
            limited = [axis for axis, a, b in zip('xyz', values[:3], xyz) if a != b]
            target_pose = xyz + [v/n for v in values[3:]]
            target = d.make_pose(target_pose)
            if enforce_limits and not d._max_step_ok(target):
                limited.append('distance')
            if limited:
                # Ordinary workspace/lead limits are not faults. Latch the
                # measured FULL pose once: a rejected rotation must not keep
                # pulling the arm away while translation is held. Do not
                # chase changing feedback or keep the previous moving goal.
                if 'hold_pose' not in s:
                    s['hold_pose'] = list(d.measured_pose())
                target_pose = list(s['hold_pose'])
                target = d.make_pose(target_pose)
            else:
                s.pop('hold_pose', None)
            d._set_target(target)
            s.update(seq=seq, deadline=time.monotonic()+.25, phase='running')
        return dict(exit='success', completion='target_held' if limited else 'target_accepted', seq=seq,
                    target_pose=target_pose, limited_axes=limited,
                    eef_right=d.measured_pose(), source_t=d.stream_source_t['eef_right'])
