"""Standalone right-hand Wuji service with local streaming sessions."""
import argparse
import json
import os
from pathlib import Path
import threading
import time
from ..config import load_config
from .session import Sessions
from .server import make_server
from .wuji_stream import HandStream, unpack_states

os.environ.setdefault('WUJI_TELEMETRY_DISABLE','1')

class HandDriver:
    def __init__(self, sdk, config=None):
        self.config = config or json.loads((Path(__file__).resolve().parents[1]/'assets/hand.json').read_text())
        self.sdk = sdk
        self.manager = sdk.SdkManager.instance()
        self.devices = {'right': load_config()['right_hand_serial']}
        self.safety = self.config['safety']
        self.lock = threading.Lock()
        self.state_lock = threading.Lock()
        self.cancel = threading.Event()
        self.sessions = Sessions()
        self.hands = {side:{'sn':sn,'online':None,'discovery_t':0.,'feedback_t':0.} for side,sn in self.devices.items()}
        self.motion_owner = None
        self.cancelled_owners = {}
        self.active_hand = self.hand_stream = None

    def check_motion(self, owner):
        if self.cancel.is_set() or owner in self.cancelled_owners:
            raise InterruptedError('motion cancelled')
        self.sessions.check(owner)

    def execute(self, name, args, owner=None):
        if name in ('stream_start','stream_target','stream_status'):
            with self.state_lock:
                if self.hand_stream is None:
                    self.hand_stream = HandStream(self)
            if name == 'stream_start':
                return self.hand_stream.start(args,owner)
            if name == 'stream_target':
                return self.hand_stream.update(args,owner)
            return self.hand_stream.status()
        if name == 'cancel_motion':
            return self.cancel_motion(owner)
        if name == 'hand_state':
            return self.hand_state(args)
        return {'exit':'unknown_capability','diagnosis':str(name)}

    def ready(self):
        # Discovery is deferred to stream_start; /ready never connects/enables motors.
        return {'ready':True,'backend':'standalone','hardware_checked':False,
                'capabilities':['stream_start','stream_target','stream_status','cancel_motion','hand_state'],
                **self.status()}

    def close(self):
        self.cancel.set()
        worker = getattr(self.hand_stream,'worker',None)
        if worker:
            worker.join(timeout=6)

    def status(self):
        with self.state_lock:
            return {"robot": "wuji-hand", "t": time.time(),
                    "task_protocol": 1,
                    "control_mode": "guarded",
                    "hands": {side: dict(state) for side, state in self.hands.items()}}

    def update_discovery(self, discovered):
        with self.state_lock:
            for side, serial in self.devices.items():
                device = discovered.get(serial)
                self.hands[side].update({"online": device is not None,
                                         "address": str(device.address) if device else None,
                                         "discovery_t": time.time()})

    def update_feedback(self, side, positions, online):
        with self.state_lock:
            self.hands[side].update({"positions_rad": positions, "online_joints": online,
                                     "feedback_t": time.time()})

    def begin_motion(self, owner):
        with self.state_lock:
            self.cancelled_owners = {key: seen for key, seen in self.cancelled_owners.items()
                                     if time.monotonic() - seen < 120.0}
            if owner in self.cancelled_owners:
                raise InterruptedError("task owner cancelled before dispatch")
            self.cancel.clear()
            self.motion_owner = owner

    def cancel_motion(self, owner):
        if not isinstance(owner, str) or not owner:
            raise ValueError("task owner required")
        with self.state_lock:
            self.cancelled_owners[owner] = time.monotonic()
            matches = self.motion_owner == owner
            if matches:
                self.cancel.set()
            hand = self.active_hand if matches else None
            if hand is not None:
                hand.disable()
        return {"exit": "success", "completion": "command_completed",
                "active_request_cancelled": matches}

    def connect(self, side, serial):
        available = {device.sn: device for device in self.manager.scan()}
        self.update_discovery(available)
        if serial not in available:
            raise RuntimeError(f"{side} hand {serial} not discovered")
        if available[serial].device_type != self.sdk.DeviceType.WujiHand2:
            raise RuntimeError(f"{serial} is not a Wuji Hand 2")
        return self.manager.connect(sn=serial, device_name=f"wuji_{side}")

    def positions(self, hand, timeout=3.0):
        subscription = hand.joint_states().subscribe()
        try:
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if self.motion_owner is not None:
                    self.check_motion(self.motion_owner)
                frame = subscription.recv()
                if frame is not None:
                    try:
                        return unpack_states(frame, self.sdk)
                    except (RuntimeError, ValueError):
                        pass  # Wait for a complete, valid SDK feedback frame.
                time.sleep(0.005)
        finally:
            subscription.close()
        raise TimeoutError("no complete joint_states frame in 3 seconds")

    def hand_state(self, args):
        side = args.get('side')
        if side != 'right':
            raise ValueError('right hand only')
        serial = self.devices[side]
        if not self.lock.acquire(blocking=False):
            return {"exit": "busy", "completion": "not_started"}
        try:
            hand = self.connect(side, serial)
            positions = self.positions(hand)
            online = hand.online_joints_count().get()
            self.update_feedback(side, positions, online)
            return {"exit": "success", "side": side, "sn": serial,
                    "task_protocol": 1,
                    "online_joints": online, "completion": "observed",
                    "positions_rad": positions}
        finally:
            try:
                self.manager.disconnect_all()
            finally:
                self.lock.release()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=17894)
    args=parser.parse_args()
    import wuji_sdk
    driver=HandDriver(wuji_sdk)
    server=make_server(driver,args.host,args.port)
    print(f'Wuji standalone listening on {args.host}:{args.port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        driver.close()
        server.server_close()

if __name__ == '__main__': main()
