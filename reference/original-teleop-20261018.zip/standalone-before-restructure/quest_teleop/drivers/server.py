"""HTTP transport shared by the two independent device services."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json

class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 128

def make_server(driver, host, port):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        disable_nagle_algorithm = True

        def respond(self, code, value):
            body = json.dumps(value, allow_nan=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            try:
                if self.path == '/ready':
                    result = driver.ready()
                    self.respond(200 if result.get('ready') else 503,result)
                elif self.path == '/state':
                    self.respond(200,driver.status())
                else:
                    self.respond(404,{'error':'unknown path'})
            except Exception as error:
                self.respond(503,{'ready':False,'diagnosis':str(error)})

        def do_POST(self):
            try:
                length = int(self.headers.get('Content-Length','0'))
                if not 0 < length <= 65536:
                    return self.respond(413,{'exit':'invalid_arguments','diagnosis':'request size'})
                body = json.loads(self.rfile.read(length))
                if not isinstance(body,dict):
                    raise ValueError('request must be an object')
                if self.path.startswith('/session/'):
                    result = driver.sessions.handle(self.path.rsplit('/',1)[1],body)
                elif self.path == '/cap':
                    if not isinstance(body.get('args',{}),dict):
                        raise ValueError('args must be an object')
                    result = driver.execute(body.get('name'),body.get('args',{}),body.get('by'))
                else:
                    return self.respond(404,{'exit':'unknown_path'})
                self.respond(200,result)
            except (ValueError,TypeError) as error:
                self.respond(400,{'exit':'invalid_arguments','diagnosis':str(error)})
            except (PermissionError,InterruptedError) as error:
                self.respond(200,{'exit':'session_required','diagnosis':str(error)})
            except Exception as error:
                self.respond(200,{'exit':'driver_error','diagnosis':str(error)})

        def log_message(self,*args):
            pass
    return Server((host,port),Handler)
