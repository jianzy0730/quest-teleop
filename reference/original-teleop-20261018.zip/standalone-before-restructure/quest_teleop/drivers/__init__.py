"""Standalone device services; imports never access hardware."""
