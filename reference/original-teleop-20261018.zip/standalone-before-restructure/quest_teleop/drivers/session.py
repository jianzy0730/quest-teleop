"""Driver-local exclusive control, independent of any external service."""
import math
import threading
import time

class Sessions:
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.lock = threading.RLock()
        self.owner = None
        self.deadline = 0.

    def valid(self, owner):
        with self.lock:
            return bool(owner and self.owner == owner and self.clock() < self.deadline)

    def handle(self, operation, body):
        owner = body.get('by')
        if not isinstance(owner,str) or not owner:
            raise ValueError('nonempty session owner required')
        ttl = body.get('ttl_s',6.)
        if isinstance(ttl,bool) or not isinstance(ttl,(int,float)) or not math.isfinite(ttl) or not 1 <= ttl <= 30:
            raise ValueError('ttl_s must be 1..30')
        with self.lock:
            active = self.owner is not None and self.clock() < self.deadline
            if operation == 'lease':
                if active and self.owner != owner:
                    return {'granted':False,'diagnosis':'device already controlled'}
                self.owner, self.deadline = owner, self.clock()+ttl
                return {'granted':True}
            if operation == 'heartbeat':
                if not self.valid(owner):
                    return {'granted':False,'diagnosis':'session expired or owned by another client'}
                self.deadline = self.clock()+ttl
                return {'granted':True}
            if operation == 'release':
                if self.owner != owner:
                    return {'released':False}
                self.owner, self.deadline = None, 0.
                return {'released':True}
            raise ValueError('unknown session operation')

    def check(self, owner):
        if not self.valid(owner):
            raise PermissionError('active device session required')
