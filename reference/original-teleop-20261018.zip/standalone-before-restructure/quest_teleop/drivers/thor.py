"""Standalone Thor EEF bridge; publishes to the vendor IK, never switches modes."""
import argparse
import math
import os
import threading
import time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from geometry_msgs.msg import PoseStamped, Pose
from std_msgs.msg import Int16MultiArray, Int32
from marvin_msgs.msg import IKRequest
from ..config import load_config
from .session import Sessions
from .server import make_server
from .thor_stream import ArmStream

def _now(): return time.time()

class Driver(Node):
    def __init__(self):
        super().__init__('quest_teleop_thor')
        self.config=load_config()
        self.lock=threading.RLock()
        self.action_lock=threading.RLock()
        self.request_context=threading.local()
        self.sessions=Sessions()
        self.cancelled_owners={}
        self.target=self.target_owner=None
        self.eef_r=None
        self.stream_source_t={'eef_right':0.}
        self.control_valid_until=0.
        self.control_samples={}
        self.control_topics={'robot_mode':'/tj/info/robot_state',
                             'input':'/tj/control/input_mode',
                             'ik_source':'/tj/info/ik_request_mux/active_source'}
        self.servo=ArmStream(self)
        latched=QoSProfile(reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,history=HistoryPolicy.KEEP_LAST,depth=1)
        self.create_subscription(PoseStamped,'/tj/info/eef_right',self.on_pose,10)
        self.create_subscription(Int16MultiArray,self.control_topics['robot_mode'],
            lambda m,info:self._control_sample('robot_mode',list(m.data),info),10)
        self.create_subscription(Int32,self.control_topics['input'],
            lambda m,info:self._control_sample('input',int(m.data),info),latched)
        self.create_subscription(Int32,self.control_topics['ik_source'],
            lambda m,info:self._control_sample('ik_source',int(m.data),info),latched)
        self.pub_ik=self.create_publisher(IKRequest,'/tj/control/ik_request/vla',10)
        self.create_timer(.02,self.tick)
        self.create_timer(.5,self._check_control_watchdog)

    def on_pose(self,message):
        stamp=message.header.stamp.sec+message.header.stamp.nanosec/1e9
        with self.lock:
            self.eef_r=message
            self.stream_source_t['eef_right']=stamp or _now()

    def check_owner(self,owner):
        self.sessions.check(owner)
        if owner in self.cancelled_owners:
            raise InterruptedError('session cancelled')

    def perception_status(self):
        age=_now()-self.stream_source_t['eef_right']
        ready=self.eef_r is not None and 0 <= age < .5
        return {'ready':ready,'streams':{'eef_right':{'source_t':self.stream_source_t['eef_right'],'ready':ready}}}

    def status(self):
        return {'robot':'ms-thor','updated_at':_now(),'eef_right':self.measured_pose(),
                'perception':self.perception_status()}

    def ready(self):
        return {'ready':self.perception_status()['ready'],'backend':'standalone',
                'control':self.control_status(),'servo':self.servo.status(),
                'capabilities':['servo_start','servo_target','servo_status','stop_motion','control_state']}

    def execute(self,name,args,owner):
        self.request_context.owner=owner
        if name == 'control_state':
            return {'exit':'success','control':self.control_status()}
        if name == 'stop_motion':
            return self.stop_motion(args)
        if name == 'servo_status':
            return self.servo.feedback(owner)
        with self.action_lock:
            self.check_owner(owner)
            try:
                if name == 'servo_start':
                    return self.servo.start(args,owner)
                if name == 'servo_target':
                    return self.servo.update(args,owner)
            except Exception:
                # A rejected malformed request or real fault ends this owner's
                # target. Normal workspace/lead limits return success/hold.
                if self.servo.session and self.servo.session['owner'] == owner:
                    self._release('command failed')
                raise
        return {'exit':'unknown_capability','diagnosis':str(name)}

    def _clamp(self, xyz):
        return [min(max(float(v),self.config['workspace'][k][0]),self.config['workspace'][k][1]) for k,v in zip('xyz',xyz)]

    def _max_step_ok(self,pose):
        actual=self.measured_pose()
        return actual is not None and math.dist(actual[:3],[pose.position.x,pose.position.y,pose.position.z]) <= self.config['max_step_m']

    def _release(self,why=''):
        self.servo.stop()
        with self.lock:
            self.target=self.target_owner=None

    def tick(self):
        self.servo.guard()
        with self.lock:
            target,owner=self.target,self.target_owner
        if target is None: return
        if not self.sessions.valid(owner) or not self.perception_status()['ready'] or _now()>self.control_valid_until:
            self._release('feedback/control/session unavailable')
            return
        with self.lock:
            if self.target is target: self._ik(target)

    @staticmethod
    def make_pose(values):
        result=Pose()
        result.position.x,result.position.y,result.position.z=map(float,values[:3])
        result.orientation.x,result.orientation.y,result.orientation.z,result.orientation.w=map(float,values[3:])
        return result

    def measured_pose(self):
        with self.lock:
            if self.eef_r is None: return None
            p,q=self.eef_r.pose.position,self.eef_r.pose.orientation
            return [p.x,p.y,p.z,q.x,q.y,q.z,q.w]

    def _check_control_watchdog(self):
        status = self.control_status()
        with self.lock:
            self.control_valid_until = _now() + 1.5 if status["prepared"] else 0.0

    def _control_sample(self, key, value, info):
        # Jazzy rclpy supplies message_info as a dict on this Thor image;
        # other releases expose the same field as an object attribute.
        gid = info.get("publisher_gid") if isinstance(info, dict) else getattr(info, "publisher_gid", None)
        if gid is None:
            publishers = self.get_publishers_info_by_topic(self.control_topics[key])
            gid = publishers[0].endpoint_gid if len(publishers) == 1 else None
        with self.lock:
            self.control_samples[key] = {"value": value, "seen": _now(),
                                         "gid": bytes(gid) if gid is not None else None}

    def control_status(self):
        now = _now()
        with self.lock:
            samples = dict(self.control_samples)
        values = {}
        for key, topic in self.control_topics.items():
            sample = samples.get(key)
            try:
                publishers = {bytes(item.endpoint_gid)
                              for item in self.get_publishers_info_by_topic(topic)}
            except Exception:
                publishers = set()
            live = sample is not None and len(publishers) == 1 and sample["gid"] in publishers
            if key == "robot_mode":
                live = live and now - sample["seen"] <= 1.0
            values[key] = sample["value"] if live else None
        values["ready"] = all(values[key] is not None for key in self.control_topics)
        values["prepared"] = (values["robot_mode"] == [1, 1] and
                              values["input"] == 1 and values["ik_source"] == 2)
        return values

    def _set_target(self, pose):
        owner = getattr(self.request_context, "owner", None)
        self.check_owner(owner)
        with self.lock:
            if owner in self.cancelled_owners:
                raise InterruptedError("task owner cancelled")
            self.target = pose
            self.target_owner = owner

    def _ik(self, pose):
        r = IKRequest(); r.header.stamp = self.get_clock().now().to_msg()
        r.header.frame_id = "base_link"
        r.right_hand_pose = pose; r.left_hand_pose = pose
        r.available = [False, True, False, False, False, False, False, False, False, False, False]
        self.pub_ik.publish(r)

    def stop_motion(self, _args=None):
        owner = getattr(self.request_context, "owner", None)
        if not owner:
            raise PermissionError("task owner required")
        with self.action_lock:
            self.servo.stop(owner)
            with self.lock:
                active = bool(self.servo.session and self.servo.session['owner'] == owner)
                held = self.target_owner == owner
                self.cancelled_owners[owner] = _now()
                if held:
                    self.target = None
                    self.target_owner = None
        return {"exit": "success", "completion": "command_completed",
                "active_request_cancelled": active, "held_target_released": held}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',default='0.0.0.0')
    parser.add_argument('--port',type=int,default=17893)
    args=parser.parse_args()
    os.environ.setdefault('ROS_DOMAIN_ID',str(load_config()['ros_domain_id']))
    rclpy.init()
    driver=Driver()
    server=make_server(driver,args.host,args.port)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try: rclpy.spin(driver)
    except KeyboardInterrupt: pass
    finally:
        driver._release('shutdown')
        server.shutdown()
        server.server_close()
        driver.destroy_node()
        rclpy.try_shutdown()

if __name__ == '__main__': main()
