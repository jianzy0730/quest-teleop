"""Shared bounded capture reads and live source checks for both followers."""
import json
import time


def capture_tail(path, max_bytes=131072):
    """Newest complete records first; ignore partial writes and old backlogs."""
    with path.open('rb') as source:
        source.seek(0, 2)
        start = max(0, source.tell()-max_bytes)
        source.seek(start)
        lines = source.read().split(b'\n')
    if start:
        lines = lines[1:]
    for line in reversed(lines[:-1]):
        try:
            record = json.loads(line)
            if isinstance(record, dict) and isinstance(record.get('packets'), list):
                yield record
        except (ValueError, UnicodeError):
            continue


class LiveGate:
    """Fresh frames; command sequence survives a confirmed source restart."""
    def __init__(self):
        self.seq = -1
        self.source_seq = self.source_ns = self.offset = None
        self.restart_candidate = None
        self.restarted = False

    @staticmethod
    def fresh(record, now_ns):
        age = (now_ns-record['recv_unix_ns'])/1e9
        if not -.1 <= age <= .2:
            raise TimeoutError(f'Quest input age {age:.3f}s; live input required')

    def accept(self, record, packet):
        self.fresh(record, time.time_ns())
        debug = packet.get('debug') or {}
        seq, source_ns = debug.get('source_frame_seq'), debug.get('source_ts_ns')
        if type(seq) is not int or type(source_ns) is not int or seq < 0 or source_ns < 0:
            raise ValueError('enable Debug Info in HTS; nonnegative frame sequence/time required')
        if self.source_seq is not None and (seq < self.source_seq or source_ns < self.source_ns):
            candidate = self.restart_candidate
            self.restart_candidate = (seq, source_ns)
            # One reordered packet is not a restart; confirm advancing frames.
            if candidate is None or seq <= candidate[0] or source_ns <= candidate[1]:
                return False
            self.offset = None
            self.restarted = True
        elif seq == self.source_seq or (self.source_ns is not None and source_ns <= self.source_ns):
            return False
        self.restart_candidate = None
        offset = (record['recv_unix_ns']-source_ns)/1e9
        self.offset = offset if self.offset is None else min(self.offset, offset)
        if offset-self.offset > .15:
            raise TimeoutError('Quest transport backlog >150ms')
        self.source_seq, self.source_ns = seq, source_ns
        self.seq += 1
        return True


class WristGate(LiveGate):
    def accept(self, packets, calibration=False):
        now = time.time_ns()
        for key in ('Right/wrist', 'Right/landmarks') + (('Head/pose',) if calibration or self.restarted else ()):
            self.fresh(packets[key][0], now)
        record, wrist = packets['Right/wrist']
        _, hand = packets['Right/landmarks']
        wrist_debug, hand_debug = wrist.get('debug') or {}, hand.get('debug') or {}
        if any(wrist_debug.get(key) != hand_debug.get(key)
               for key in ('source_frame_seq', 'source_ts_ns')):
            return False  # TCP lines may straddle one file flush.
        return super().accept(record, wrist)


def latest_right(path):
    for record in capture_tail(path, 65536):
        for packet in record['packets']:
            if packet.get('key') == 'Right/landmarks':
                return record, packet
    raise ValueError('no right-hand landmarks in latest input')


def latest_packets(path):
    found, pairs = {}, {}
    for record in capture_tail(path):
        for packet in record['packets']:
            key = packet.get('key')
            if key == 'Head/pose' and key not in found:
                found[key] = record, packet
            elif key in ('Right/wrist', 'Right/landmarks'):
                debug = packet.get('debug') or {}
                frame = debug.get('source_frame_seq'), debug.get('source_ts_ns')
                pairs.setdefault(frame, {}).setdefault(key, (record, packet))
        if 'Head/pose' in found:
            for pair in pairs.values():
                if len(pair) == 2:
                    return {**pair, **found}
    raise ValueError('need Right/wrist, Right/landmarks and Head/pose; enable Head Pose')
