"""Portable configuration, resolved once and passed explicitly to children."""
from copy import deepcopy
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
DEFAULTS = {
    'backend': 'standalone',
    'thor_url': 'http://6.6.8.100:17893',
    'wuji_url': 'http://127.0.0.1:17894',
    'blackboard_url': 'http://127.0.0.1:17892',
    'transport': 'usb', 'port': None, 'scale': 1.0, 'filter_alpha': 1.0,
    'only': 'both', 'wsl_distro': 'Ubuntu-22.04',
    'hand_python': '~/.venv-quest-teleop/bin/python',
    'right_hand_serial': 'WH2KA01260905017',
    'ros_domain_id': 24, 'arm_limit_policy': 'vendor_ik',
    'workspace': {'x': [0.20, 0.75], 'y': [-0.40, 0.40], 'z': [0.03, 0.90]},
    'max_step_m': 0.15,
}

def load_config(path=None):
    chosen = path or os.environ.get('QUEST_TELEOP_CONFIG')
    chosen = Path(chosen).expanduser().resolve() if chosen else ROOT/'config.local.json'
    config = deepcopy(DEFAULTS)
    if chosen.exists():
        overrides = json.loads(chosen.read_text(encoding='utf-8-sig'))
        if not isinstance(overrides, dict):
            raise ValueError('config must be a JSON object')
        unknown = set(overrides)-set(DEFAULTS)
        if unknown:
            raise ValueError('unknown config keys: '+', '.join(sorted(unknown)))
        config.update(overrides)
    elif path or os.environ.get('QUEST_TELEOP_CONFIG'):
        raise FileNotFoundError(chosen)
    if config['backend'] not in ('standalone', 'existing'):
        raise ValueError('backend must be standalone or existing')
    if config['arm_limit_policy'] not in ('vendor_ik', 'hold'):
        raise ValueError('arm_limit_policy must be vendor_ik or hold')
    for key in ('thor_url', 'wuji_url', 'blackboard_url'):
        url = urlsplit(config[key])
        if url.scheme not in ('http','https') or not url.hostname:
            raise ValueError(key+' must be an HTTP(S) URL')
    import math
    if not math.isfinite(config['scale']) or config['scale'] <= 0:
        raise ValueError('scale must be finite and positive')
    if not 0 < config['filter_alpha'] <= 1:
        raise ValueError('filter_alpha must be in (0,1]')
    if config['only'] not in ('both','arm','hand') or config['transport'] not in ('usb','udp'):
        raise ValueError('invalid only or transport')
    if config['port'] is not None and (type(config['port']) is not int or not 1 <= config['port'] <= 65535):
        raise ValueError('port must be an integer in 1..65535')
    for axis in 'xyz':
        bounds = config['workspace'].get(axis, [])
        if len(bounds) != 2 or not all(math.isfinite(v) for v in bounds) or bounds[0] >= bounds[1]:
            raise ValueError('invalid workspace '+axis)
    if not math.isfinite(config['max_step_m']) or config['max_step_m'] <= 0:
        raise ValueError('max_step_m must be finite and positive')
    return config

