# Quest Teleop · 天机右臂 + Wuji Hand 2

Quest 3 裸手遥操的独立代码仓库。一个入口完成 USB 转发、接收、坐标映射、手部 retarget、机械臂与灵巧手跟随和日志记录。Windows 运行主程序，WSL 运行手部算法/SDK，Thor 本机运行 ROS 2 驱动。

不导入原项目的 `harness/`、`遥操/`、`robots/`，手模型、算法与配置已随仓库打包。两种后端：`standalone` 使用本仓库独立驱动；`existing` 连接当前已经部署的驱动，其控制权仍由旧黑板服务管理。

## 当前这台电脑：直接运行

本机 `config.local.json` 使用 `existing`，手部算法使用独立 WSL `~/.venv-quest-teleop` 环境。客户端、独立驱动和旧驱动适配代码已在本地更新，可以离线继续开发。2026-10-17 部署记录：Wuji 现有服务已更新；Thor 端尚未部署，实机验证留待连接后进行。

从任意 PowerShell 目录运行：

```powershell
& "C:\jianziYu\桌面\天机\quest-teleop\.venv\Scripts\python.exe" -u -m quest_teleop follow
```

先运行命令也可以：程序会等 USB 授权和实时数据。Quest 的 Hand Tracking Streamer 设置为 **TCP / 127.0.0.1 / 8000**，打开 **Head Pose、Debug Info**，关闭 **Video Feed**，再点 Start Streaming。把右手放在头显视野内，初始姿态用于机械臂相对映射标定。**Ctrl+C 结束两侧跟随**。

以下相对命令在本目录执行：

```powershell
# 只跟机械臂
.\.venv\Scripts\python.exe -m quest_teleop follow --only arm

# 只跟灵巧手
.\.venv\Scripts\python.exe -m quest_teleop follow --only hand

# 手腕平移放大 1.5 倍，旋转仍为 1:1
.\.venv\Scripts\python.exe -m quest_teleop follow --scale 1.5

# 只接收和计算，不发送运动命令
.\.venv\Scripts\python.exe -m quest_teleop follow --preview

# 只读诊断：依赖、USB、驱动后端是否匹配
.\.venv\Scripts\python.exe -m quest_teleop doctor

.\.venv\Scripts\python.exe -m quest_teleop follow --help
```

代码修改和本地依赖检查不需要 Quest 或机器人在线。仅检查本地安装可运行 `python -m quest_teleop doctor --offline`（使用本仓库 `.venv`）；普通 `doctor` 会检查设备连接。`follow --preview` 不发送运动命令，但仍需要实时输入，不能用它代替完全离线检查。

## 新电脑安装

需要 Windows Python 3.10+、ADB、Ubuntu 22.04 WSL，以及头显上的 [Hand Tracking Streamer](https://github.com/wengmister/hand-tracking-streamer)。USB 调试须在头显允许。机器人厂商 ROS/IK 环境与灵巧手 USB 接入仍由设备侧提供。

```powershell
cd <本仓库目录>
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
if (-not (Test-Path config.local.json)) { Copy-Item config.example.json config.local.json }
wsl -d Ubuntu-22.04 --exec python3 scripts/setup_hand.py
.\.venv\Scripts\python.exe -m quest_teleop doctor --offline
```

这些命令创建本地 `.venv`、WSL `~/.venv-quest-teleop`，安装依赖并做离线检查；不会启用电机或启动设备驱动。Linux 如缺少 venv：`sudo apt install python3-venv`。编辑 `config.local.json`，确认机器人地址、手序列号和 WSL 发行版。若使用其他 WSL 发行版，同时修改命令中的 `-d` 和配置中的 `wsl_distro`。

复用旧设备服务时，将上述模板换成 `config.existing.json`；两种后端都使用同一个 WSL `~/.venv-quest-teleop` 环境。默认模板为 `standalone`，不能直接连接仍在使用旧协议的驱动。独立驱动部署方法见下文。

## 配置与行为

配置优先级：内置默认值 → `config.local.json`（或 `QUEST_TELEOP_CONFIG` 指定文件）→ 启动参数。`config.example.json` 是独立版模板，`config.existing.json` 是迁移模板。也可用 `python -m quest_teleop --config <路径> follow ...`。

| 配置/参数 | 含义 |
|---|---|
| `backend` | `standalone` 独立驱动 / `existing` 现有驱动 |
| `thor_url` / `wuji_url` | 两侧设备 HTTP 地址 |
| `wsl_distro` / `hand_python` | 手部算法 WSL 环境 |
| `right_hand_serial` | 独立 Wuji 驱动选择的右手序列号 |
| `arm_limit_policy` | 默认 `vendor_ik`，遥操不添加 XYZ 方框或 15 cm 领先限制；`hold` 保留旧软件限位 |
| `--only both/arm/hand` | 默认同时跟随手和手臂 |
| `--duration <秒>` | 可选，仅主入口 `follow` 统一计时；默认持续运行到 Ctrl+C |
| `--scale 1.5` | 手腕位移缩放，不改变旋转比例 |
| `--filter-alpha 1` | 默认不添加手部低通平滑 |
| `--hand-velocity <rad/s>` | 可选速度限制，默认无额外限制 |
| `--transport udp --port 9000` | Wi-Fi UDP；头显填电脑 IP |

手：Quest 21 个关键点经 Unity 坐标反射、掌心坐标对齐，输入 Wuji 官方开源 `AdaptiveOptimizerAnalytical`，输出 SDK 顺序的 20 个绝对关节角。模型掌心旋转由模型本身推导，未添加用户握拳幅度校准。

手臂：从起始右腕与机器人末端建立相对 6D 映射，头显初始朝向定义操控方向，平移按 scale 缩放；目标姿态发送给 Thor **厂商 IK**，本仓库不重新求解机械臂 IK。尚未增加腕部到工具 TCP 的外参标定。

单帧几何异常或计算后已过时的数据跳过，不退出；静止手势不会仅因坐标不变而暂停。丢手或停流暂停，恢复后继续。串流帧号归零后自动识别新数据源，手继续绝对关节角跟随，机械臂用新手腕与当前末端重新标定；发给驱动的命令序号保持递增。

手部目标按模型限位夹紧；真实反馈保留原值，越界超过 0.01 rad 记录警告。固件限位生效时保持/夹紧该关节，标志清除后释放临时边界。手部跟踪误差和固件 Warning 不退出。真实设备故障、控制权丢失和设备反馈中断仍会停止；Ctrl+C 清理逻辑保留。

默认 `arm_limit_policy: vendor_ik` 将完整位姿交给厂商 IK，不再叠加本程序的 XYZ 方框和 15 cm 领先限制；这不代表所有目标都可达，也不提供避碰。需要旧限位可设为 `hold`（独立驱动使用 `workspace` / `max_step_m`，旧驱动使用其原设置）。现有 Thor 服务需先部署更新后的 `robots/ms-thor/streaming.py` 才支持新策略；客户端会明确检查版本，不会静默使用旧策略。程序不切换 Thor 模式或 VLA 输入。

只跟手的 `--only hand` 不再要求 Head Pose 或 wrist 输入；手臂标定仍需要它们。手部已移除起点附近的小幅试运行限制。接收文件仅保存解析数据、来源与接收时间，不重复保存原始文本。

离线录制计算：在 WSL 手部环境运行 `python -m quest_teleop hand --capture <capture.jsonl> --replay`，逐帧计算后自动退出，不连接设备；不能与 `--execute` 同用。

## 代码位置

```text
quest_teleop/__main__.py            统一 Python 命令入口
config.*.json                       集中配置
quest_teleop/
  follow.py                        主进程与子进程生命周期
  quest_receive.py                  Quest TCP/UDP 接收、记录
  tracking.py                       共用输入尾读、帧配对、时效检查
  quest_arm.py / quest_arm_follow.py  腕部映射、机械臂跟随
  quest_hand.py                     手部 retarget 与跟随
  client.py / http_stream.py        设备会话、HTTP 长连接
  drivers/                         独立 Thor/Wuji 驱动
  assets/ / _vendor/                手模型、限位、算法快照
scripts/setup_hand.py               WSL 手部环境安装
logs/                              每次启动的配置、输入与日志
```

## 独立驱动部署

本机目前使用旧服务。以下独立驱动尚未做真机运动验证，部署后可以脱离旧 Harness/黑板。

Thor：将仓库复制到机器人，需要已有厂商 ROS 2、rclpy、geometry_msgs、std_msgs、marvin_msgs 和厂商 IK。停止占用 17893 的旧服务（通常为 `tianji-thor-driver.service`），在仓库目录执行：

```bash
source /etc/apex/apex_ros_env.sh
python3 -u -m quest_teleop thor-driver
```

先加载厂商 ROS 环境，再运行 Python 驱动，默认 `ROS_DOMAIN_ID=24`。驱动使用右臂 `/tj/control/ik_request/vla`，要求已有模式 `[1,1]`、input=1、IK source=2，不会切换模式或输入。

Wuji：安装完成、USB 已接入 WSL 后，停止旧 `tianji-wuji-driver.service`，释放 17894 和 SDK 连接。在 WSL 的仓库目录执行：

```bash
~/.venv-quest-teleop/bin/python -u -m quest_teleop wuji-driver
```

默认监听 `127.0.0.1:17894`，Windows 经 WSL localhost 转发访问。`/ready` 返回的 `hardware_checked: false` 表示设备连接将在跟随启动时进行。

两侧 `/ready` 都应返回 `backend: standalone`。Windows 配置改为 `backend: standalone`、`hand_python: ~/.venv-quest-teleop/bin/python`，确认地址后运行 `python -m quest_teleop doctor`，再用 `python -m quest_teleop follow --preview` 检查输入，最后 `python -m quest_teleop follow` 跟随；这里的 Python 使用本仓库 `.venv`。同一设备同时只能运行一个驱动。回退时停止新驱动、恢复旧服务，并将配置恢复为 `existing`。

## 第三方来源

| 内容 | 来源 / 版本 |
|---|---|
| 手部算法 | [wuji-retargeting](https://github.com/wuji-technology/wuji-retargeting)，`531f6ed4250b475d2e9231f54e988fc9b1c5b4ea`，MIT |
| 右手模型 | [wuji-description](https://github.com/wuji-technology/wuji-description)，`8271644a78d69ed9a4adcf9165d882c64ad33dfa` |
| Quest 应用与协议 | [hand-tracking-streamer](https://github.com/wengmister/hand-tracking-streamer)，Python SDK `hand-tracking-sdk==1.1.0` |
| 灵巧手 SDK | [wuji-sdk](https://pypi.org/project/wuji-sdk/)，`2026.9.22` |

上游许可证保留于 `quest_teleop/_vendor/wuji_retargeting/LICENSE` 和 `quest_teleop/assets/WUJI_MODEL_LICENSE`。算法为本地精简版：移除了备用 VectorOptimizer、可视化/代价查询接口及未使用的内部性能统计；AdaptiveOptimizerAnalytical 的目标函数、梯度、求解参数和限位保持原样。模型用于运动学计算，不含渲染网格。本地原创部分的对外许可证由所有者决定。
