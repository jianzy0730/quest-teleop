"""Install WSL hand dependencies without touching device services."""
import argparse
from pathlib import Path
import subprocess
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.parse_args()
root=Path(__file__).resolve().parents[1]
environment=Path.home()/'.venv-quest-teleop'
if not (environment/'bin/python').is_file():
    subprocess.run([sys.executable,'-m','venv',str(environment)],check=True)
interpreter=environment/'bin/python'
subprocess.run([str(interpreter),'-m','pip','install','-e',str(root)+'[hand]'],check=True)
subprocess.run([str(interpreter),'-m','quest_teleop','doctor','--offline','--hand'],check=True,cwd=root)
print('Hand environment ready:',interpreter)
